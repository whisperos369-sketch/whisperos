/**
 * @fileoverview The central orchestration agent for the Whisper OS multi-agent system.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { aiService } from './services/ai-service.ts';
import type { SongState } from './sections.ts';
import type { AgentName, AgentState, AgentStatus } from './context.ts';
import { serializeCues } from './cue-export.ts';

type ProjectGetter = () => SongState;
type ProjectUpdater = (updates: Partial<SongState>, markDirty?: boolean) => void;
type StatusUpdater = (agent: AgentName, status: AgentState, message?: string) => void;
type AgentStatusGetter = () => AgentStatus;
type ToastNotifier = (message: string, type?: 'info' | 'success' | 'error') => void;

export class OrchestratorAgent {
    public isRunning = false;

    constructor(
        private getProject: ProjectGetter,
        private updateProject: ProjectUpdater,
        private updateStatus: StatusUpdater,
        private getAgentStatus: AgentStatusGetter,
        private showToast: ToastNotifier
    ) {}

    private _setStatus(agent: AgentName, status: AgentState, message?: string) {
        this.updateStatus(agent, status, message);
    }
    
    private _resetAllStatuses() {
        const agents: AgentName[] = ['lyrics', 'music', 'mastering', 'cover', 'video'];
        agents.forEach(agent => this._setStatus(agent, 'idle'));
    }

    async runFullPipeline() {
        if (this.isRunning) {
            this.showToast('Orchestration is already in progress.', 'info');
            return;
        }

        this.isRunning = true;
        this._resetAllStatuses();
        this.showToast('Starting multi-agent orchestration...', 'info');

        try {
            // 1. Lyrics Agent
            this._setStatus('lyrics', 'working', 'Drafting lyrical concepts...');
            let project = this.getProject();
            const lyricsRes = await aiService.lyricsDraft({
                prompt: `A song titled "${project.meta.title}" with a genre of ${project.meta.key}`,
                energy: 'high',
                rhyme: 'medium',
                syllables: 12,
                rhymeScheme: 'ABAB'
            });
            const bestDraft = lyricsRes.drafts[0];
            if (!bestDraft) throw new Error('Lyrics agent failed to produce a draft.');
            
            const firstSection = project.order[0] || 'verse1';
            this.updateProject({
                lyrics: bestDraft.text,
                drafts: { ...project.drafts, [firstSection]: [bestDraft] }
            });
            this._setStatus('lyrics', 'complete', 'Best draft selected and analyzed.');

            // Refresh project state after update
            project = this.getProject();
            
            // 2. Parallel Music and Cover Art Generation with enhanced context
            this._setStatus('music', 'working', 'Composing instrumental...');
            this._setStatus('cover', 'working', 'Generating cover art...');

            const musicPrompt = `Music for a ${bestDraft.analysis.mood} song titled "${project.meta.title}" about ${bestDraft.analysis.themes.join(', ')}. Key features should include ${bestDraft.analysis.instrumentation_suggestions.join(', ')}. The song's energy should be: ${bestDraft.analysis.energy_curve}. Style: ${project.meta.key}.`;
            const coverPrompt = `An abstract album cover for a ${bestDraft.analysis.mood} song titled "${project.meta.title}" about ${bestDraft.analysis.themes.join(', ')}. Visually, it should incorporate motifs of ${bestDraft.analysis.visual_motifs.join(', ')}. Style: dark, cinematic.`;

            const [musicResult, coverResult] = await Promise.all([
                aiService.musicGen({
                    prompt: musicPrompt,
                    duration: project.meta.duration,
                    model: 'medium'
                }),
                aiService.coverArt({
                    prompt: coverPrompt,
                    numImages: 6,
                    loras: project.loraStack.filter(l => l.path.includes('visual')),
                })
            ]);
            
            this.updateProject({
                audio: { ...this.getProject().audio, latestMix: musicResult.url },
                visuals: { ...this.getProject().visuals, coverArtUrl: coverResult.pickedUrl },
                meta: { ...this.getProject().meta, clipScore: coverResult.images.find(img => img.url === coverResult.pickedUrl)?.score }
            });
            this._setStatus('music', 'complete', 'Instrumental ready.');
            this._setStatus('cover', 'complete', `Best cover selected (Score: ${this.getProject().meta.clipScore?.toFixed(4)})`);
            
            // 3. Mastering Agent
            this._setStatus('mastering', 'working', 'Applying mastering chain...');
            // FIX: The exportPack method was missing from the service stub. Using a mock response.
            const masterRes = await aiService.exportPack({
                mix: musicResult.url,
                stems: {},
                metadata: this.getProject().meta,
                lufsTarget: this.getProject().meta.lufsTarget,
            });
            this.updateProject({
                audio: { ...this.getProject().audio, latestMix: masterRes.mixUrl },
                meta: { ...this.getProject().meta, measurements: masterRes.measurements }
            });
            this._setStatus('mastering', 'complete', `Mastered to ${masterRes.measurements.lufs.toFixed(1)} LUFS.`);
            
            // 4. Video Agent
            this._setStatus('video', 'working', 'Rendering video...');
            const videoRes = await aiService.videoGen({
                audioUrl: masterRes.mixUrl,
                imageUrl: coverResult.pickedUrl,
                template: 'spectrum',
                cueJson: serializeCues(this.getProject()),
            });
            this.updateProject({ visuals: { ...this.getProject().visuals, videoUrl: videoRes.videoUrl } });
            this._setStatus('video', 'complete', 'Video render complete.');
            
            // 5. Finalize
            this.showToast('Orchestration complete! All assets generated.', 'success');

        } catch (e) {
            const errorMessage = (e instanceof Error) ? e.message : 'An unknown error occurred.';
            this.showToast(`Orchestration failed: ${errorMessage}`, 'error');
            // Mark the currently running agent as failed
            const agents: AgentName[] = ['lyrics', 'music', 'cover', 'mastering', 'video'];
            for (const agent of agents) {
                if (this.getAgentStatus()[agent].status === 'working') {
                    this._setStatus(agent, 'error', errorMessage);
                    break;
                }
            }
        } finally {
            this.isRunning = false;
        }
    }
}