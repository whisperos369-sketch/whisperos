



/**
 * @fileoverview The "Remix" mode component.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { html, svg, css, LitElement } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { ContextConsumer } from '@lit/context';

import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';
import { appContext } from '../context.ts';
import { aiService } from '@/ai-service.ts';
import { GENRES, STANDARD_VOCAL_MODELS } from '../data.ts';
import { audioBufferToWav } from '../utils.ts';
import { audioIntelService } from '../audio-intel.ts';
import type { Analysis, Stems } from '../audio-intel.ts';
import type { SmartLoraSelection } from '../schema.ts';
import { beatAgent } from '../beat-agent.ts';


// Import the new file input component
import './file-link-input.ts';

@customElement('remix-lora-mode')
export class RemixLoraMode extends StudioModule {
    private appContextConsumer = new ContextConsumer(this, {context: appContext, subscribe: true});

    @state() private generatedRemixPlan = '';
    @state() private isRemixGenerated = false;
    
    // Remix state
    @state() private remixSourceFile: File | null = null;
    @state() private isFetchingRemixFile = false;
    @state() private audioAnalysis: Analysis | null = null;
    @state() private audioStems: Stems | null = null;
    @state() private smartLoraSelection: SmartLoraSelection | null = null;
    @state() private analysisStatus: 'idle' | 'loading' | 'success' | 'error' = 'idle';
    @state() private stemSeparationStatus: 'idle' | 'loading' | 'success' | 'error' = 'idle';
    @state() private analysisError = '';
    @state() private stemSeparationError = '';
    @state() private pitchShiftSemitones = 0;
    private currentStemSource: AudioBufferSourceNode | null = null;
    private _lastAnalyzedTrackBuffer: AudioBuffer | null = null;
    
    // FIX: Removed 'override' modifier to fix build error.
    static styles = [
        sharedStyles,
        css`
            .source-info-bar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                background-color: var(--bg-sidebar);
                padding: 0.5rem 1rem;
                border-radius: 5px;
                margin-top: 1rem;
                font-size: 0.8rem;
                border: 1px solid var(--border-color);
            }
            .source-name {
                color: var(--text-secondary);
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                margin-right: 1rem;
                flex-shrink: 1;
            }
            .analysis-results {
                display: flex;
                gap: 1rem;
                align-items: center;
                flex-shrink: 0;
            }
            .analysis-item {
                display: flex;
                align-items: center;
                gap: 0.3rem;
            }
            .analysis-error {
                color: var(--color-error);
            }
            .spinner {
                animation: rotate 2s linear infinite;
            }
            @keyframes rotate {
                100% { transform: rotate(360deg); }
            }
            .spinner .path {
                stroke: currentColor;
                stroke-linecap: round;
                animation: dash 1.5s ease-in-out infinite;
            }
            @keyframes dash {
                0% { stroke-dasharray: 1, 150; stroke-dashoffset: 0; }
                50% { stroke-dasharray: 90, 150; stroke-dashoffset: -35; }
                100% { stroke-dasharray: 90, 150; stroke-dashoffset: -124; }
            }
            .stem-loading-indicator {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                color: var(--text-tertiary);
                font-size: 0.8rem;
                padding: 1rem;
            }
            .stem-player-controls {
                display: flex;
                gap: 0.5rem;
                flex-wrap: wrap;
                margin-top: 1rem;
            }
            .stem-player-controls button {
                background-color: var(--bg-input);
                color: var(--text-secondary);
                border: 1px solid var(--border-color);
            }
            .stem-player-controls button:hover {
                background-color: var(--border-color);
            }
            .remix-plan-container pre {
                white-space: pre-wrap;
                word-wrap: break-word;
                font-size: 0.85rem;
                line-height: 1.6;
                color: var(--text-secondary);
                background-color: var(--bg-input);
                padding: 1.2rem;
                border-radius: 8px;
                border: 1px solid var(--border-color);
            }
        `
    ];

    private get _sourceAudioFile(): File | null {
        if (this.remixSourceFile) {
            return this.remixSourceFile;
        }
        const appContext = this.appContextConsumer.value;
        if (appContext?.currentTrack.audioBuffer) {
            const blob = audioBufferToWav(appContext.currentTrack.audioBuffer);
            return new File([blob], `${appContext.currentTrack.title}.wav`, { type: 'audio/wav' });
        }
        return null;
    }

    private async _runAnalysis() {
        const fileToAnalyze = this._sourceAudioFile;
        const appContext = this.appContextConsumer.value;

        if (!fileToAnalyze || !appContext?.audioContext) {
            this.analysisError = 'No source audio file to analyze.';
            this.analysisStatus = 'error';
            return;
        }

        // Prevent re-analysis of the same buffer if it hasn't changed
        const currentBuffer = this.remixSourceFile ? null : appContext.currentTrack.audioBuffer;
        if (this.analysisStatus === 'success' && currentBuffer && currentBuffer === this._lastAnalyzedTrackBuffer) {
            return;
        }

        this.analysisStatus = 'loading';
        this.analysisError = '';
        this.audioAnalysis = null;
        this._lastAnalyzedTrackBuffer = currentBuffer;

        try {
            this.audioAnalysis = await audioIntelService.analyze(fileToAnalyze, appContext.audioContext);
            this.analysisStatus = 'success';
        } catch (e) {
            this.analysisError = (e as Error).message;
            this.analysisStatus = 'error';
            console.error("Audio analysis failed:", e);
        }
    }
    
    private async _runStemSeparation() {
        const fileToSeparate = this._sourceAudioFile;
        const appContext = this.appContextConsumer.value;

        if (!fileToSeparate || !appContext?.audioContext) {
            this.stemSeparationError = 'No source audio file to separate.';
            this.stemSeparationStatus = 'error';
            return;
        }

        this.stemSeparationStatus = 'loading';
        this.stemSeparationError = '';
        this.audioStems = null;

        try {
            this.audioStems = await audioIntelService.splitStems(fileToSeparate, appContext.audioContext);
            this.stemSeparationStatus = 'success';
            this._getSmartLoraSelection();
        } catch (e) {
            this.stemSeparationError = (e as Error).message;
            this.stemSeparationStatus = 'error';
            console.error("Stem separation failed:", e);
        }
    }
    
    private async _getSmartLoraSelection() {
        const appContext = this.appContextConsumer.value;
        if (!appContext) return;
        
        const task = async () => {
            const genre = (this as LitElement).shadowRoot?.querySelector<HTMLSelectElement>('#remix-genre-select')?.value ?? 'House';
            this.smartLoraSelection = await aiService.getSmartLoraSelection(
                genre,
                'vocal remix',
                appContext.trainedLoras.map(lora => ({ name: lora.name, type: lora.type }))
            );
        };
        
        await this._performTask('Select LoRAs', [{message: 'Analyzing context for LoRA selection...', duration: 1500}], task);
    }
    
    public triggerRemixPlan(source: string, genre: string, targets: string[]) {
        ((this as LitElement).shadowRoot!.querySelector<HTMLSelectElement>('#remix-genre-select')!).value = genre;
        (this as LitElement).shadowRoot!.querySelectorAll<HTMLInputElement>('input[name="remix-target"]').forEach(el => {
            el.checked = targets.includes(el.value);
        });
        (this as LitElement).requestUpdate();
        this._handleGeneratePlan();
    }

    private async _handleGeneratePlan() {
        const appContext = this.appContextConsumer.value;
        if (!appContext) return;

        const targets = Array.from((this as LitElement).shadowRoot!.querySelectorAll<HTMLInputElement>('input[name="remix-target"]:checked')).map(el => el.value);
        const mutedTargets = Array.from((this as LitElement).shadowRoot!.querySelectorAll<HTMLInputElement>('input[name="remix-target"]:not(:checked)')).map(el => el.value);
        const genre = ((this as LitElement).shadowRoot!.querySelector<HTMLSelectElement>('#remix-genre-select'))?.value ?? 'House';
        const vocalRetakeLora = ((this as LitElement).shadowRoot!.querySelector<HTMLSelectElement>('#vocal-retake-lora-select'))?.value ?? 'none';

        const task = async () => {
            const plan = await aiService.generateRemixPlan({
                genre,
                source: this._sourceAudioFile?.name || 'current track',
                targets,
                mutedTargets,
                loras: this.smartLoraSelection?.instrumental || 'none',
                vocalRetakeLora,
                analysis: this.audioAnalysis,
                pitchShiftSemitones: this.pitchShiftSemitones,
            }, appContext.explicitContentFilter);
            if (!plan) throw new Error("Remix plan generation failed.");
            this.generatedRemixPlan = plan;
        };

        await this._performTask('Generate Remix Plan', [
            { message: 'Analyzing remix parameters...', duration: 1000 },
            { message: 'Formulating production strategy...', duration: 2500 },
        ], task);
    }

    private async _handleGenerateRemix() {
        const appContext = this.appContextConsumer.value;
        if (!appContext?.audioContext || !this.generatedRemixPlan) return;

        const task = async () => {
            const genre = (this as LitElement).shadowRoot!.querySelector<HTMLSelectElement>('#remix-genre-select')?.value ?? 'House';
            
            let vocalBlob: Blob | undefined;
            const vocalStemBuffer = this.audioStems?.vocal;
            if (vocalStemBuffer) {
                vocalBlob = audioBufferToWav(vocalStemBuffer);
            }

            const buffer = await beatAgent.generateInstrumental({
                audioContext: appContext.audioContext!,
                duration: vocalStemBuffer?.duration || 90,
                bpm: this.audioAnalysis?.bpm ? (this.audioAnalysis.bpm > 140 ? 128 : 150) : 128,
                keySignature: this.audioAnalysis?.key || 'A Minor',
                instrumentalDescriptions: {
                    drums: `a ${genre} drum beat`,
                    bassline: `a ${genre} bassline`,
                    melody: `a melody for the remix of ${this._sourceAudioFile?.name || 'the track'}`,
                    pads: `atmospheric pads for a ${genre} remix`,
                },
                conditioningAudio: vocalBlob,
            });

            appContext.updateTrack({
                title: `${this._sourceAudioFile?.name.replace(/\.[^/.]+$/, '')} (Remix)`,
                artist: 'Remix Agent',
                duration: buffer.duration,
                audioBuffer: buffer,
            });
            this.isRemixGenerated = true;
        };
        
        await this._performTask('Generate Remix Audio', [], task);
    }
    
    private _updatePrimaryAction() {
        let label = 'Generate Remix';
        let action = this._handleGenerateRemix.bind(this);
        let disabled = !this.generatedRemixPlan || this.isLoading;

        (this as LitElement).dispatchEvent(new CustomEvent('primary-action-update', {
            detail: { label, action, disabled },
            bubbles: true,
            composed: true,
        }));
    }

    // FIX: Removed 'override' modifier to fix build error.
    firstUpdated() {
        this._updatePrimaryAction();
    }
    
    // FIX: Removed 'override' modifier to fix build error.
    updated(changedProperties: Map<string, unknown>) {
        if(changedProperties.has('generatedRemixPlan') || changedProperties.has('isLoading')) {
            this._updatePrimaryAction();
        }
    }
    
    private _renderAnalysisSection() {
        const sourceName = this._sourceAudioFile?.name || 'No Source Selected';
        return html`
            <div class="source-info-bar">
                <span class="source-name" title=${sourceName}>Source: ${sourceName}</span>
                <div class="analysis-results">
                    ${this.analysisStatus === 'loading' ? html`<div class="analysis-item"><svg class="spinner" viewBox="0 0 50 50" width="16" height="16"><circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle></svg>Analyzing...</div>` : ''}
                    ${this.analysisStatus === 'error' ? html`<div class="analysis-item analysis-error">${this.analysisError}</div>` : ''}
                    ${this.audioAnalysis ? html`
                        <div class="analysis-item" title="Beats Per Minute"><strong>BPM:</strong> ${this.audioAnalysis.bpm.toFixed(0)}</div>
                        <div class="analysis-item" title="Musical Key"><strong>Key:</strong> ${this.audioAnalysis.key}</div>
                    ` : ''}
                </div>
            </div>
        `;
    }
    
    private _renderStemSection() {
        const stemTargets: (keyof Stems)[] = ['vocal', 'drums', 'bass', 'other'];
        return html`
            <div class="control-group">
                <h3>Remix Parameters</h3>
                <div class="row">
                    <div>
                        <label for="remix-genre-select">Target Genre</label>
                        <select id="remix-genre-select">
                            ${GENRES.map(g => html`<option value=${g}>${g}</option>`)}
                        </select>
                    </div>
                    <div>
                        <label>Featured Stems</label>
                         <div class="checkbox-group">
                            ${stemTargets.map(stem => html`
                                <label>
                                    <input type="checkbox" name="remix-target" value=${stem} checked ?disabled=${this.stemSeparationStatus !== 'success'}>
                                    ${(stem as string).charAt(0).toUpperCase() + (stem as string).slice(1)}
                                </label>
                            `)}
                        </div>
                    </div>
                </div>
                 <div class="row">
                    <div>
                        <label for="vocal-retake-lora-select">Vocal Retake Model</label>
                        <select id="vocal-retake-lora-select" ?disabled=${this.stemSeparationStatus !== 'success'}>
                             <option value="none">Keep Original Vocal</option>
                            ${(this.appContextConsumer.value?.trainedLoras.filter(l => l.type === 'vocal') ?? []).map(l => html`<option value=${l.name}>${l.name}</option>`)}
                        </select>
                        ${this.smartLoraSelection?.leadVocal ? html`<p class="sub-label" style="margin-top: 0.5rem;">Recommended: ${this.smartLoraSelection.leadVocal}</p>` : ''}
                    </div>
                    <div class="slider-container">
                        <label for="pitch-shift-slider">Pitch Shift: ${this.pitchShiftSemitones > 0 ? '+' : ''}${this.pitchShiftSemitones} st</label>
                        <input type="range" id="pitch-shift-slider" min="-12" max="12" step="1" .value=${String(this.pitchShiftSemitones)} @input=${(e: Event) => this.pitchShiftSemitones = parseInt((e.target as HTMLInputElement).value)}>
                    </div>
                </div>
                <div style="text-align: right; margin-top: 1rem;">
                    <button @click=${this._handleGeneratePlan} ?disabled=${this.analysisStatus !== 'success'}>Generate Production Plan</button>
                </div>
            </div>
        `;
    }

    // FIX: Removed 'override' modifier to fix build error.
    render() {
        return html`
            <div class="panel">
                <h2 class="page-title">Remix Station</h2>
                <div class="control-group">
                    <h3>Source Audio</h3>
                    <p class="sub-label">Load the track you want to remix, either from your current project or by uploading a new file.</p>
                    <file-link-input @file-change=${(e: CustomEvent) => this.remixSourceFile = e.detail.file}></file-link-input>
                </div>
                
                <div class="control-group">
                    <h3>Analysis & Separation</h3>
                    <p class="sub-label">Run the source audio through the intelligence layer to detect its properties and separate it into instrumental stems.</p>
                    <div style="display: flex; gap: 1rem;">
                        <button @click=${this._runAnalysis} ?disabled=${!this._sourceAudioFile}>Analyze BPM & Key</button>
                        <button @click=${this._runStemSeparation} ?disabled=${!this._sourceAudioFile}>Separate Stems</button>
                    </div>
                    ${this._renderAnalysisSection()}
                </div>
                
                ${this._renderStemSection()}

                ${this.renderProgressIndicator()}
                ${this.renderErrorMessage()}

                ${this.generatedRemixPlan ? html`
                    <div class="control-group">
                        <h3>Production Plan</h3>
                        <div class="remix-plan-container">
                            <pre>${this.generatedRemixPlan}</pre>
                        </div>
                    </div>
                ` : ''}

                ${this.isRemixGenerated ? html `
                    <div class="control-group" style="border-color: var(--color-success);">
                        <p style="color: var(--color-success); font-weight: 500;">Remix generated successfully. Check the player bar.</p>
                    </div>
                `: ''}
            </div>
        `;
    }
}