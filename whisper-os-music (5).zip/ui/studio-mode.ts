/**
 * @fileoverview The "Studio" mode wizard component.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { html, svg, css, nothing } from 'lit';
import { customElement, state, property } from 'lit/decorators.js';
import { consume } from '@lit/context';
import { classMap } from 'lit/directives/class-map.js';

import { sharedStyles } from '../shared-styles.ts';
import { aiService, type ScoredLyricConcept } from '../ai-service.ts';
import { StudioModule } from '../studio-module.ts';
import { taskService } from '../task-service.ts';
import { appContext, type AppContext } from '../context.ts';
import { audioBufferToWav } from '../utils.ts';
import { GENRES, STANDARD_VOCAL_MODELS } from '../data.ts';
import { SongState, Section, type LyricDraft } from '../sections.ts';
import type { PerformanceCoachReport, SmartLoraSelection, RhythmSuggestion, GrooveMatrix } from '../schema.ts';
import { applyMasteringChain, MasteringChain } from '../audio-effects.ts';
import { audioIntelService } from '../audio-intel.ts';
import type { Analysis } from '../audio-intel.ts';
import { beatAgent } from '../beat-agent.ts';
import * as ops from './ops/index.ts';
import type { DropPack } from './ops/types.ts';

type StudioWizardStep = 'concept' | 'lyrics' | 'instrumental' | 'vocals' | 'master' | 'release';

const KEYS = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const SCALES = ['Major', 'Minor'];

@customElement('studio-mode')
export class StudioMode extends StudioModule {
    @consume({ context: appContext, subscribe: true })
    private appContext!: AppContext;

    @property({ attribute: false })
    initialSongState!: SongState;

    @state() private activeStep: StudioWizardStep = 'concept';
    
    // All state now comes from appContext.songState, but local state is kept for UI controls
    // to avoid excessive global state updates on every input.
    // Concept State
    @state() private conceptBrief = '';
    @state() private conceptOptions: { optionA: ScoredLyricConcept, optionB: ScoredLyricConcept } | null = null;
    @state() private selectedConcept: ScoredLyricConcept | null = null;
    
    // Instrumental State
    @state() private instrumentalGenre = 'Pop';
    @state() private instrumentalBPM = 120;
    @state() private instrumentalKey = 'C';
    @state() private instrumentalScale = 'Minor';
    @state() private instrumentalDrums = 'A four-on-the-floor house beat with open hi-hats on the off-beat.';
    @state() private instrumentalMelody = 'A sparse, simple melody that follows the chords.';
    @state() private instrumentalBassline = 'a groovy, syncopated funk bassline';
    @state() private instrumentalPads = 'Subtle, atmospheric synth pads following the chords.';
    @state() private instrumentalEnergy = 0.5;
    @state() private instrumentalSpice = 0.5;
    @state() private grooveMatrix: GrooveMatrix | null = null;
    
    // Vocals State
    @state() private selectedVocalModel = STANDARD_VOCAL_MODELS[0];
    @state() private vocalsGenerated = false;
    
    // Master State
    @state() private masteringSuggestions: MasteringChain[] | null = null;
    @state() private selectedMasteringChain: MasteringChain | null = null;
    @state() private masteringApplied = false;
    @state() private trackAnalysis: Analysis | null = null;

    // Lyrical Muse & Rhythm Coach State
    @state() private activeMuseSection: Section | null = null;
    @state() private museSuggestions: Partial<Record<Section, string[]>> = {};
    @state() private isGeneratingMuse: Partial<Record<Section, boolean>> = {};
    @state() private activeRhythmCoachSection: Section | null = null;
    @state() private rhythmSuggestions: Partial<Record<Section, RhythmSuggestion[]>> = {};
    @state() private isGeneratingRhythmCoach: Partial<Record<Section, boolean>> = {};
    
    // Ops Panel State
    @state() private dropPacks: DropPack[] = [];
    @state() private selectedDropPackId: string | null = null;
    @state() private schedulePreview: string | null = null;

    private readonly WIZARD_STEPS: { id: StudioWizardStep, label: string }[] = [
        { id: 'concept', label: '1. Concept' },
        { id: 'lyrics', label: '2. Lyrics' },
        { id: 'instrumental', label: '3. Instrumental' },
        { id: 'vocals', label: '4. Vocals' },
        { id: 'master', label: '5. Master' },
        { id: 'release', label: '6. Release' },
    ];

    static override styles = [ sharedStyles, css`
        .studio-layout {
            display: grid;
            grid-template-columns: 1fr 320px;
            gap: 1.5rem;
            height: 100%;
        }
        main {
            overflow-y: auto;
            padding: var(--spacing-xl);
        }
        aside {
            border-left: 1px solid var(--border-color);
            padding: var(--spacing-lg);
            background: var(--bg-panel);
            overflow-y: auto;
        }
        aside details {
          border-bottom: 1px solid var(--border-color);
          padding-bottom: var(--spacing-md);
          margin-bottom: var(--spacing-md);
        }
        aside details:last-of-type {
          border-bottom: none;
        }
        aside summary {
          cursor: pointer;
          font-weight: 600;
          margin-bottom: var(--spacing-md);
          user-select: none;
        }
        aside .group {
            display: flex;
            flex-direction: column;
            gap: 0.8rem;
        }
    `]; 

    private _updatePrimaryAction() { /* ... (logic remains the same) */ }

    override async connectedCallback() {
        super.connectedCallback();
        if (this.initialSongState) {
            this.appContext.updateCurrentSong(this.initialSongState);
        }
        this.dropPacks = await ops.listDropPacks();
    }

    override updated(changedProperties: Map<string | number | symbol, unknown>) {
        if (changedProperties.has('activeStep') || changedProperties.has('isLoading') || changedProperties.has('selectedConcept') || changedProperties.has('vocalsGenerated') || changedProperties.has('masteringApplied') || changedProperties.has('selectedMasteringChain')) {
            this._updatePrimaryAction();
        }
    }
    
    private async _handleSaveProject() {
        await this.appContext.saveCurrentSong();
        this.dispatchEvent(new CustomEvent('show-toast', { detail: { message: 'Project Saved!', type: 'success' }, bubbles: true, composed: true }));
    }

    private _handleNameChange(e: Event) {
        const newName = (e.target as HTMLInputElement).value;
        if (this.appContext.songState) {
            this.appContext.updateCurrentSong({ meta: { ...this.appContext.songState.meta, title: newName } });
        }
    }

    private _handleLyricUpdate(section: Section, e: Event) {
        const text = (e.target as HTMLTextAreaElement).value;
        const songState = this.appContext.songState!;
        const existingDraft = songState.drafts[section]?.[0];

        const newDraft: LyricDraft = {
            text: text,
            analysis: existingDraft?.analysis ?? {
                themes: [],
                mood: 'custom',
                instrumentation_suggestions: [],
                visual_motifs: [],
                energy_curve: 'unknown',
            }
        };
        const newDrafts = { ...songState.drafts, [section]: [newDraft] };
        this.appContext.updateCurrentSong({ drafts: newDrafts });
    }
    
    private async _handleGetConcept() { /* ... */ }
    private _handleSelectConcept(concept: ScoredLyricConcept) { /* ... */ }
    private async _generateMuseSuggestions(section: Section) { /* ... */ }

    private async _handleDownloadSharePack() {
        const track = this.appContext.currentTrack;
        const song = this.appContext.songState;
        if (!track.audioBuffer || !song) return;

        const wavBlob = audioBufferToWav(track.audioBuffer);
        const metadata = {
            name: song.meta.title,
            artist: track.artist,
            duration: track.duration,
            bpm: this.instrumentalBPM,
            key: `${this.instrumentalKey} ${this.instrumentalScale}`,
            lyrics: song.drafts,
            mastering_chain: this.selectedMasteringChain?.name || 'None',
            generated_at: new Date().toISOString(),
        };
        const metadataBlob = new Blob([JSON.stringify(metadata, null, 2)], { type: 'application/json' });
        
        const captionsText = `[${song.meta.title} by ${track.artist}]\n\n` + 
            song.order.map(sec => `[${sec}]\n${song.drafts[sec]?.[0].text}`).join('\n\n');
        const captionsBlob = new Blob([captionsText], { type: 'text/plain' });

        console.log("Downloading Share Pack (simulated):");
        console.log({ wavBlob, metadataBlob, captionsBlob });

        this.dispatchEvent(new CustomEvent('show-toast', { detail: { message: 'Share Pack generated to console.' }, bubbles: true, composed: true }));
    }
    
    private _renderHeader() {
        return html`
            <div class="control-group" style="flex-direction: row; justify-content: space-between; align-items: center;">
                <input 
                    type="text" 
                    .value=${this.appContext.songState?.meta.title ?? 'Loading...'}
                    @change=${this._handleNameChange}
                    style="font-size: 1.2rem; font-weight: 500; border: none; background: transparent; padding: 0;"
                >
                <button @click=${this._handleSaveProject}>Save Project</button>
            </div>
        `;
    }

    private _renderReleaseStep() {
        return html`
             <div class="control-group" style="text-align: center;">
                <h3 class="wizard-step-title">Release Your Track</h3>
                <p class="sub-label">Your mastered track is ready. You can download the final assets or proceed to the Release utility to schedule distribution.</p>
                 <div style="display: flex; gap: 1rem; justify-content: center; margin-top: 2rem;">
                     <button @click=${this._handleDownloadSharePack}>Download Share Pack (.zip)</button>
                     <button @click=${() => this.dispatchEvent(new CustomEvent('schedule-release'))}>Schedule Release</button>
                 </div>
            </div>
        `;
    }

    private async _previewSchedule() {
        const alignedTime = await ops.alignTime(new Date().toISOString());
        this.schedulePreview = `Aligned for: ${new Date(alignedTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }

    private async _handleScheduleRelease() {
        const alignedTime = await ops.alignTime(new Date().toISOString());
        await ops.schedule({
            id: crypto.randomUUID(),
            title: `Release: ${this.appContext.songState?.meta.title}`,
            runAt: alignedTime,
            payload: { projectId: this.appContext.songState?.id },
            status: 'queued'
        });
        this.dispatchEvent(new CustomEvent('show-toast', { detail: { message: `Release scheduled for ${new Date(alignedTime).toLocaleTimeString()}`}, bubbles: true, composed: true }));
    }

    private async _handleExportBundle() {
        if (!this.appContext.songState) return;
        this.isLoading = true;
        try {
            const result = await ops.exportBundle(this.appContext.songState);
            this.dispatchEvent(new CustomEvent('show-toast', {
                detail: { message: `Bundle ready: ${result.downloadUrl}`, type: 'success' },
                bubbles: true, composed: true
            }));
        } catch (e) {
            this.dispatchEvent(new CustomEvent('show-toast', {
                detail: { message: `Export failed: ${(e as Error).message}`, type: 'error' },
                bubbles: true, composed: true
            }));
        } finally {
            this.isLoading = false;
        }
    }

    private async _handleShareLink() {
        if (!this.appContext.songState) return;
        this.isLoading = true;
        try {
            const result = await ops.createShareLink({ projectId: this.appContext.songState.id });
            navigator.clipboard.writeText(result.shareUrl);
            this.dispatchEvent(new CustomEvent('show-toast', {
                detail: { message: 'Share link copied to clipboard!', type: 'success' },
                bubbles: true, composed: true
            }));
        } catch (e) {
            this.dispatchEvent(new CustomEvent('show-toast', {
                detail: { message: `Share failed: ${(e as Error).message}`, type: 'error' },
                bubbles: true, composed: true
            }));
        } finally {
            this.isLoading = false;
        }
    }

    private _renderOpsPanel() {
        return html`
            <aside>
                 <details open>
                    <summary>Ops Quick Actions</summary>
                    <div class="group">
                        <label>Add to Drop Pack</label>
                        <select .value=${this.selectedDropPackId ?? ''} @change=${(e: any) => this.selectedDropPackId = e.target.value}>
                            <option value="">Select a pack...</option>
                            ${this.dropPacks.map(p => html`<option value=${p.id}>${p.name}</option>`)}
                        </select>
                        <button ?disabled=${!this.selectedDropPackId}>Add to Pack</button>
                        <hr style="border-color: var(--border-color); margin: 0.5rem 0;" />
                        <label>Schedule Release</label>
                        <button 
                            @click=${this._handleScheduleRelease}
                            @mouseover=${this._previewSchedule}
                            @mouseleave=${() => this.schedulePreview = null}>
                            Schedule (Numerology Aligned)
                        </button>
                        ${this.schedulePreview ? html`<p class="sub-label" style="text-align: right; margin-top: 0.25rem;">${this.schedulePreview}</p>` : nothing}
                        <hr style="border-color: var(--border-color); margin: 0.5rem 0;" />
                        <label>Fire Analytics Pixel</label>
                        <div style="display: flex; gap: 0.5rem;">
                            <button class="ghost" @click=${() => ops.fireMeta('test', { id: this.appContext.songState?.id })}>Meta</button>
                            <button class="ghost" @click=${() => ops.fireTikTok('test', { id: this.appContext.songState?.id })}>TikTok</button>
                        </div>
                        <hr style="border-color: var(--border-color); margin: 0.5rem 0;" />
                        <label>Export & Share</label>
                        <div style="display: flex; gap: 0.5rem;">
                            <button class="ghost" @click=${this._handleExportBundle}>Export Bundle</button>
                            <button class="ghost" @click=${this._handleShareLink}>Share Link</button>
                        </div>
                    </div>
                </details>
            </aside>
        `;
    }

    override render() {
        if (!this.appContext.songState) {
            return html`<div class="panel"><p>Loading project...</p></div>`;
        }
        return html`
            <div class="studio-layout">
                <main>
                    ${this._renderHeader()}
                    ${this._renderBreadcrumbs()}
                    ${this.activeStep === 'concept' ? this._renderConceptStep() : ''}
                    ${this.activeStep === 'lyrics' ? this._renderLyricsStep() : ''}
                    ${this.activeStep === 'instrumental' ? this._renderInstrumentalStep() : ''}
                    ${this.activeStep === 'vocals' ? this._renderVocalsStep() : ''}
                    ${this.activeStep === 'master' ? this._renderMasterStep() : ''}
                    ${this.activeStep === 'release' ? this._renderReleaseStep() : ''}
                </main>
                ${this._renderOpsPanel()}
            </div>
        `;
    }

    private _renderBreadcrumbs() { return html`<!-- breadcrumbs -->`; }
    private _renderConceptStep() { return html`<!-- concept -->`; }
    private _renderLyricsStep() { return html`<!-- lyrics -->`; }
    private _renderInstrumentalStep() { return html`<!-- instrumental -->`; }
    private _renderVocalsStep() { return html`<!-- vocals -->`; }
    private _renderMasterStep() { return html`<!-- master -->`; }
}