import type { CreativeAgent, OrchestratorContext, AgentIO } from "../core/types.ts";
import type { LyricsDraftResponse } from '../sections.ts';

export const SongwriterAgent: CreativeAgent = {
  name: "songwriter",
  consumes: ["title", "genre", "project"],
  produces: ["lyrics.draft", "lyrics.analysis"],
  async run(input: AgentIO, ctx: OrchestratorContext): Promise<AgentIO> {
    const llm = await ctx.getModel("llm");
    const prompt = `A song titled "${input.title}" with a genre of ${input.genre}`;
    
    const out = await llm.generate({
        prompt,
        energy: 'high',
        rhyme: 'medium',
        syllables: 12,
        rhymeScheme: 'ABAB'
    }) as LyricsDraftResponse;

    const bestDraft = out.drafts[0];
    if (!bestDraft) throw new Error('SongwriterAgent failed to produce a draft.');

    ctx.setBlackboard("lyrics.draft", bestDraft.text);
    ctx.setBlackboard("lyrics.analysis", bestDraft.analysis);

    return {
      "lyrics.draft": bestDraft.text,
      "lyrics.analysis": bestDraft.analysis,
    };
  }
};