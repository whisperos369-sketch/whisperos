import type { CreativeAgent, AgentIO, OrchestratorContext } from "../core/types.ts";
import type { LyricDraftAnalysis } from "../sections.ts";

export const GrooveSurgeonAgent: CreativeAgent = {
  name: "groove-surgeon",
  consumes: ["lyrics.analysis"],
  produces: ["composition.grooveParams"],
  async run(input: AgentIO, _ctx: OrchestratorContext): Promise<AgentIO> {
    console.log("[Groove Surgeon] Defining groove parameters...");
    await new Promise(r => setTimeout(r, 500));
    const analysis = input["lyrics.analysis"] as LyricDraftAnalysis;
    
    // This would be derived from a more complex model in a real scenario.
    const grooveParams = {
        swing: analysis.mood.includes("hip-hop") ? 0.6 : 0.5,
        syncopationLevel: analysis.energy_curve.includes("high") ? 0.7 : 0.4,
        humanization: 0.05, // 5% timing variation
    };

    return { "composition.grooveParams": grooveParams };
  }
};
