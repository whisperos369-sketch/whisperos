import type { CreativeAgent, AgentIO, OrchestratorContext } from "../core/types.ts";
import type { SongState, LyricDraftAnalysis } from '../sections.ts';

export const VisualsAgent: CreativeAgent = {
  name: "visuals",
  consumes: ["master.url", "lyrics.analysis", "project"],
  produces: ["video.url", "cover.url", "cover.score"],
  async run(input: AgentIO, ctx: OrchestratorContext): Promise<AgentIO> {
    const vision = await ctx.getModel("vision");
    const video = await ctx.getModel("video");

    const project = input['project'] as SongState;
    const analysis = input['lyrics.analysis'] as LyricDraftAnalysis;
    const masterUrl = input['master.url'] as string;

    const coverPrompt = `An abstract album cover for a ${analysis.mood} song titled "${project.meta.title}" about ${analysis.themes.join(', ')}. Visually, it should incorporate motifs of ${analysis.visual_motifs.join(', ')}. Style: dark, cinematic.`;

    const coverResult = await vision.generate({
        prompt: coverPrompt,
        numImages: 4,
        loras: project.loraStack.filter(l => l.path.includes('visual')),
    }) as {images: {url: string, score: number}[], pickedUrl: string};
    
    const videoResult = await video.generate({
        audioUrl: masterUrl,
        imageUrl: coverResult.pickedUrl,
        template: 'spectrum',
    }) as {videoUrl: string};

    const bestImage = coverResult.images.find(img => img.url === coverResult.pickedUrl);

    return {
        "video.url": videoResult.videoUrl,
        "cover.url": coverResult.pickedUrl,
        "cover.score": bestImage?.score ?? 0,
    };
  }
};