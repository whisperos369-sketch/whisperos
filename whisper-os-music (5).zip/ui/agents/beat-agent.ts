import type { CreativeAgent, AgentIO, OrchestratorContext } from "../core/types.ts";
import type { SongState, LyricDraftAnalysis } from '../sections.ts';

export const BeatAgent: CreativeAgent = {
  name: "beat",
  consumes: ["lyrics.analysis", "project", "arrangement.plan"],
  produces: ["beat.url"],
  async run(input: AgentIO, ctx: OrchestratorContext): Promise<AgentIO> {
    const music = await ctx.getModel("musicgen");
    const analysis = input['lyrics.analysis'] as LyricDraftAnalysis;
    const project = input['project'] as SongState;
    const plan = input['arrangement.plan'] as string[] || [];

    const prompt = `Music for a ${analysis.mood} song titled "${project.meta.title}" about ${analysis.themes.join(', ')}. Key features should include ${analysis.instrumentation_suggestions.join(', ')}. The song's energy should be: ${analysis.energy_curve}. Style: ${project.meta.key}. The structure is: ${plan.join(', ')}.`;

    const res = await music.generate({
        prompt,
        negative: 'muddy mix, harsh highs',
        duration: project.meta.duration,
        bpm: project.meta.bpm,
        key: project.meta.key,
        seed: project.generators.seed,
        temp: project.generators.temperature,
        topK: project.generators.topK,
        topP: project.generators.topP,
        base: project.generators.baseModel,
        loras: project.loraStack,
    }) as { url: string };

    return { "beat.url": res.url };
  }
};