import { registerAgent } from "../core/agent-registry.ts";
import { SongwriterAgent } from "./songwriter-agent.ts";
import { BeatAgent } from "./beat-agent.ts";
import { MixingAgent } from "./mixing-agent.ts";
import { MasteringAgent } from "./mastering-agent.ts";
import { VisualsAgent } from "./visuals-agent.ts";
import { EvaluationAgent } from "./evaluation-agent.ts";
import { HookArchitectAgent } from "./hook-architect-agent.ts";
import { GrooveSurgeonAgent } from "./groove-surgeon-agent.ts";
import { EmotionalConductorAgent } from "./emotional-conductor-agent.ts";
import { SpatialSoundArchitectAgent } from "./spatial-sound-architect-agent.ts";
import { ArrangementAgent } from "./arrangement-agent.ts";

export function registerAllAgents(){
  [
    SongwriterAgent, 
    ArrangementAgent,
    HookArchitectAgent,
    EmotionalConductorAgent,
    GrooveSurgeonAgent,
    BeatAgent, 
    MixingAgent,
    SpatialSoundArchitectAgent,
    MasteringAgent, 
    VisualsAgent, 
    EvaluationAgent
  ].forEach(registerAgent);
}