import type { CreativeAgent, AgentIO, OrchestratorContext } from "../core/types.ts";
import type { LyricDraftAnalysis } from "../sections.ts";

export const EmotionalConductorAgent: CreativeAgent = {
  name: "emotional-conductor",
  consumes: ["lyrics.analysis", "project.order"],
  produces: ["composition.emotionMap"],
  async run(input: AgentIO, _ctx: OrchestratorContext): Promise<AgentIO> {
    console.log("[Emotional Conductor] Mapping emotional arc...");
    await new Promise(r => setTimeout(r, 500));
    const analysis = input["lyrics.analysis"] as LyricDraftAnalysis;
    const order = input["project.order"] as string[];

    const emotionMap: Record<string, { energy: number, valence: number }> = {};
    let currentEnergy = 0.5;

    order.forEach(section => {
        if (section.includes("chorus")) {
            currentEnergy = Math.min(1.0, currentEnergy + 0.2);
        } else if (section.includes("bridge")) {
            currentEnergy = Math.max(0.2, currentEnergy - 0.3);
        }
        emotionMap[section] = {
            energy: currentEnergy,
            valence: analysis.mood === 'upbeat' ? 0.7 : 0.4,
        };
    });
    
    return { "composition.emotionMap": emotionMap };
  }
};
