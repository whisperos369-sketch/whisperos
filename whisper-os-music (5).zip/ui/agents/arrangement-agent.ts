import type { CreativeAgent, AgentIO, OrchestratorContext } from "../core/types.ts";
import type { LyricDraft } from "../sections.ts";

export const ArrangementAgent: CreativeAgent = {
  name: "arrangement",
  consumes: ["lyrics.draft"],
  produces: ["arrangement.plan"],
  async run(input: AgentIO, _ctx: OrchestratorContext): Promise<AgentIO> {
    console.log("[ArrangementAgent] Structuring song from lyrics...");
    await new Promise(r => setTimeout(r, 700)); // Simulate analysis

    const lyrics = input["lyrics.draft"] as string || "";
    
    // Simple heuristic to create an arrangement plan
    const plan: string[] = ['intro'];
    const lines = lyrics.toLowerCase().split('\n');
    let verseCount = 1;
    let chorusCount = 1;
    let bridgeCount = 1;

    for (const line of lines) {
        if (line.includes('[verse')) {
            plan.push(`verse${verseCount++}`);
        } else if (line.includes('[chorus')) {
            plan.push(`chorus${chorusCount++}`);
        } else if (line.includes('[bridge')) {
            plan.push(`bridge${bridgeCount++}`);
        }
    }
    
    // If no sections were found, create a default structure
    if (plan.length === 1) {
        plan.push('verse1', 'chorus1', 'verse2', 'chorus2');
    }

    plan.push('outro');

    console.log(`[ArrangementAgent] Generated plan: ${plan.join(', ')}`);

    return { "arrangement.plan": plan };
  }
};
