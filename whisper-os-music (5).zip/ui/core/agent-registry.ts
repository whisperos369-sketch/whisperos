/**
 * @fileoverview A registry for managing creative agents.
 */
import type { CreativeAgent } from "./types.ts";
const registry = new Map<string, CreativeAgent>();
export function registerAgent(a: CreativeAgent){ registry.set(a.name, a); }
export function getAgent(name: string){
  const a = registry.get(name);
  if (!a) throw new Error(`Agent not found: ${name}`);
  return a;
}
export function listAgents(){ return Array.from(registry.values()); }