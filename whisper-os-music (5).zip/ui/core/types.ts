/**
 * @fileoverview Central type definitions for the new architecture.
 */
export type AgentIO = Record<string, unknown>;

export interface CreativeAgent {
  name: string;
  consumes: string[];   // e.g., ["lyrics.draft"]
  produces: string[];   // e.g., ["beat.stem"]
  run(input: AgentIO, ctx: OrchestratorContext): Promise<AgentIO>;
}

export interface OrchestratorContext {
  emit: (event: OrchestratorEvent) => void;
  getModel: (key: string) => Promise<ModelAdapter>;
  setBlackboard: (k: string, v: unknown) => void;
  getBlackboard: <T=unknown>(k: string) => T|undefined;
}

export type OrchestratorEvent =
  | { type: "STEP_STARTED"; agent: string }
  | { type: "STEP_FINISHED"; agent: string; outputKeys: string[] }
  | { type: "EVALUATION_READY"; score: number; notes: string[] }
  | { type: "RELOOP_TRIGGERED"; reason: string }
  | { type: "ERROR"; agent?: string; message: string };

export interface ModelAdapter {
  id: string;
  kind: "music"|"text"|"voice"|"vision";
  generate: (params: Record<string, unknown>) => Promise<unknown>;
}