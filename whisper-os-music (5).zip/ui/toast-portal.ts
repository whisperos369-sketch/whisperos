/**
 * @fileoverview A portal for displaying toast notifications.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {html, css, LitElement} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {repeat} from 'lit/directives/repeat.js';

type ToastType = 'info' | 'success' | 'error';
type Toast = {
    id: number;
    message: string;
    type: ToastType;
};

@customElement('toast-portal')
export class ToastPortal extends LitElement {
    @state() private toasts: Toast[] = [];
    private nextId = 0;

    // FIX: Removed 'override' modifier to fix build error.
    static styles = css`
        .toast-container {
            position: fixed;
            bottom: var(--player-height, 110px);
            right: 1rem;
            z-index: 9999;
            display: flex;
            flex-direction: column-reverse;
            gap: 0.5rem;
            align-items: flex-end;
        }
        .toast {
            padding: 1rem 1.5rem;
            border-radius: 8px;
            color: white;
            font-size: 0.9rem;
            font-weight: 500;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            background: var(--bg-panel-solid);
            animation: slide-in 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            opacity: 1;
            transform: translateY(0);
        }
        .toast.success { background-color: var(--color-success); color: var(--bg-main); }
        .toast.error { background-color: var(--color-error); }
        
        @keyframes slide-in {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    `;

    public addToast(message: string, type: ToastType = 'info', duration = 3000) {
        const id = this.nextId++;
        this.toasts = [...this.toasts, { id, message, type }];
        setTimeout(() => this.removeToast(id), duration);
    }

    private removeToast(id: number) {
        this.toasts = this.toasts.filter(toast => toast.id !== id);
    }

    // FIX: Removed 'override' modifier to fix build error.
    render() {
        return html`
            <div class="toast-container">
                ${repeat(this.toasts, (toast) => toast.id, (toast) => html`
                    <div class="toast ${toast.type}">${toast.message}</div>
                `)}
            </div>
        `;
    }
}