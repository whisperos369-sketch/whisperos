/**
 * @fileoverview A professional, persistent media player component.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {html, css, LitElement, svg, nothing} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {consume} from '@lit/context';

import {appContext, AppContext} from '../context.ts';
import {formatDuration} from '../utils.ts';
import {sharedStyles} from '../shared-styles.ts';
import '../volume-control.ts';

@customElement('media-player')
export class MediaPlayer extends LitElement {
    @consume({context: appContext, subscribe: true})
    private _app!: AppContext;
    
    @state() private waveformPeaks: number[][] | null = null;
    @state() private isWaveformReady = false;

    private waveformWorker: Worker | null = null;
    private canvas!: HTMLCanvasElement;
    private lastBuffer: AudioBuffer | null = null;
    
    static override styles = [sharedStyles, css`
        :host {
            display: block;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: var(--player-height);
            background: var(--bg-panel);
            backdrop-filter: var(--backdrop-blur);
            -webkit-backdrop-filter: var(--backdrop-blur);
            border-top: 1px solid var(--border-color);
            z-index: 20;
            padding: 1rem 1.5rem;
            display: grid;
            grid-template-columns: 1fr 2fr 1fr;
            align-items: center;
            gap: 1.5rem;
        }

        .track-info { display: flex; align-items: center; gap: 1rem; }
        .cover-art { width: 60px; height: 60px; border-radius: 4px; background-color: var(--bg-input); overflow: hidden; }
        .cover-art img { width: 100%; height: 100%; object-fit: cover; }
        .title-artist h4 { margin: 0; font-weight: 500; }
        .title-artist p { margin: 0; font-size: 0.8rem; color: var(--text-secondary); }

        .transport-controls { display: flex; flex-direction: column; align-items: center; gap: 0.5rem; }
        .main-controls { display: flex; align-items: center; gap: 1rem; }
        .play-button { width: 48px; height: 48px; border-radius: 50%; background-color: var(--accent-primary); color: var(--bg-main); }
        .play-button:hover { background-color: var(--accent-primary-hover); }

        .time-and-waveform { width: 100%; display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 0.8rem; }
        .timecode { font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-secondary); }
        .waveform-container { position: relative; height: 50px; cursor: pointer; }
        .waveform-canvas { width: 100%; height: 100%; display: block; }
        .meta-controls { display: flex; justify-content: flex-end; align-items: center; gap: 1rem; }
        .kv { display: flex; align-items: center; gap: 0.5rem; }
        .kv label { margin: 0; font-size: 0.8rem; }
        .kv input, .kv select { padding: 4px 8px; font-size: 0.8rem; width: 80px; }
    `];
    
    override firstUpdated() {
        this.canvas = this.shadowRoot!.querySelector('.waveform-canvas')!;
        this.waveformWorker = new Worker(new URL('../ui/waveform-worker.ts', import.meta.url), { type: 'module' });
        this.waveformWorker.onmessage = (e) => {
            this.waveformPeaks = e.data.peaks;
            this.isWaveformReady = true;
            this._drawWaveform();
        };
        
        const resizeObserver = new ResizeObserver(() => this._drawWaveform());
        resizeObserver.observe(this.canvas);
    }

    override disconnectedCallback(): void {
        super.disconnectedCallback();
        this.waveformWorker?.terminate();
    }
    
    override willUpdate(changed: Map<string, any>) {
        if (this._app) {
            const track = this._app.currentTrack;
            if (track.audioBuffer && track.audioBuffer !== this.lastBuffer) {
                this.lastBuffer = track.audioBuffer;
                this._processWaveform(track.audioBuffer);
            }
            if (!track.audioBuffer) {
                this.waveformPeaks = null;
                this.isWaveformReady = false;
            }
        }
    }

    override updated(changed: Map<string, any>) {
        if (changed.has('_app') && this._app) {
            requestAnimationFrame(() => this._drawWaveform());
        }
    }
    
    private _processWaveform(buffer: AudioBuffer) {
        if (!this.waveformWorker) return;
        this.isWaveformReady = false;
        const targetPeakCount = Math.min(4096, Math.max(1024, Math.floor(buffer.duration * 10)));
        const channelData = buffer.getChannelData(0);
        this.waveformWorker.postMessage({ channelData: channelData.buffer, targetPeakCount }, [channelData.buffer]);
    }

    private _drawWaveform() {
        if (!this.canvas || !this._app) return;
        const ctx = this.canvas.getContext('2d')!;
        const { width, height } = this.canvas.getBoundingClientRect();
        this.canvas.width = width * devicePixelRatio;
        this.canvas.height = height * devicePixelRatio;
        ctx.scale(devicePixelRatio, devicePixelRatio);
        ctx.clearRect(0, 0, width, height);

        if (!this.isWaveformReady || !this.waveformPeaks) return;

        const peaks = this.waveformPeaks;
        const numPeaks = peaks.length;
        const barWidth = width / numPeaks;
        const midY = height / 2;
        
        ctx.fillStyle = getComputedStyle(this).getPropertyValue('--text-tertiary');
        for (let i = 0; i < numPeaks; i++) {
            const [min, max] = peaks[i];
            const barHeight = (max - min) * midY;
            ctx.fillRect(i * barWidth, midY - (max * midY), barWidth * 0.8, barHeight);
        }

        const progress = this._app.currentTime / this._app.currentTrack.duration;
        const playheadX = width * progress;
        ctx.fillStyle = getComputedStyle(this).getPropertyValue('--accent-primary');
        ctx.fillRect(playheadX, 0, 2, height);
    }
    
    override render() {
        if (!this._app || !this._app.songState) return nothing;
        const { meta } = this._app.songState;
        const { currentTrack, isPlaying, currentTime } = this._app;
        
        return html`
            <div class="track-info">
                <div class="cover-art">
                    ${currentTrack.coverArtUrl ? html`<img src=${currentTrack.coverArtUrl} alt="Cover Art">` : nothing}
                </div>
                <div class="title-artist">
                    <h4>${currentTrack.title || 'Untitled'}</h4>
                    <p>${currentTrack.artist || 'Unknown Artist'}</p>
                </div>
            </div>
            <div class="transport-controls">
                <div class="main-controls">
                     <button class="icon-button" title="Previous Marker">${svg`<svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/></svg>`}</button>
                    <button class="icon-button play-button" @click=${this._app.togglePlay} title=${isPlaying ? 'Pause' : 'Play'}>
                        ${isPlaying 
                            ? svg`<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M14 19h4V5h-4v14zm-6 0h4V5H8v14z"/></svg>`
                            : svg`<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>`
                        }
                    </button>
                    <button class="icon-button" title="Next Marker">${svg`<svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M16 6h2v12h-2zm-3.5 6l-8.5 6V6z"/></svg>`}</button>
                </div>
                <div class="time-and-waveform">
                    <span class="timecode">${formatDuration(currentTime)}</span>
                    <div class="waveform-container">
                        <canvas class="waveform-canvas"></canvas>
                    </div>
                    <span class="timecode">${formatDuration(currentTrack.duration)}</span>
                </div>
            </div>
            <div class="meta-controls">
                 <div class="kv">
                    <label>BPM</label><input type="number" .value=${String(meta.bpm)} @change=${(e:any)=>{ this._app.updateCurrentSong({ meta: {...meta, bpm: Number(e.target.value)} })}}/>
                    <label>Key</label>
                    <select .value=${meta.key} @change=${(e:any)=>{ this._app.updateCurrentSong({ meta: {...meta, key: e.target.value} })}}>
                        ${['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'].map(k => html`<option>${k}</option>`)}
                    </select>
                </div>
                <volume-control></volume-control>
            </div>
        `;
    }
}
