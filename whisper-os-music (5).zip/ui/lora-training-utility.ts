/**
 * @fileoverview The "LoRA Training" utility component.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { html, svg, css } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { ContextConsumer } from '@lit/context';
import { classMap } from 'lit/directives/class-map.js';

import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';
import { appContext, Lora } from '../context.ts';
import { AIError } from '@/ai-service.ts';
import { taskService } from '../task-service.ts';
import { beatAgent } from '../beat-agent.ts';

// Import the new file input component
import './file-link-input.ts';

type LogEntry = {
    level: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR';
    msg: string;
};

type LoraTrainingType = 'sound' | 'vocal';

@customElement('lora-training-utility')
export class LoraTrainingUtility extends StudioModule {
    private appContextConsumer = new ContextConsumer(this, {context: appContext, subscribe: true});

    @state() private isDragOver = false;
    @state() private datasetFiles: File[] = [];
    @state() private datasetUrl = '';
    @state() private trainingLogs: LogEntry[] = [];
    @state() private trainingType: LoraTrainingType = 'sound';
    @state() private isProcessingFiles = false;
    
    // LoRA Test Modal State
    @state() private showTestModal = false;
    @state() private testingLora: Lora | null = null;
    @state() private isGeneratingTestSample = false;
    @state() private testLoraTemperature = 0.7;
    @state() private testLoraGuidanceScale = 7.5;
    
    @query('#lora-training-section') private loraTrainingSection!: HTMLElement;

    private _triggerFileInputClick() {
        this.shadowRoot?.querySelector<HTMLInputElement>('#dataset-upload')?.click();
    }

    static override styles = [
        sharedStyles,
        css`
            .file-processing-indicator {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                color: var(--text-tertiary);
                font-size: 0.8rem;
                padding: 0.8rem 0 0.5rem;
            }
            .spinner {
                animation: rotate 2s linear infinite;
            }
            @keyframes rotate {
                100% { transform: rotate(360deg); }
            }
            .spinner .path {
                stroke: currentColor;
                stroke-linecap: round;
                animation: dash 1.5s ease-in-out infinite;
            }
            @keyframes dash {
                0% { stroke-dasharray: 1, 150; stroke-dashoffset: 0; }
                50% { stroke-dasharray: 90, 150; stroke-dashoffset: -35; }
                100% { stroke-dasharray: 90, 150; stroke-dashoffset: -124; }
            }
            .lora-list {
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
            }
            .lora-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0.8rem 1rem;
                background-color: var(--bg-input);
                border-radius: 8px;
                border: 1px solid var(--border-color);
            }
            .lora-item-actions {
                display: flex;
                gap: 0.5rem;
            }
            .lora-item-actions button {
                font-size: 0.8rem;
                padding: 0.4rem 0.8rem;
            }
            .lora-type {
                color: var(--text-tertiary);
                font-size: 0.8rem;
            }
            .drop-zone {
                border: 2px dashed var(--border-color);
                border-radius: 12px;
                padding: 2rem;
                text-align: center;
                cursor: pointer;
                transition: all 0.2s;
                color: var(--text-tertiary);
                background-color: var(--bg-input);
            }
            .drop-zone.drag-over, .drop-zone:hover {
                border-color: var(--accent-primary);
                background-color: var(--glow-color);
                color: var(--text-primary);
            }
            .file-list-container {
                margin-top: 1rem;
                max-height: 150px;
                overflow-y: auto;
                padding: 0.5rem;
                background: var(--bg-sidebar);
                border-radius: 8px;
            }
            .file-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0.5rem;
                font-size: 0.85rem;
                border-bottom: 1px solid var(--border-color);
            }
            .file-item:last-child {
                border-bottom: none;
            }
            .remove-file-btn {
              background: none;
              border: none;
              color: var(--text-tertiary);
              cursor: pointer;
            }
            .remove-file-btn:hover {
              color: var(--color-error);
            }
        `
    ];

    private _updatePrimaryAction() {
        let disabled = this.isLoading || this.isProcessingFiles;
        let action = this._handleTrain.bind(this);
        let label = 'Start Training';

        const nameInput = this.shadowRoot?.querySelector<HTMLInputElement>('#lora-name-input');
        const hasDataset = this.datasetFiles.length > 0 || this.datasetUrl.trim() !== '';
        if (!hasDataset || !nameInput?.value.trim()) {
            disabled = true;
        }

        this.dispatchEvent(new CustomEvent('primary-action-update', {
            detail: { label, action, disabled },
            bubbles: true,
            composed: true,
        }));
    }

    override updated(changedProperties: Map<string | number | symbol, unknown>) {
        if (changedProperties.has('isLoading') || changedProperties.has('datasetFiles') || changedProperties.has('datasetUrl') || changedProperties.has('isProcessingFiles')) {
            this._updatePrimaryAction();
        }
    }
    
    private async _handleTrain() {
        this.errorMessage = '';
        this.isLoading = true;
        
        const nameInput = this.shadowRoot!.querySelector('#lora-name-input') as HTMLInputElement;
        const epochsInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-epochs-input');
        const totalEpochs = parseInt(epochsInput?.value ?? '10', 10);
        const modelName = nameInput.value;
        const isRetraining = this.appContextConsumer.value?.trainedLoras.some(l => l.name === modelName);
        
        const taskId = taskService.addTask(
            `Train LoRA: ${modelName}`,
            [
                { message: 'Initializing & Validating Dataset...' },
                ...Array.from({ length: totalEpochs }, (_, i) => ({ message: `Training Epoch ${i + 1}/${totalEpochs}` })),
                { message: 'Finalizing and saving model...' }
            ]
        );
        this.currentTaskId = taskId;

        try {
            // Stage 1: Validation
            taskService.updateTask(taskId, { status: 'running', statusMessage: 'Validating dataset...' });
            await new Promise(r => setTimeout(r, 2000)); // Simulate validation
            if (Math.random() < 0.1) throw new AIError('Dataset validation failed: Contains unsupported file types or is corrupted.');
            
            const task = taskService.getTask(taskId)!;
            task.stages[0].status = 'complete';
            taskService.updateTask(taskId, { stages: task.stages, progress: 5 });

            // Stage 2: Training Loop
            for (let i = 1; i <= totalEpochs; i++) {
                const currentEpochStage = task.stages[i];
                currentEpochStage.status = 'running';
                
                const loss = 0.8 / (i + Math.random()) + Math.random() * 0.1;
                const eta = totalEpochs - i;
                const statusMessage = `Epoch ${i}/${totalEpochs}: Loss: ${loss.toFixed(4)}, ETA: ~${eta}m`;
                
                taskService.updateTask(taskId, {
                    stages: task.stages,
                    statusMessage: statusMessage,
                    progress: 5 + (i / totalEpochs) * 90
                });
                
                await new Promise(r => setTimeout(r, 1000)); // Simulate epoch
                currentEpochStage.status = 'complete';
            }
            
            // Stage 3: Finalizing
            const finalStage = task.stages[task.stages.length - 1];
            finalStage.status = 'running';
            taskService.updateTask(taskId, { stages: task.stages, statusMessage: 'Finalizing model...' });
            await new Promise(r => setTimeout(r, 1500));
            finalStage.status = 'complete';

            taskService.updateTask(taskId, { status: 'complete', progress: 100, statusMessage: 'Training complete.' });
            
            // Dispatch update event to app context
            const lrInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-lr-input');
            const batchSizeInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-batch-size-input');
            const stepsInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-steps-input');
            this.dispatchEvent(new CustomEvent('add-or-update-lora', {
                detail: {
                    name: nameInput.value,
                    epochs: totalEpochs,
                    baseModel: 'base_model_v1',
                    type: this.trainingType,
                    learningRate: lrInput?.value,
                    batchSize: batchSizeInput?.value ? parseInt(batchSizeInput.value) : undefined,
                    steps: stepsInput?.value ? parseInt(stepsInput.value) : undefined,
                },
                bubbles: true, composed: true
            }));

        } catch (e) {
            const message = (e as Error).message;
            this.errorMessage = message;
            taskService.updateTask(taskId, { status: 'failed', error: message });
        } finally {
            this.isLoading = false;
            this.currentTaskId = null;
            this._updatePrimaryAction();
        }
    }
    
    private async _processAndAddFiles(files: FileList | File[]) {
        const audioContext = this.appContextConsumer.value?.audioContext;
        if (!audioContext) {
            this.errorMessage = 'Audio context not available for file validation.';
            return;
        }

        this.isProcessingFiles = true;
        this.statusMessage = 'Validating audio files...';
        this.errorMessage = '';
        this.datasetUrl = ''; // Clear URL if files are being added.

        const newFiles: File[] = [];
        let invalidFileCount = 0;

        for (const file of Array.from(files)) {
            try {
                // A simple check to avoid trying to decode massive files in browser
                if (file.size > 50 * 1024 * 1024) { // 50MB limit
                    throw new Error('File is too large (> 50MB)');
                }
                const arrayBuffer = await file.arrayBuffer();
                await audioContext.decodeAudioData(arrayBuffer);
                newFiles.push(file);
            } catch (err) {
                console.error(`Error processing file ${file.name}:`, err);
                invalidFileCount++;
            }
        }
        
        this.datasetFiles = [...this.datasetFiles, ...newFiles];

        if (invalidFileCount > 0) {
            this.errorMessage = `${invalidFileCount} file(s) could not be loaded. They may be corrupted or in an unsupported format.`;
        }

        this.isProcessingFiles = false;
        this.statusMessage = '';
        this._updatePrimaryAction();
    }
    
    private async _handleDatasetFileSelect(e: Event) {
        const input = e.target as HTMLInputElement;
        if (input.files) {
            await this._processAndAddFiles(input.files);
        }
    }

    private _handleUrlInput(e: Event) {
        this.datasetUrl = (e.target as HTMLInputElement).value;
        if (this.datasetUrl.trim() !== '') {
            this.datasetFiles = [];
        }
        this._updatePrimaryAction();
    }

    private _removeFile(indexToRemove: number) {
        this.datasetFiles = this.datasetFiles.filter((_, index) => index !== indexToRemove);
        this._updatePrimaryAction();
    }

    private _clearFiles() {
        this.datasetFiles = [];
        this._updatePrimaryAction();
    }

    private _setupDragAndDrop(dropZone: HTMLElement) {
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            this.isDragOver = true;
        });
        dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            this.isDragOver = false;
        });
        dropZone.addEventListener('drop', async (e) => {
            e.preventDefault();
            this.isDragOver = false;
            if (e.dataTransfer?.files) {
                await this._processAndAddFiles(e.dataTransfer.files);
            }
        });
    }
    
    private _handleDeleteLora(name: string) {
        if (confirm(`Are you sure you want to delete the LoRA model "${name}"? This action cannot be undone.`)) {
            // This would ideally dispatch an event to the parent to handle deletion from the central state.
            alert("Deletion from the central store is not yet implemented in this component.");
        }
    }

    private _handleContinueTraining(lora: Lora) {
        const nameInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-name-input');
        const epochsInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-epochs-input');
        const lrInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-lr-input');
        const batchSizeInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-batch-size-input');
        const stepsInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-steps-input');
        
        if (nameInput) nameInput.value = lora.name;
        if (epochsInput) epochsInput.value = lora.epochs?.toString() ?? '10';
        if (lrInput) lrInput.value = lora.learningRate ?? '1e-4';
        if (batchSizeInput) batchSizeInput.value = lora.batchSize?.toString() ?? '8';
        if (stepsInput) stepsInput.value = lora.steps?.toString() ?? '';
        
        this.trainingType = lora.type || 'sound';
        this._clearFiles();
        this.datasetUrl = '';
        this.loraTrainingSection?.scrollIntoView({ behavior: 'smooth' });
        this._updatePrimaryAction();
    }
    
    private _handleTrainNewClick() {
        const nameInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-name-input');
        if (nameInput) {
            nameInput.value = '';
        }
        const epochsInput = this.shadowRoot!.querySelector<HTMLInputElement>('#lora-epochs-input');
        if (epochsInput) {
            epochsInput.value = '10'; // Default value
        }
        
        this.datasetFiles = [];
        this.datasetUrl = '';
        this.trainingType = 'sound'; // Default value

        this.loraTrainingSection?.scrollIntoView({ behavior: 'smooth' });
        this._updatePrimaryAction();
    }

    private _handleTestLora(lora: Lora) {
        this.testingLora = lora;
        this.showTestModal = true;
    }

    private _closeTestModal() {
        this.showTestModal = false;
        this.testingLora = null;
        this.isGeneratingTestSample = false;
    }

    private async _handleGenerateTestSample() {
        const appContext = this.appContextConsumer.value;
        if (!appContext?.audioContext || !this.testingLora) return;
        
        this.isGeneratingTestSample = true;
        
        const task = async () => {
            const { audioContext } = appContext;
            const duration = 3;
            
            const buffer = await beatAgent.generateInstrumental({
                audioContext: audioContext,
                duration: duration,
                bpm: 120,
                keySignature: 'C Major',
                instrumentalDescriptions: {
                    drums: `a test drum beat`,
                    bassline: `a test bassline`,
                    melody: `a test melody with ${this.testingLora!.name}`,
                    pads: `test pads`,
                }
            });
            
            appContext.updateTrack({ title: `Test: ${this.testingLora!.name}`, artist: 'LoRA Test', duration, audioBuffer: buffer });
        };
        
        await this._performTask(
            `Generate LoRA Test Sample`,
            [{message: 'Generating test sample...', duration: 1500}],
            task
        );
        
        this.isGeneratingTestSample = false;
        this._closeTestModal();
    }

    override firstUpdated() {
        this._updatePrimaryAction();
        const dropZone = this.shadowRoot!.querySelector('.drop-zone');
        if (dropZone) this._setupDragAndDrop(dropZone as HTMLElement);
    }
    
    private _renderTestModal() {
        if (!this.showTestModal || !this.testingLora) return null;

        const isVocal = this.testingLora.type === 'vocal';

        return html`
            <div class="modal-overlay" @click=${this._closeTestModal}>
                <div class="modal-content test-lora-modal-content" @click=${(e: Event) => e.stopPropagation()}>
                    <div class="modal-header">
                        <h3>Test Model: ${this.testingLora.name}</h3>
                        <button class="close-button" @click=${this._closeTestModal}>&times;</button>
                    </div>
                    
                    ${isVocal ? html`
                        <div>
                            <label for="test-vocal-text">Text to Generate</label>
                            <textarea id="test-vocal-text" placeholder="Type or paste lyrics here..."></textarea>
                        </div>
                    ` : html`
                        <p class="sub-label">Generate a short audio sample to hear the character of this sound model. Adjust parameters for different results.</p>
                    `}

                    <div class="row">
                        <div class="slider-container">
                            <label>Temperature: ${this.testLoraTemperature.toFixed(2)}</label>
                            <input type="range" min="0" max="1" step="0.01" .value=${this.testLoraTemperature} @input=${(e: Event) => this.testLoraTemperature = parseFloat((e.target as HTMLInputElement).value)}>
                            <div class="slider-labels"><span>Less Random</span><span>More Random</span></div>
                        </div>
                        <div class="slider-container">
                            <label>Guidance Scale: ${this.testLoraGuidanceScale.toFixed(1)}</label>
                            <input type="range" min="1" max="20" step="0.5" .value=${this.testLoraGuidanceScale} @input=${(e: Event) => this.testLoraGuidanceScale = parseFloat((e.target as HTMLInputElement).value)}>
                            <div class="slider-labels"><span>Less Adherence</span><span>More Adherence</span></div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button @click=${this._handleGenerateTestSample} ?disabled=${this.isLoading}>
                            ${this.isLoading ? 'Generating...' : 'Generate Sample'}
                        </button>
                    </div>
                    ${this.renderProgressIndicator()}
                </div>
            </div>
        `;
    }
    
    override render() {
        const trainedLoras = this.appContextConsumer.value?.trainedLoras ?? [];
        return html`
            <div class="panel">
                <h2 class="page-title">LoRA Training</h2>
                <div class="control-group">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                        <h3>My Trained Models</h3>
                        <button @click=${this._handleTrainNewClick}>Train New Model</button>
                    </div>
                    ${trainedLoras.length === 0 ? html`<p class="sub-label">No models trained yet. Train a new model below.</p>` : ''}
                    <div class="lora-list">
                        ${trainedLoras.map(lora => html`
                            <div class="lora-item">
                                <span><strong>${lora.name}</strong> <span class="lora-type">(${lora.type || 'sound'})</span></span>
                                <div class="lora-item-actions">
                                    <button @click=${() => this._handleTestLora(lora)}>Test</button>
                                    <button @click=${() => this._handleContinueTraining(lora)}>Continue Training</button>
                                    <button @click=${() => this._handleDeleteLora(lora.name)}>Delete</button>
                                </div>
                            </div>
                        `)}
                    </div>
                </div>

                <div id="lora-training-section" class="control-group">
                    <h3>Model Training</h3>
                    <p class="sub-label">Train a custom sound or vocal model by providing audio files, a ZIP, or a URL.</p>
                     
                    <div>
                        <label>Model Type</label>
                        <div class="radio-group">
                             <label><input type="radio" name="training-type" value="sound" .checked=${this.trainingType === 'sound'} @change=${() => this.trainingType = 'sound'}> Sound Model (for instruments)</label>
                             <label><input type="radio" name="training-type" value="vocal" .checked=${this.trainingType === 'vocal'} @change=${() => this.trainingType = 'vocal'}> Vocal Model (for singers)</label>
                        </div>
                    </div>

                    <div class="drop-zone ${classMap({ 'drag-over': this.isDragOver })}" @click=${this._triggerFileInputClick}>
                        <label for="dataset-upload">Drag & Drop Audio Files, or Click to Upload</label>
                        <input type="file" id="dataset-upload" accept="audio/*,.zip" style="display: none;" @change=${this._handleDatasetFileSelect} multiple>
                    </div>

                    ${this.isProcessingFiles ? html`
                        <div class="file-processing-indicator">
                            <svg class="spinner" viewBox="0 0 50 50" width="18" height="18"><circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle></svg>
                            <span>${this.statusMessage}</span>
                        </div>
                    ` : ''}

                    ${this.datasetFiles.length > 0 ? html`
                        <div class="file-list-container">
                            ${this.datasetFiles.map((file, index) => html`
                                <div class="file-item">
                                    <span>${file.name}</span>
                                    <button class="remove-file-btn" @click=${() => this._removeFile(index)}>&times;</button>
                                </div>
                            `)}
                        </div>
                        <button class="clear-all-btn" @click=${this._clearFiles}>Clear All</button>
                    ` : ''}
                    
                    ${this.errorMessage ? html`<p class="sub-label" style="color: var(--color-error);">${this.errorMessage}</p>` : ''}

                     <div class="row">
                        <div>
                            <label>Dataset URL (Optional)</label>
                            <input type="text" placeholder="https://.../dataset.zip" .value=${this.datasetUrl} @input=${this._handleUrlInput}>
                        </div>
                        <div>
                            <label>Model Name</label>
                            <input id="lora-name-input" type="text" placeholder="my_custom_sound" @input=${() => this._updatePrimaryAction()}>
                        </div>
                    </div>
                    <details>
                      <summary>Expert Settings</summary>
                      <div class="row" style="margin-top: 1rem;">
                          <div>
                              <label>Epochs</label>
                              <input id="lora-epochs-input" type="number" value="10">
                          </div>
                          <div>
                              <label>Learning Rate</label>
                              <input id="lora-lr-input" type="text" value="1e-4">
                          </div>
                          <div>
                              <label>Batch Size</label>
                              <input id="lora-batch-size-input" type="number" value="8">
                          </div>
                          <div>
                              <label>Number of Steps</label>
                              <input id="lora-steps-input" type="number" placeholder="Optional">
                          </div>
                      </div>
                    </details>
                    ${this.renderProgressIndicator()}
                    ${this.renderErrorMessage()}
                </div>
                ${this._renderTestModal()}
            </div>
        `;
    }
}