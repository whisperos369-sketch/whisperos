// ui/vocal-studio-module.ts
import {html, css} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {consume} from '@lit/context';
import {appContext, AppContext} from '../context.ts';
import type { SongState } from '../sections.ts';
import { aiService } from './services/ai-service.ts';
// FIX: Corrected import paths for root-level modules.
import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';

@customElement('vocal-studio-module')
export class VocalStudioModule extends StudioModule {
  @consume({context: appContext, subscribe: true})
  private _app!: AppContext;
  
  @state() private targetVoice = 'aria';
  @state() private url?: string;
  @state() private sourceFile: File | null = null;
  
  private _handleFileChange(e: Event) {
      const input = e.target as HTMLInputElement;
      this.sourceFile = input.files?.[0] || null;
  }

  private async _convert() {
    if (!this.sourceFile) {
      this.errorMessage = 'Please upload an audio file to convert.';
      return;
    }

    const task = async () => {
      // In a real app, we'd upload the file and get a URL. The stub backend
      // doesn't need a real URL, so we can pass a placeholder.
      const pseudoUrl = `localfile://${this.sourceFile!.name}`;
      
      const res = await aiService.rvcConvert({
        audio_url: pseudoUrl,
        target_voice: this.targetVoice,
      });
      this.url = res.url;
      
      if(this._app.songState) {
        const newStems = { ...this._app.songState.audio.stems, 'vocal_converted': res.url };
        this._app.updateCurrentSong({ audio: { ...this._app.songState.audio, stems: newStems } });
      }

      return res;
    };
    
    await this._performTask('Vocal Conversion', [
        { message: 'Uploading source audio...', duration: 1500 },
        { message: 'RVC model is processing (stub)...', duration: 2000 },
        { message: 'Fetching converted audio...', duration: 1000 },
    ], task);
  }
  
  static override styles = [sharedStyles, css`
    .panel {
        padding: var(--spacing-xl);
        max-width: 800px;
        margin: 0 auto;
    }
    audio { 
      width:100%; 
      margin-top: 1rem; 
    }
  `];

  // FIX: Removed 'override' modifier to fix build error.
  render() {
    if (!this._app.songState) return html`<p>Loading...</p>`;
    
    return html`
      <div class="panel">
        <h2 class="page-title">Voice Conversion (RVC)</h2>
        <div class="well">
            <div class="row" style="grid-template-columns: 1fr;">
                <div>
                    <label for="vocal-upload">Source Vocal</label>
                    <input id="vocal-upload" type="file" accept="audio/*" @change=${this._handleFileChange} ?disabled=${this.isLoading}>
                    <p class="sub-label">Upload a clean, isolated vocal track (WAV or MP3).</p>
                </div>
            </div>
            <div class="row">
                <div>
                    <label>Target Voice Model</label>
                    <select .value=${this.targetVoice} @change=${(e:any)=>this.targetVoice=e.target.value} ?disabled=${this.isLoading}>
                        <option value="aria">Aria</option>
                        <option value="titan">Titan</option>
                        <option value="custom_model_1">Custom Model 1</option>
                    </select>
                </div>
            </div>
             <div style="text-align: right; margin-top: 1.5rem;">
                <button @click=${this._convert} ?disabled=${this.isLoading || !this.sourceFile} class="primary">${this.isLoading?'Converting…':'Convert Voice'}</button>
            </div>
        </div>

        ${this.renderProgressIndicator()}
        ${this.renderErrorMessage()}

        ${this.url ? html`
            <div class="control-group" style="margin-top: 2rem;">
                <h4>Converted Vocal (Stub)</h4>
                <audio controls src=${this.url}></audio>
            </div>
        ` : ''}
      </div>
    `;
  }
}