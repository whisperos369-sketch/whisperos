import { _fetch } from './_fetch.ts';

export type SettingsData = {
    musicgen_url: string;
    llm_url: string;
    voice_url: string;
    ace_url: string;
    llm_provider: "gemini" | "openai" | "claude" | "local";
    keys: Record<string, string>;
    socials: Record<string, Record<string, string>>;
};

export type VramProbeResult = {
    cuda: boolean;
    device_name: string | null;
    free_gb: number | null;
    total_gb: number | null;
    cap_large_recommended: boolean;
    advice: string;
};

class SettingsService {
    private cache: Partial<SettingsData> | null = null;

    async getSettings(forceRefresh = false): Promise<Partial<SettingsData>> {
        if (this.cache && !forceRefresh) {
            return this.cache;
        }
        const settings = await _fetch('/api/settings', { method: 'GET' });
        this.cache = settings;
        return settings;
    }

    async saveSettings(settings: Partial<SettingsData>): Promise<void> {
        await _fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(settings),
        });
        // Invalidate cache on save
        this.cache = null;
    }

    async probeVram(): Promise<VramProbeResult> {
        return _fetch('/api/system/vram', { method: 'GET' });
    }
}

export const settingsService = new SettingsService();
