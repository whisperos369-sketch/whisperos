import { _fetch } from './_fetch.ts';

export interface Job {
    id: string;
    name: string;
    status: "queued" | "running" | "done" | "failed";
    payload: any;
    runAt: string;
    error?: string;
}

interface PublishPayload {
    platforms: string[];
    asset_url: string;
    cover_url?: string;
    video_url?: string;
    title: string;
    tags: string[];
    description?: string;
}

interface SchedulePayload extends PublishPayload {
    schedule: {
        datetime: string; // ISO 8601
        timezone: string;
    };
}

class PublisherService {
    async publishNow(payload: PublishPayload): Promise<{ status: string, message: string }> {
        return _fetch('/api/publish/now', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
    }

    async schedule(payload: SchedulePayload): Promise<{ status: string, job_id: string, run_at: string }> {
        return _fetch('/api/publish/schedule', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
    }

    async listJobs(status: string = "all"): Promise<Job[]> {
        // Mock data for UI development
        if (status === "pending") {
            return Promise.resolve([
                { id: 'job1', name: 'social_publish', status: 'queued', runAt: new Date(Date.now() + 3600000).toISOString(), payload: { platforms: ['YouTube'], title: 'My Scheduled Track' } }
            ]);
        }
        return Promise.resolve([]);
        // Real implementation:
        // return _fetch(`/api/publish/jobs?status=${status}`, { method: 'GET' });
    }

    async cancelJob(jobId: string): Promise<{ status: string, job_id: string }> {
         return _fetch(`/api/publish/jobs/${jobId}/cancel`, { method: 'POST' });
    }
}

export const publisherService = new PublisherService();
