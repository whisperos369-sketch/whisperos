export class APIError extends Error {
    constructor(message: string, public originalError?: unknown) {
        super(message);
        this.name = 'APIError';
    }
}

export async function _fetch(url: string, options: RequestInit): Promise<any> {
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`API Error (${response.status}): ${errorBody || response.statusText}`);
        }
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.indexOf("application/json") !== -1) {
            return response.json();
        }
        return response; // Let the caller handle non-JSON responses like text or blobs
    } catch (e) {
        console.error(`Fetch failed for ${url}:`, e);
        throw new APIError(`Network request failed for ${url}. Is the backend running?`, e);
    }
}
