import { _fetch } from './_fetch.ts';

type LlmTask = "songwriting" | "cover_caption" | "video_desc" | "hashtags" | "vocal_direction";

interface ComposePayload {
    provider: string;
    task: LlmTask;
    prompt: string;
    params?: Record<string, any>;
}

interface CaptionPayload {
    platform: string;
    track_meta: Record<string, any>;
}

class LlmService {
    async compose(payload: ComposePayload): Promise<{ text: string }> {
        return _fetch('/api/llm/compose', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
    }

    async captions(payload: CaptionPayload): Promise<{ caption: string, hashtags: string[] }> {
        return _fetch('/api/llm/captions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
    }
}

export const llmService = new LlmService();
