/**
 * @fileoverview Utility for exporting song arrangement cues to JSON.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type { SongState } from './sections.ts';

/**
 * Serializes markers and loop regions into a JSON object.
 * This can be passed to backend services like the video generator.
 */
export function serializeCues(project: SongState): object {
    return {
        markers: project.markers,
        loopRegion: project.loopRegion,
        bpm: project.meta.bpm,
        key: project.meta.key,
    };
}
