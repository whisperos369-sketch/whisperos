/**
 * @fileoverview A stateful service for managing A/B comparison of project states.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type { SongState, LoraRef, StemMixState } from '../sections.ts';

type Snapshot = {
    loraStack: LoraRef[];
    mix: {
        stems: Record<string, StemMixState>;
        master: { volume: number; };
    }
};

export type ABCompareState = {
    active: 'A' | 'B';
    snapshots: {
        A: Snapshot | null;
        B: Snapshot | null;
    };
    activeState: Partial<SongState> | null;
};

type ABListener = (newState: ABCompareState) => void;

export class ABCompareService {
    public state: ABCompareState = {
        active: 'A',
        snapshots: { A: null, B: null },
        activeState: null,
    };
    private listeners: Set<ABListener> = new Set();

    on(event: 'update', listener: ABListener) {
        this.listeners.add(listener);
    }

    off(event: 'update', listener: ABListener) {
        this.listeners.delete(listener);
    }

    private _emitUpdate() {
        this.listeners.forEach(listener => listener(this.state));
    }

    private _extractSnapshot(project: SongState): Snapshot {
        return {
            loraStack: JSON.parse(JSON.stringify(project.loraStack)),
            mix: JSON.parse(JSON.stringify(project.mix)),
        };
    }

    reset(project: SongState) {
        this.state = {
            active: 'A',
            snapshots: { A: this._extractSnapshot(project), B: null },
            activeState: null,
        };
        this._emitUpdate();
    }

    snapshot(slot: 'A' | 'B', project: SongState) {
        this.state.snapshots[slot] = this._extractSnapshot(project);
        this._emitUpdate();
    }
    
    toggleActive() {
        if (!this.state.snapshots.A || !this.state.snapshots.B) return;
        
        this.state.active = this.state.active === 'A' ? 'B' : 'A';
        const activeSnapshot = this.state.snapshots[this.state.active];
        
        if (activeSnapshot) {
            this.state.activeState = {
                loraStack: activeSnapshot.loraStack,
                mix: activeSnapshot.mix,
            };
        }
        
        this._emitUpdate();
    }
}

export const abCompareService = new ABCompareService();