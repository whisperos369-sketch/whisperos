import { z } from "zod";

const Schema = z.object({
  VITE_MUSICGEN_URL: z.coerce.string().default("/api/musicgen"),
  VITE_LLM_URL: z.coerce.string().default("/api/llm"),
  VITE_VOICE_URL: z.coerce.string().default("/api/voice"),
  VITE_ACE_URL: z.coerce.string().default("/api/ace"),
  VITE_EXPORT_BUNDLE_URL: z.coerce.string().default("/api/export/bundle"),
  VITE_SHARE_URL: z.coerce.string().default("/api/share/create"),

  VITE_API_TIMEOUT_MS: z.coerce.number().default(300000),

  // Feature Flags
  VITE_FF_RVC: z.coerce.string().default("true"),
  VITE_FF_ACE_STEP: z.coerce.string().default("true"),
  VITE_FF_LLM_CONNECTOR: z.coerce.string().default("true"),
  VITE_FF_PUBLISHER: z.coerce.string().default("true"),
  VITE_FF_ENDPOINT_MANAGER: z.coerce.string().default("true"),

  // Ops Vars
  VITE_DEFAULT_PROFIT_MARGIN: z.coerce.string().default("0.2"),
  VITE_DEFAULT_RETURN_DAYS: z.coerce.string().default("14"),
  VITE_TRENDS_SEARCH_URL: z.string().optional(),
  VITE_TRENDS_WEEKLY_REPORT: z.string().optional(),
  VITE_SOCIAL_TIKTOK_PROXY: z.string().optional(),
  VITE_SOCIAL_INSTAGRAM_PROXY: z.string().optional(),
  VITE_SOCIAL_FACEBOOK_PROXY: z.string().optional(),
  VITE_SOCIAL_YOUTUBE_PROXY: z.string().optional(),
  VITE_PIXEL_META: z.string().optional(),
  VITE_PIXEL_TIKTOK: z.string().optional(),
  VITE_AFFILIATE_PORTAL_URL: z.string().optional(),
  VITE_SUPPLIER_SEARCH_URL: z.string().optional(),
  VITE_POD_PRINTIFY_URL: z.string().optional(),
  VITE_POD_PRINTFUL_URL: z.string().optional(),
});

const parsedEnv = Schema.parse((import.meta as any).env ?? {});

export const env = {
    MUSICGEN_URL: parsedEnv.VITE_MUSICGEN_URL,
    LLM_URL: parsedEnv.VITE_LLM_URL,
    VOICE_URL: parsedEnv.VITE_VOICE_URL,
    ACE_URL: parsedEnv.VITE_ACE_URL,
    EXPORT_BUNDLE_URL: parsedEnv.VITE_EXPORT_BUNDLE_URL,
    SHARE_URL: parsedEnv.VITE_SHARE_URL,
    API_TIMEOUT_MS: parsedEnv.VITE_API_TIMEOUT_MS,
    DEFAULT_PROFIT_MARGIN: parsedEnv.VITE_DEFAULT_PROFIT_MARGIN,
    DEFAULT_RETURN_DAYS: parsedEnv.VITE_DEFAULT_RETURN_DAYS,
    TRENDS_SEARCH_URL: parsedEnv.VITE_TRENDS_SEARCH_URL,
    TRENDS_WEEKLY_REPORT: parsedEnv.VITE_TRENDS_WEEKLY_REPORT,
    SOCIAL_TIKTOK_PROXY: parsedEnv.VITE_SOCIAL_TIKTOK_PROXY,
    SOCIAL_INSTAGRAM_PROXY: parsedEnv.VITE_SOCIAL_INSTAGRAM_PROXY,
    SOCIAL_FACEBOOK_PROXY: parsedEnv.VITE_SOCIAL_FACEBOOK_PROXY,
    SOCIAL_YOUTUBE_PROXY: parsedEnv.VITE_SOCIAL_YOUTUBE_PROXY,
    PIXEL_META: parsedEnv.VITE_PIXEL_META,
    PIXEL_TIKTOK: parsedEnv.VITE_PIXEL_TIKTOK,
    AFFILIATE_PORTAL_URL: parsedEnv.VITE_AFFILIATE_PORTAL_URL,
    SUPPLIER_SEARCH_URL: parsedEnv.VITE_SUPPLIER_SEARCH_URL,
    POD_PRINTIFY_URL: parsedEnv.VITE_POD_PRINTIFY_URL,
    POD_PRINTFUL_URL: parsedEnv.VITE_POD_PRINTFUL_URL,
};

export const flags = {
  rvc: parsedEnv.VITE_FF_RVC === "true",
  ace: parsedEnv.VITE_FF_ACE_STEP === "true",
  llmConnector: parsedEnv.VITE_FF_LLM_CONNECTOR === "true",
  publisher: parsedEnv.VITE_FF_PUBLISHER === "true",
  endpointManager: parsedEnv.VITE_FF_ENDPOINT_MANAGER === "true",
};
