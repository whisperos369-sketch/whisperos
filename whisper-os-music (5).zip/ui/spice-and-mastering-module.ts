// spice-and-mastering-module.ts
import {html, LitElement, css, nothing} from 'lit';
import {customElement, property, state} from 'lit/decorators.js';
import {consume} from '@lit/context';
import {appContext, AppContext} from '../context.ts';
import type { SongState } from '../sections.ts';
import { sharedStyles } from '../shared-styles.ts';
import * as ops from './ops/index.ts';

@customElement('spice-and-mastering-module')
export class SpiceAndMasteringModule extends LitElement {
  @consume({context: appContext, subscribe: true})
  private _app!: AppContext;

  @state() private loading = false;
  @state() private downloadUrl: string | null = null;

  // FIX: Removed 'override' modifier to fix build error.
  static styles = [sharedStyles, css`
    .results {
        margin-top: 1.5rem;
        padding-top: 1.5rem;
        border-top: 1px solid var(--border-color);
    }
  `];

  private _getProject(): SongState | null {
      return this._app?.songState ?? null;
  }

  private async _handleExport() {
    const project = this._getProject();
    if(!project) return;
    
    this.loading = true;
    this.downloadUrl = null;

    try{
      const out = await ops.exportBundle(project);
      
      this.downloadUrl = out.downloadUrl;
      
      this._app.showToast('Export bundle is ready!', 'success');

    } catch (e) {
        this._app.showToast(`Export failed: ${(e as Error).message}`, 'error');
    } finally { 
      this.loading = false;
    }
  }

  render() {
    const project = this._getProject();
    if (!project) return html`<div class="panel"><p>No project loaded.</p></div>`;

    const lufsTarget = project.meta.lufsTarget;

    return html`
    <div class="panel">
      <h2 class="page-title">Mastering & Export</h2>
      <label>LUFS Target</label>
      <input type="number" step="0.5" .value=${String(lufsTarget)} @change=${(e:any) => this._app.updateCurrentSong({ meta: { ...project.meta, lufsTarget: Number(e.target.value) }})}/>
      <p class="sub-label">Set the target loudness for the final master. -14 LUFS is standard for streaming.</p>
      
      <div>
        <button @click=${this._handleExport} ?disabled=${this.loading || !project.audio.latestMix} style="margin-top: 1rem;" class="primary">
            ${this.loading ? 'Exporting…' : 'Export Bundle'}
        </button>
      </div>

      ${this.downloadUrl ? html`
        <div class="results">
            <a href=${this.downloadUrl} class="button" download>Download Bundle (.zip)</a>
        </div>
      `: nothing}
    </div>
    `;
  }
}