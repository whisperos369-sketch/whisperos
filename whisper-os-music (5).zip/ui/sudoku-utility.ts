/**
 * @fileoverview The "Sudoku" utility component.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { html, css, LitElement } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';

import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';
import { formatDuration } from '../utils.ts';

type Difficulty = 'easy' | 'medium' | 'hard';

const puzzles: Record<Difficulty, (number | null)[][]> = {
    easy: [
        [null, 3, 4, 6, 7, 8, 9, 1, 2],
        [6, 7, 2, 1, 9, 5, 3, 4, 8],
        [1, 9, 8, 3, 4, 2, 5, 6, null],
        [8, 5, 9, 7, 6, 1, 4, 2, 3],
        [4, 2, 6, null, 5, null, 7, 9, 1],
        [7, 1, 3, 9, 2, 4, 8, 5, 6],
        [null, 6, 1, 5, 3, 7, 2, 8, 4],
        [2, 8, 7, 4, 1, 9, 6, 3, 5],
        [3, 4, 5, 2, 8, 6, 1, 7, null]
    ],
    // FIX: Add missing medium and hard puzzles
    medium: [
        [5, 3, null, null, 7, null, null, null, null],
        [6, null, null, 1, 9, 5, null, null, null],
        [null, 9, 8, null, null, null, null, 6, null],
        [8, null, null, null, 6, null, null, null, 3],
        [4, null, null, 8, null, 3, null, null, 1],
        [7, null, null, null, 2, null, null, null, 6],
        [null, 6, null, null, null, null, 2, 8, null],
        [null, null, null, 4, 1, 9, null, null, 5],
        [null, null, null, null, 8, null, null, 7, 9]
    ],
    hard: [
        [null, null, null, 6, null, null, 4, null, null],
        [7, null, null, null, null, 3, 6, null, null],
        [null, null, null, null, 9, 1, null, 8, null],
        [null, null, null, null, null, null, null, null, null],
        [null, 5, 1, null, null, null, null, null, 3],
        [null, null, null, 3, null, null, null, null, null],
        [6, null, null, null, null, null, null, 7, 5],
        [null, null, 3, 4, null, null, null, null, null],
        [null, null, null, null, null, null, 1, null, null]
    ]
};

@customElement('sudoku-utility')
export class SudokuUtility extends StudioModule {
    @state() private board: (number | null)[][] = [];
    @state() private isEditable: boolean[][] = [];
    @state() private errors: boolean[][] = [];
    @state() private currentDifficulty: Difficulty = 'medium';
    @state() private elapsedTime = 0;
    @state() private isSolved = false;
    @state() private isTimerPaused = false;
    private timerInterval: number | undefined;

    constructor() {
        super();
        this.resetGame();
    }

    // FIX: Removed 'override' modifier to fix build error.
    disconnectedCallback() {
        // FIX: Removed `super.disconnectedCallback()` call as `StudioModule` does not have a `disconnectedCallback` method.
        this._stopTimer();
    }

    private _startTimer() {
        this._stopTimer();
        this.timerInterval = window.setInterval(() => {
            if (!this.isTimerPaused) {
                this.elapsedTime++;
            }
        }, 1000);
    }

    private _stopTimer() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = undefined;
        }
    }

    private _toggleTimerPause() {
        if (this.isSolved) return;
        this.isTimerPaused = !this.isTimerPaused;
    }

    private resetGame() {
        this._stopTimer();
        this.elapsedTime = 0;
        this.isSolved = false;
        this.isTimerPaused = false;

        const initialBoard = puzzles[this.currentDifficulty];
        this.board = initialBoard.map(row => [...row]);
        this.isEditable = initialBoard.map(row => row.map(cell => cell === null));
        this.errors = Array(9).fill(null).map(() => Array(9).fill(false));
        this._validateBoard();
        this._startTimer();
    }
    
    private _changeDifficulty(difficulty: Difficulty) {
        this.currentDifficulty = difficulty;
        this.resetGame();
    }

    private _checkIfSolved(): boolean {
        const isFull = !this.board.some(row => row.some(cell => cell === null));
        if (!isFull) return false;

        this._validateBoard();
        const hasErrors = this.errors.some(row => row.some(cell => cell === true));

        return isFull && !hasErrors;
    }

    private _validateBoard() {
        const newErrors: boolean[][] = Array(9).fill(null).map(() => Array(9).fill(false));

        // Check rows
        for (let r = 0; r < 9; r++) {
            const row = this.board[r];
            const counts: { [key: number]: number[] } = {};
            for (let c = 0; c < 9; c++) {
                const num = row[c];
                if (num !== null) {
                    if (!counts[num]) counts[num] = [];
                    counts[num].push(c);
                }
            }
            for (const num in counts) {
                if (counts[num].length > 1) {
                    counts[num].forEach(c => newErrors[r][c] = true);
                }
            }
        }

        // Check columns
        for (let c = 0; c < 9; c++) {
            const counts: { [key: number]: number[] } = {};
            for (let r = 0; r < 9; r++) {
                const num = this.board[r][c];
                if (num !== null) {
                    if (!counts[num]) counts[num] = [];
                    counts[num].push(r);
                }
            }
            for (const num in counts) {
                if (counts[num].length > 1) {
                    counts[num].forEach(r => newErrors[r][c] = true);
                }
            }
        }

        // Check boxes
        for (let boxRow = 0; boxRow < 3; boxRow++) {
            for (let boxCol = 0; boxCol < 3; boxCol++) {
                const counts: { [key: number]: {r: number, c: number}[] } = {};
                for (let r_off = 0; r_off < 3; r_off++) {
                    for (let c_off = 0; c_off < 3; c_off++) {
                        const r = boxRow * 3 + r_off;
                        const c = boxCol * 3 + c_off;
                        const num = this.board[r][c];
                        if (num !== null) {
                            if (!counts[num]) counts[num] = [];
                            counts[num].push({r, c});
                        }
                    }
                }
                 for (const num in counts) {
                    if (counts[num].length > 1) {
                        counts[num].forEach(pos => newErrors[pos.r][pos.c] = true);
                    }
                }
            }
        }

        this.errors = newErrors;
    }

    private _handleInputChange(e: Event, r: number, c: number) {
        const input = e.target as HTMLInputElement;
        let value = parseInt(input.value, 10);

        if (isNaN(value) || value < 1 || value > 9) {
            value = NaN;
            input.value = '';
        }

        this.board[r][c] = isNaN(value) ? null : value;
        (this as LitElement).requestUpdate('board');
        this._validateBoard();

        if (this._checkIfSolved()) {
            this.isSolved = true;
            this._stopTimer();
        }
    }
    
    // Auto-solver logic omitted for brevity.
}
