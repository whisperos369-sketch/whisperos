import { LitElement, html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';

type VisualizerType = 'spectrum' | 'waveform' | 'particles';

@customElement('audio-visualizer')
export class AudioVisualizer extends LitElement {
  @property({ attribute: false })
  analyserNode: AnalyserNode | null = null;

  @property({ type: String })
  type: VisualizerType = 'spectrum';

  @property({ type: Boolean })
  isPlaying = false;

  private canvas!: HTMLCanvasElement;
  private canvasCtx!: CanvasRenderingContext2D;
  private animationFrameId: number | null = null;
  private particles: { x: number; y: number; radius: number; vx: number; vy: number; alpha: number; }[] = [];
  private particleColor = '255, 20, 147'; // Default to deep pink

  static override styles = css`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
    canvas {
      width: 100%;
      height: 100%;
      display: block;
    }
  `;

  override firstUpdated() {
    this.canvas = this.shadowRoot!.querySelector('canvas')!;
    this.canvasCtx = this.canvas.getContext('2d')!;
    this.updateParticleColor();
    this.resizeCanvas();
    if (this.isPlaying) {
      this.startVisualization();
    }
  }

  override updated(changedProperties: Map<string, any>) {
    if (changedProperties.has('isPlaying')) {
      if (this.isPlaying) {
        this.startVisualization();
      } else {
        this.stopVisualization();
      }
    }
    if (changedProperties.has('type') && this.isPlaying) {
        // Clear particles when switching to this visualizer
        if (this.type === 'particles') {
            this.particles = [];
        }
        this.startVisualization();
    }
  }

  disconnectedCallback(): void {
      super.disconnectedCallback();
      this.stopVisualization();
  }
  
  private updateParticleColor() {
      // Use a try-catch block in case the component is not fully attached to the DOM
      try {
        const colorString = getComputedStyle(this).getPropertyValue('--accent-secondary').trim();
        if (colorString.startsWith('#')) {
            const hex = colorString.substring(1);
            const r = parseInt(hex.substring(0, 2), 16);
            const g = parseInt(hex.substring(2, 4), 16);
            const b = parseInt(hex.substring(4, 6), 16);
            if (!isNaN(r) && !isNaN(g) && !isNaN(b)) {
                this.particleColor = `${r}, ${g}, ${b}`;
            }
        }
      } catch (e) {
          console.warn("Could not read CSS variable for particle color, using default.", e);
      }
  }

  private startVisualization() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    const draw = () => {
      if (!this.analyserNode) {
        // Stop the loop if the component has no analyser
        this.stopVisualization();
        return;
      }
      this.resizeCanvas();
      
      switch (this.type) {
        case 'spectrum':
          this.drawSpectrum();
          break;
        case 'waveform':
          this.drawWaveform();
          break;
        case 'particles':
          this.drawParticles();
          break;
      }
      this.animationFrameId = requestAnimationFrame(draw);
    };
    draw();
  }
  
  private stopVisualization() {
      if(this.animationFrameId) {
          cancelAnimationFrame(this.animationFrameId);
          this.animationFrameId = null;
      }
      // Clear the canvas after a short delay to ensure the last frame is gone
      setTimeout(() => {
          if (!this.isPlaying && this.canvasCtx) {
            this.canvasCtx.clearRect(0, 0, this.canvas.width, this.canvas.height);
          }
      }, 50);
  }

  private resizeCanvas() {
    const { width, height } = this.canvas.getBoundingClientRect();
    if (this.canvas.width !== width || this.canvas.height !== height) {
        this.canvas.width = width;
        this.canvas.height = height;
    }
  }

  private drawSpectrum() {
    const bufferLength = this.analyserNode!.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    this.analyserNode!.getByteFrequencyData(dataArray);

    this.canvasCtx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    const barWidth = (this.canvas.width / bufferLength) * 2.5;
    let x = 0;

    const primaryColor = getComputedStyle(this).getPropertyValue('--accent-primary');
    
    const midY = this.canvas.height / 2;

    for (let i = 0; i < bufferLength; i++) {
      const barHeight = (dataArray[i] / 255) * midY;
      
      this.canvasCtx.fillStyle = primaryColor;
      this.canvasCtx.fillRect(x, midY - barHeight, barWidth, barHeight * 2);
      x += barWidth + 1;
    }
  }

  private drawWaveform() {
    const bufferLength = this.analyserNode!.fftSize;
    const dataArray = new Uint8Array(bufferLength);
    this.analyserNode!.getByteTimeDomainData(dataArray);

    this.canvasCtx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.canvasCtx.lineWidth = 2;
    this.canvasCtx.strokeStyle = getComputedStyle(this).getPropertyValue('--accent-primary');
    this.canvasCtx.beginPath();
    
    const sliceWidth = this.canvas.width * 1.0 / bufferLength;
    let x = 0;
    
    for (let i = 0; i < bufferLength; i++) {
      const v = dataArray[i] / 128.0;
      const y = v * this.canvas.height / 2;
      if (i === 0) {
        this.canvasCtx.moveTo(x, y);
      } else {
        this.canvasCtx.lineTo(x, y);
      }
      x += sliceWidth;
    }
    
    this.canvasCtx.lineTo(this.canvas.width, this.canvas.height / 2);
    this.canvasCtx.stroke();
  }

  private drawParticles() {
    const bufferLength = this.analyserNode!.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    this.analyserNode!.getByteFrequencyData(dataArray);
    
    const { width, height } = this.canvas;
    this.canvasCtx.clearRect(0, 0, width, height);
    
    // Average the intensity of the first 10 frequency bins for bass response
    const bass = dataArray.slice(0, 10).reduce((a, b) => a + b, 0) / 10;
    
    // Generate new particles on a strong bass hit
    if (bass > 180 && Math.random() > 0.8 && this.particles.length < 100) {
        for(let i = 0; i < 3; i++) {
            this.particles.push({
                x: width / 2 + (Math.random() - 0.5) * 20, // Start near center
                y: height / 2 + (Math.random() - 0.5) * 20,
                radius: Math.random() * 3 + 2,
                vx: (Math.random() - 0.5) * 4,
                vy: (Math.random() - 0.5) * 4,
                alpha: 1
            });
        }
    }
    
    // Filter out old particles and update/draw the rest
    this.particles = this.particles.filter(p => p.alpha > 0.01 && p.radius > 0.1);

    this.particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= 0.02;
        p.radius *= 0.98;
        
        this.canvasCtx.beginPath();
        this.canvasCtx.arc(p.x, p.y, p.radius, 0, Math.PI * 2, false);
        this.canvasCtx.fillStyle = `rgba(${this.particleColor}, ${p.alpha})`;
        this.canvasCtx.fill();
    });
  }

  override render() {
    return html`<canvas></canvas>`;
  }
}
