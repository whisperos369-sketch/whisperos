// ui/music-module.ts
import {css, html} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {consume} from '@lit/context';
import {appContext, AppContext} from '../context.ts';
import type { SongState } from '../sections.ts';
// FIX: Corrected import paths for root-level modules.
import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';
import { aiService } from './services/ai-service.ts';

@customElement('music-module')
export class MusicModule extends StudioModule {
  @consume({context: appContext, subscribe: true})
  private _app!: AppContext;
  
  @state() private prompt = 'dark cinematic hip-hop, heavy 808s, halftime groove';
  @state() private url?: string;
  // FIX: Add model and duration state to satisfy aiService.musicGen and provide UI control.
  @state() private duration = 12;
  @state() private model = 'medium';

  private async _generate() {
    if (!this._app || !this._app.songState) return;
    this.url = undefined;

    const task = async () => {
      const res = await aiService.musicGen({
        prompt: this.prompt,
        // FIX: Use local state for duration.
        duration: this.duration,
        // FIX: Pass the selected model to the AI service.
        model: this.model,
      });

      this.url = res.url;
      const newVersion = {id: crypto.randomUUID(), label:`MusicGen ${this._app.songState!.versions.length+1}`, url:res.url, createdAt:Date.now()};
      
      const updates: Partial<SongState> = {
          audio: { ...this._app.songState!.audio, latestMix: res.url },
          versions: [...this._app.songState!.versions, newVersion],
      };
      this._app.updateCurrentSong(updates);

      return res;
    };
    
    await this._performTask('Generate Instrumental', [
        { message: 'Sending prompt to MusicGen service...', duration: 1500 },
        { message: 'Generating audio waveform (this can take a moment)...', duration: 8000 },
        { message: 'Finalizing audio...', duration: 2000 },
    ], task);
  }

  static override styles = [sharedStyles, css`
    .panel {
        padding: var(--spacing-xl);
        max-width: 800px;
        margin: 0 auto;
    }
    audio { 
      width:100%; 
      margin-top: 1rem; 
      filter: var(--shadow-color) 0 0 10px;
    }
  `];

  override render() {
    if (!this._app?.songState) return html`<p>Loading...</p>`;
    
    return html`
      <div class="panel">
        <h2 class="page-title">Music Generation</h2>
        <div class="well">
            <div class="row" style="grid-template-columns: 1fr;">
              <div>
                <label>Prompt</label>
                <textarea .value=${this.prompt} @input=${(e:any)=>this.prompt=e.target.value} rows="3" ?disabled=${this.isLoading}></textarea>
              </div>
              <!-- FIX: Add controls for duration and model size -->
              <div class="row">
                <div>
                  <label>Duration (seconds)</label>
                  <input type="number" .value=${String(this.duration)} @input=${(e:any)=>this.duration=Number(e.target.value)} ?disabled=${this.isLoading}>
                </div>
                 <div>
                    <label>Model Size</label>
                    <select .value=${this.model} @change=${(e:any)=>this.model=e.target.value} ?disabled=${this.isLoading}>
                        <option value="small">Small (Fastest)</option>
                        <option value="medium">Medium (Balanced)</option>
                        <option value="large">Large (Highest Quality)</option>
                    </select>
                </div>
              </div>
            </div>
            <div style="text-align: right; margin-top: 1.5rem;">
                <button @click=${this._generate} ?disabled=${this.isLoading} class="primary">
                    ${this.isLoading ? 'Generating...' : 'Generate Instrumental'}
                </button>
            </div>
        </div>
        
        ${this.renderProgressIndicator()}
        ${this.renderErrorMessage()}
        
        ${this.url ? html`
            <div class="control-group" style="margin-top: 2rem;">
                <h4>Generated Track</h4>
                <audio controls src=${this.url}></audio>
            </div>
        `:''}
      </div>
    `;
  }
}
