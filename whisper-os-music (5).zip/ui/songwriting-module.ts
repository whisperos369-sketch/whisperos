// ui/songwriting-module.ts
import {css, html} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {consume} from '@lit/context';
import {appContext, AppContext} from '../context.ts';
import type { SongState } from '../sections.ts';
import { aiService, type LyricDraft } from '../ai-service.ts';
// FIX: Corrected import paths for root-level modules.
import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';

@customElement('songwriting-module')
export class SongwritingModule extends StudioModule {
  @consume({context: appContext, subscribe: true})
  private _app!: AppContext;

  @state() private prompt = 'Write a verse and chorus for a hip-hop track about ambition and overcoming obstacles.';
  @state() private drafts: LyricDraft[] = [];

  static override styles = [sharedStyles, css`
    .panel {
      padding: var(--spacing-xl);
      max-width: 1200px;
      margin: 0 auto;
    }
    .drafts-grid { 
      display: grid; 
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); 
      gap: var(--spacing-lg); 
      margin-top: var(--spacing-xl);
    }
    .draft-card { 
      border: 1px solid var(--border-color); 
      border-radius: var(--border-radius); 
      background: var(--bg-panel); 
      display: flex;
      flex-direction: column;
      transition: var(--transition-fast);
    }
    .draft-card:hover {
        border-color: var(--border-color-strong);
        transform: translateY(-2px);
    }
    .draft-card-header {
        padding: var(--spacing-sm) var(--spacing-md);
        border-bottom: 1px solid var(--border-color);
        font-weight: 500;
        color: var(--text-secondary);
        font-size: 0.85rem;
    }
    .draft-card pre {
      white-space: pre-wrap;
      word-wrap: break-word;
      font-family: var(--font-mono);
      flex-grow: 1;
      padding: var(--spacing-md);
      margin: 0;
      color: var(--text-secondary);
      font-size: 0.9rem;
    }
    .draft-card-footer {
        padding: var(--spacing-sm) var(--spacing-md);
        border-top: 1px solid var(--border-color);
        display: flex;
        justify-content: flex-end;
    }
  `];

  private async _generate() {
    this.drafts = [];
    const task = async () => {
      // The new service returns a simpler object, so we adapt it here
      const res = await aiService.lyricsDraft({ prompt: this.prompt });
      this.drafts = res.drafts;
      return res;
    };
    
    await this._performTask('Generate Lyric Drafts', [
        { message: 'Sending prompt to LLM service...', duration: 1000 },
        { message: 'Generating lyrical concepts...', duration: 2500 },
    ], task);
  }

  private _adopt(i: number) {
    const draft = this.drafts[i];
    if (!draft || !this._app.songState) return;
    
    const project = this._app.songState;
    
    const updates: Partial<SongState> = {
        lyrics: draft.text,
    };
    
    this._app.updateCurrentSong(updates);
    this._app.showToast('Lyrics adopted!', 'success');
  }

  override render() {
    if (!this._app || !this._app.songState) {
        return html`<div class="panel"><p>Loading project...</p></div>`;
    }

    return html`
      <div class="panel">
        <h2 class="page-title">Songwriting Assistant</h2>
        <div class="well">
            <div>
              <label>Creative Prompt</label>
              <textarea .value=${this.prompt} @input=${(e:any)=>this.prompt=e.target.value} rows="4" placeholder="Describe the theme, mood, and story of your song..."></textarea>
            </div>
            <div style="text-align: right; margin-top: 1rem;">
              <button @click=${this._generate} ?disabled=${this.isLoading} class="primary">
                ${this.isLoading?'Generating…':'Generate Drafts'}
              </button>
            </div>
        </div>
        
        ${this.renderProgressIndicator()}
        ${this.renderErrorMessage()}
        
        <div class="drafts-grid">
          ${this.drafts.map((d,i)=>html`
            <div class="draft-card">
              <div class="draft-card-header">
                Draft ${i + 1}
              </div>
              <pre>${d.text}</pre>
              <div class="draft-card-footer">
                <button @click=${()=>this._adopt(i)}>Use This Draft</button>
              </div>
            </div>
          `)}
        </div>
      </div>
    `;
  }
}