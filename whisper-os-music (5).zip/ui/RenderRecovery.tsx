/**
 * @fileoverview A panel for displaying and managing long-running jobs.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { css, html, LitElement, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { jobQueueService, type Job } from '../core/job-queue.ts';
import { sharedStyles } from '../shared-styles.ts';
import { formatDuration } from '../utils.ts';

@customElement('render-recovery-panel')
export class RenderRecoveryPanel extends LitElement {
    @state() private jobs: Job[] = [];
    @state() private isOpen = false;
    
    @state() private now = Date.now();
    private timer: number | undefined;

    constructor() {
        super();
        this._updateJobs = this._updateJobs.bind(this);
    }

    connectedCallback() {
        super.connectedCallback();
        jobQueueService.addEventListener('update', this._updateJobs);
        this._updateJobs(); // Initial load
        this.timer = window.setInterval(() => {
            this.now = Date.now();
        }, 1000);
        (this as unknown as HTMLElement).classList.add('render-recovery-panel-host');
        (this as unknown as HTMLElement).classList.toggle('open', this.isOpen);
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        jobQueueService.removeEventListener('update', this._updateJobs);
        if (this.timer) {
            clearInterval(this.timer);
        }
    }
    
    // FIX: Removed 'override' modifier to fix build error.
    updated(changedProperties: Map<string, any>) {
        if (changedProperties.has('isOpen')) {
            (this as unknown as HTMLElement).classList.toggle('open', this.isOpen);
        }
    }

    private async _updateJobs() {
        this.jobs = await jobQueueService.listJobs();
    }

    public togglePanel(open: boolean) {
        this.isOpen = open;
    }

    private _getElapsedTime(job: Job): string {
        const end = job.status === 'completed' || job.status === 'failed' || job.status === 'cancelled'
            ? job.updatedAt
            : this.now;
        
        if(job.status === 'paused') {
            return formatDuration((job.updatedAt - job.createdAt) / 1000);
        }

        return formatDuration((end - job.createdAt) / 1000);
    }

    // FIX: Removed 'override' modifier to fix build error.
    static styles = [sharedStyles, css`
        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 12px;
            border-bottom: 1px solid var(--border-color);
            flex-shrink: 0;
            cursor: pointer;
            user-select: none;
        }
        .panel-header h4 { margin: 0; font-weight: 500; }
        .job-list {
            padding: 12px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 1rem;
            flex-grow: 1;
        }
        .job-item {
            background-color: var(--bg-input);
            padding: 1rem;
            border-radius: 6px;
            border-left: 4px solid var(--border-color);
        }
        .job-item.status-running { border-left-color: var(--accent-primary); }
        .job-item.status-completed { border-left-color: var(--color-success); }
        .job-item.status-failed, .job-item.status-cancelled { border-left-color: var(--color-error); }
        .job-item.status-paused { border-left-color: var(--color-warning); }

        .job-header { display: flex; justify-content: space-between; align-items: center; }
        .job-name { font-weight: 500; }
        .job-status { font-size: 0.8rem; text-transform: capitalize; }
        
        .progress-bar {
            height: 6px;
            background: var(--bg-panel-solid);
            border-radius: 3px;
            overflow: hidden;
            margin: 0.5rem 0;
        }
        .progress-bar-fill {
            height: 100%;
            background: var(--accent-primary);
            width: 0%;
            transition: width 0.3s;
        }

        .job-meta {
            display: flex;
            justify-content: space-between;
            font-size: 0.75rem;
            color: var(--text-secondary);
        }

        .job-actions {
            margin-top: 0.75rem;
            display: flex;
            gap: 0.5rem;
        }
        .job-actions button {
            font-size: 0.75rem;
            padding: 4px 8px;
        }
        details summary {
            cursor: pointer;
            font-size: 0.85rem;
            color: var(--text-secondary);
        }
    `];

    // FIX: Removed 'override' modifier to fix build error.
    render() {
        const activeJobs = this.jobs.filter(j => ['queued', 'running', 'paused'].includes(j.status));
        const recentJobs = this.jobs.filter(j => !['queued', 'running', 'paused'].includes(j.status));

        return html`
            <div class="panel-header" @click=${() => this.isOpen = !this.isOpen}>
                <h4>Render Recovery (${activeJobs.length})</h4>
                <button class="icon-button">${this.isOpen ? '−' : '+'}</button>
            </div>
            <div class="job-list">
                ${activeJobs.length === 0 && recentJobs.length === 0 ? html`<p class="sub-label" style="text-align: center;">No active or recent jobs.</p>` : ''}

                ${activeJobs.map(job => html`
                    <div class="job-item status-${job.status}">
                        <div class="job-header">
                            <span class="job-name">${job.name}</span>
                            <span class="job-status">${job.status}</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-bar-fill" style="width: ${job.progress}%"></div>
                        </div>
                        <div class="job-meta">
                            <span>Elapsed: ${this._getElapsedTime(job)}</span>
                            <span>Attempts: ${job.attempts}</span>
                        </div>
                        <div class="job-actions">
                            ${job.status === 'running' ? html`<button @click=${() => jobQueueService.pause(job.id)}>Pause</button>` : ''}
                            ${job.status === 'paused' ? html`<button @click=${() => jobQueueService.resume(job.id)}>Resume</button>` : ''}
                            <button @click=${() => jobQueueService.cancel(job.id)} class="ghost" style="border-color: var(--color-warning);">Cancel</button>
                        </div>
                    </div>
                `)}

                ${recentJobs.length > 0 ? html`
                    <details>
                        <summary>Recent Jobs (${recentJobs.length})</summary>
                        ${recentJobs.map(job => html`
                             <div class="job-item status-${job.status}" style="margin-top: 0.5rem;">
                                <div class="job-header">
                                    <span class="job-name">${job.name}</span>
                                    <span class="job-status">${job.status}</span>
                                </div>
                                ${job.error ? html`<p class="error-message" style="font-size: 0.75rem; padding: 0.5rem; margin: 0.5rem 0 0;">${job.error}</p>` : ''}
                                <div class="job-meta" style="margin-top: 0.5rem;">
                                    <span>Finished: ${new Date(job.updatedAt).toLocaleTimeString()}</span>
                                    <span>Duration: ${this._getElapsedTime(job)}</span>
                                </div>
                                <div class="job-actions">
                                    ${job.status === 'failed' || job.status === 'cancelled' ? html`<button @click=${() => jobQueueService.retry(job.id)}>Retry</button>` : ''}
                                </div>
                            </div>
                        `)}
                    </details>
                `: ''}
            </div>
        `;
    }
    
    // FIX: Removed 'override' modifier to fix build error.
    createRenderRoot() {
        return this;
    }
}

// Add global styles for positioning the non-shadow-DOM component
const style = document.createElement('style');
style.textContent = `
    .render-recovery-panel-host {
        position: fixed;
        bottom: 0;
        right: 1.5rem;
        width: 400px;
        max-height: 50vh;
        transform: translateY(calc(100% - 45px));
        background: var(--bg-panel-solid);
        border: 1px solid var(--border-color);
        border-bottom: none;
        border-radius: 8px 8px 0 0;
        z-index: 100;
        display: flex;
        flex-direction: column;
        transition: transform 0.3s ease-in-out;
        box-shadow: 0 0 20px rgba(0,0,0,0.5);
    }
    .render-recovery-panel-host.open {
        transform: translateY(0);
    }
`;
document.head.appendChild(style);