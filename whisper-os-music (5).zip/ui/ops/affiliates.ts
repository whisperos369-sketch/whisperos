/**
 * @fileoverview Service stubs for Affiliate and Talent Portal integration.
 */
import { env } from '../config/env.ts';

const AFFILIATE_PORTAL_URL = env.AFFILIATE_PORTAL_URL || '/api/affiliate';

export async function registerAffiliate(data: any) {
  return fetch(AFFILIATE_PORTAL_URL, { 
      method:"POST", 
      headers:{ "Content-Type":"application/json" }, 
      body: JSON.stringify({ action:"register", data })
  });
}

export async function trackReferral(clickId: string, orderId: string, amount: number) {
  return fetch(AFFILIATE_PORTAL_URL, { 
      method:"POST", 
      headers:{ "Content-Type":"application/json" }, 
      body: JSON.stringify({ action:"track", clickId, orderId, amount })
  });
}