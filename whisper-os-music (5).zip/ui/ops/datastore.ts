/**
 * @fileoverview A simple, local-first data store using IndexedDB via idb-keyval.
 */
import { set, get } from "idb-keyval";
export const storeSet = set;
export const storeGet = get;

// Recommended keys for consistency: 
// "droppacks", "social.accounts", "revenue", "abuse", 
// "trends.cache", "scheduler.jobs", "settings"
