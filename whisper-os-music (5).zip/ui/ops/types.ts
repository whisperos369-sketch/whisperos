/**
 * @fileoverview Domain models for the Whisper OS business operations layer.
 */
export type Currency = "USD"|"AED"|"EUR"|"GBP";
export interface DropItem { 
    id: string; 
    title: string; 
    baseCost: number; 
    images: string[]; 
    supplier?: string; 
    pod?: "printify"|"printful"|null; 
    tags: string[]; 
}
export interface DropPack { 
    id: string; 
    name: string; 
    items: DropItem[]; 
    launchAt: string; 
    priceStrategy: "margin"|"fixed"; 
    margin?: number; 
    fixedPrice?: number; 
    region?: "UAE"|"USA"|"UK"|"DE"| "GLOBAL"; 
}
export interface TrendInsight { 
    platform: "tiktok"|"instagram"|"youtube"|"market"; 
    topic: string; 
    score: number; 
    evidence: string[]; 
}
export interface SocialAccount { 
    platform: "tiktok"|"instagram"|"facebook"|"youtube"; 
    handle: string; 
    enabled: boolean; 
}
export interface RevenueRecord { 
    ts: string; 
    sku: string; 
    price: number; 
    cost: number; 
    currency: Currency; 
    channel: string; 
    orderId: string; 
    refundable: boolean; 
}
export interface AbuseEvent { 
    ts: string; 
    orderId: string; 
    reason: string; 
    flag: "watch"|"block"|"review"; 
}

export interface Job {
    id: string;
    title: string;
    runAt: string;
    payload: any;
    status: "queued"|"done"|"failed";
}

export interface Settings {
  defaultMargin: number;
  returnsDays: number;
  numerology: {
    enabled: boolean;
    primary: number;
    secondary: number;
    colors: string[];
    symbols: string[];
  };
  regions: string[];
}