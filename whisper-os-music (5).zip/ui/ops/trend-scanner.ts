/**
 * @fileoverview Service for scanning market and social media trends.
 */
import { storeGet, storeSet } from "./datastore.ts";
import type { TrendInsight } from "./types.ts";
import { env } from '../config/env.ts';

const TRENDS_SEARCH_URL = env.TRENDS_SEARCH_URL || '/api/trends/search';
const TRENDS_WEEKLY_REPORT_URL = env.TRENDS_WEEKLY_REPORT || '/api/trends/weekly';

export async function scanTrends(query="smart gadgets"): Promise<TrendInsight[]> {
  try {
    const res = await fetch(TRENDS_SEARCH_URL, { 
      method:"POST", 
      headers:{ "Content-Type":"application/json" }, 
      body: JSON.stringify({ query })
    });
    if (!res.ok) {
        console.warn("Trend search API failed, returning cached data.");
        return await storeGet("trends.cache") ?? [];
    }
    const data = await res.json();
    await storeSet("trends.cache", data);
    return data;
  } catch(e) {
    console.error("Error fetching trends:", e);
    return await storeGet("trends.cache") ?? [];
  }
}

export async function weeklyTrendReport() { 
    return fetch(TRENDS_WEEKLY_REPORT_URL, { method:"POST" }); 
}