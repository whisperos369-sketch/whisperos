/**
 * @fileoverview Service for firing analytics pixels.
 */
import { env } from '../config/env.ts';

const PIXEL_META_URL = env.PIXEL_META || '/api/pixel/meta';
const PIXEL_TIKTOK_URL = env.PIXEL_TIKTOK || '/api/pixel/tiktok';

export async function fireMeta(event: string, payload: any) {
  return fetch(PIXEL_META_URL, { 
      method:"POST", 
      headers:{ "Content-Type":"application/json" }, 
      body: JSON.stringify({ event, payload })
  });
}

export async function fireTikTok(event: string, payload: any) {
  return fetch(PIXEL_TIKTOK_URL, { 
      method:"POST", 
      headers:{ "Content-Type":"application/json" }, 
      body: JSON.stringify({ event, payload })
  });
}