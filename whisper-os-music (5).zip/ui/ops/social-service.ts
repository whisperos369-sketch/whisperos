/**
 * @fileoverview Service for social media account management and autoposting.
 */
import { storeGet, storeSet } from "./datastore.ts";
import type { SocialAccount } from "./types.ts";
import { env } from '../config/env.ts';

export async function getAccounts(): Promise<SocialAccount[]> { 
    return (await storeGet("social.accounts")) ?? []; 
}

export async function setAccounts(a: SocialAccount[]) { 
    await storeSet("social.accounts", a); 
}

export async function autopost(platform: SocialAccount["platform"], payload: any) {
  const map: Record<SocialAccount["platform"], string | undefined> = {
    tiktok: env.SOCIAL_TIKTOK_PROXY,
    instagram: env.SOCIAL_INSTAGRAM_PROXY,
    facebook: env.SOCIAL_FACEBOOK_PROXY,
    youtube: env.SOCIAL_YOUTUBE_PROXY
  };
  const url = map[platform];
  if (!url) {
      throw new Error(`Proxy URL for platform "${platform}" is not configured.`);
  }
  return fetch(url, { 
      method:"POST", 
      headers:{ "Content-Type":"application/json" }, 
      body: JSON.stringify(payload) 
  });
}