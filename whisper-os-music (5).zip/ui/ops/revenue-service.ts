/**
 * @fileoverview Service for tracking revenue, profit, and abuse events.
 */
import { storeGet, storeSet } from "./datastore.ts";
import type { RevenueRecord, AbuseEvent } from "./types.ts";

export async function addRevenue(r: RevenueRecord) {
  const list: RevenueRecord[] = (await storeGet("revenue")) ?? [];
  list.push(r);
  await storeSet("revenue", list);
}

export async function listRevenue(): Promise<RevenueRecord[]> { 
    return (await storeGet("revenue")) ?? []; 
}

export async function grossProfit(): Promise<number> { 
    const r = await listRevenue(); 
    return r.reduce((acc: number, x: RevenueRecord) => acc + (x.price - x.cost), 0); 
}

export async function flagAbuse(e: AbuseEvent) {
  const list: AbuseEvent[] = (await storeGet("abuse")) ?? [];
  list.push(e);
  await storeSet("abuse", list);
}

export async function listAbuse(): Promise<AbuseEvent[]> { 
    return (await storeGet("abuse")) ?? []; 
}
