/**
 * @fileoverview Service hooks for suppliers and Print-on-Demand (POD) providers.
 */
import { env } from '../config/env.ts';

const SUPPLIER_SEARCH_URL = env.SUPPLIER_SEARCH_URL || '/api/suppliers/search';
const POD_PRINTIFY_URL = env.POD_PRINTIFY_URL || '/api/pod/printify';
const POD_PRINTFUL_URL = env.POD_PRINTFUL_URL || '/api/pod/printful';

export async function searchSuppliers(query: string) {
  return fetch(SUPPLIER_SEARCH_URL, { 
      method:"POST", 
      headers:{ "Content-Type":"application/json" }, 
      body: JSON.stringify({ query })
  });
}

export async function podCreatePrintifySku(payload: any) {
  return fetch(POD_PRINTIFY_URL, { 
      method:"POST", 
      headers:{ "Content-Type":"application/json" }, 
      body: JSON.stringify(payload)
  });
}

export async function podCreatePrintfulSku(payload: any) {
  return fetch(POD_PRINTFUL_URL, { 
      method:"POST", 
      headers:{ "Content-Type":"application/json" }, 
      body: JSON.stringify(payload)
  });
}