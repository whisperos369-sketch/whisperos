/**
 * @fileoverview Service for managing product drop packs.
 */
import dayjs from "dayjs";
import { storeGet, storeSet } from "./datastore.ts";
import type { DropPack, DropItem } from "./types.ts";
import { getSettings } from "./settings-service.ts";

export async function listDropPacks(): Promise<DropPack[]> { 
    return (await storeGet("droppacks")) ?? []; 
}

export async function saveDropPack(dp: DropPack) { 
    const list = await listDropPacks(); 
    const idx = list.findIndex(x => x.id === dp.id); 
    if(idx >= 0) list[idx] = dp; else list.push(dp); 
    await storeSet("droppacks", list); 
}

export async function addItemToPack(packId: string, item: DropItem) { 
    const list = await listDropPacks(); 
    const p = list.find(x => x.id === packId); 
    if (!p) throw new Error("pack not found"); 
    p.items.push(item); 
    await storeSet("droppacks", list); 
}

export function computePrice(item: DropItem, pack: DropPack, settingsMargin?: number) {
  if (pack.priceStrategy === "fixed" && pack.fixedPrice) return pack.fixedPrice;
  const margin = pack.margin ?? settingsMargin ?? 0.2;
  return Math.round((item.baseCost * (1 + margin)) * 100) / 100;
}

export function isLaunchable(pack: DropPack) { 
    return dayjs(pack.launchAt).isBefore(dayjs().add(5,"minute")); 
}
