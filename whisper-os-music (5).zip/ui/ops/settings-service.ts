/**
 * @fileoverview Service for managing global Whisper OS settings.
 */
import { storeGet, storeSet } from "./datastore.ts";
import type { Settings } from "./types.ts";
import { env } from '../config/env.ts';

export async function getSettings(): Promise<Settings> {
  const s = await storeGet("settings");
  return s ?? { 
    defaultMargin: parseFloat(env.DEFAULT_PROFIT_MARGIN), 
    returnsDays: parseInt(env.DEFAULT_RETURN_DAYS, 10),
    numerology: { 
      enabled: true, 
      primary: 8, 
      secondary: 3, 
      colors:["gold","purple","royalblue"], 
      symbols:["∞","third-eye","spiral"] 
    }, 
    regions:["UAE","USA","UK","DE"] 
  };
}

export async function updateSettings(p: Partial<Settings>){ const s = await getSettings(); await storeSet("settings", { ...s, ...p }); }