import {css, html, LitElement, nothing} from 'lit';
import {customElement, property, state} from 'lit/decorators.js';
import {consume} from '@lit/context';
import {appContext, AppContext} from '../context.ts';
import {aiService} from '../ai-service.ts';
import {sharedStyles} from '../shared-styles.ts';
import type { SongState } from '../sections.ts';

type VideoTemplate = 'audiogram' | 'spectrum' | 'lyric-kinetic' | 'lyric-minimal';
type VideoAspectRatio = '16:9' | '1:1' | '9:16';

@customElement('video-module')
export class VideoModule extends LitElement {
  @consume({context: appContext, subscribe: true})
  private _app!: AppContext;
  
  @property({attribute:false}) project!: SongState;
  
  @state() private audioUrl: string = '';
  @state() private imageUrl: string = '';
  @state() private template: VideoTemplate = 'spectrum';
  @state() private aspectRatio: VideoAspectRatio = '16:9';
  @state() private loading = false;
  @state() private error = '';
  @state() private videoUrl: string | null = null;
  
  // FIX: Removed 'override' modifier to fix build error.
  static styles = [sharedStyles, css`
    .grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: var(--spacing-lg);
        max-width: 900px;
    }
    .preview {
        aspect-ratio: 16 / 9;
        background: #0f172a;
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius);
        display: flex;
        align-items: center;
        justify-content: center;
    }
    video {
        width: 100%;
        height: 100%;
        object-fit: contain;
        border-radius: var(--border-radius);
    }
    .config {
        display: flex;
        flex-direction: column;
        gap: var(--spacing-md);
    }
  `];

  private async _generate() {
    if (!this.audioUrl || !this.imageUrl) {
        this.error = 'Please select a mastered mix and a cover image.';
        return;
    }
    this.loading = true;
    this.error = '';
    this.videoUrl = null;
    try {
        const res = await aiService.videoGen({
            audioUrl: this.audioUrl,
            imageUrl: this.imageUrl,
            template: this.template,
            target: this.aspectRatio,
        });
        this.videoUrl = res.videoUrl;
        
        // Also update the project state
        if (this._app && this._app.songState) {
          const newVisuals = { ...this._app.songState.visuals, videoUrl: res.videoUrl };
          this._app.updateCurrentSong({ visuals: newVisuals });
        }
    } catch (e: any) {
        this.error = e?.message ?? 'Video generation failed.';
    } finally {
        this.loading = false;
    }
  }

  // FIX: Removed 'override' modifier to fix build error.
  render() {
    if (!this.project) return nothing;
    
    // Use latest mix as default audio if available
    const latestAudio = this.project.audio.latestMix;
    const latestCover = this.project.visuals?.coverArtUrl;
    if (!this.audioUrl && latestAudio) {
        this.audioUrl = latestAudio;
    }
    if (!this.imageUrl && latestCover) {
        this.imageUrl = latestCover;
    }


    return html`
    <div class="panel">
      <h2 class="page-title">Video Generator</h2>
      <div class="grid">
        <div class="preview">
            ${this.videoUrl 
                ? html`<video controls src=${this.videoUrl}></video>`
                : html`<p style="color: #64748b;">Video preview will appear here</p>`
            }
        </div>
        <div class="config">
            <div>
                <label>Mastered Mix
                    <select .value=${this.audioUrl} @change=${(e:any) => this.audioUrl = e.target.value}>
                        <option value="">Select an audio version</option>
                        ${this.project.versions.map(v => html`<option value=${v.url}>${v.label}</option>`)}
                        ${latestAudio ? html`<option value=${latestAudio}>Latest Mix</option>` : ''}
                    </select>
                </label>
            </div>
             <div>
                <label>Cover Art Image URL
                    <input type="text" .value=${this.imageUrl} @input=${(e: any) => this.imageUrl = e.target.value} placeholder="Paste image URL here...">
                </label>
            </div>
            <div class="row">
                <div>
                    <label>Template
                        <select .value=${this.template} @change=${(e:any) => this.template = e.target.value}>
                            <option value="spectrum">Spectrum</option>
                            <option value="audiogram">Audiogram</option>
                            <option value="lyric-kinetic">Kinetic Lyrics</option>
                            <option value="lyric-minimal">Minimal Lyrics</option>
                        </select>
                    </label>
                </div>
                <div>
                    <label>Aspect Ratio
                        <select .value=${this.aspectRatio} @change=${(e:any) => this.aspectRatio = e.target.value}>
                            <option value="16:9">16:9 (YouTube)</option>
                            <option value="1:1">1:1 (Instagram Post)</option>
                            <option value="9:16">9:16 (TikTok/Reels)</option>
                        </select>
                    </label>
                </div>
            </div>
             <button @click=${this._generate} ?disabled=${this.loading} class="primary">
                ${this.loading ? 'Rendering Video...' : 'Render Video'}
            </button>
            ${this.error ? html`<div class="error-message">${this.error}</div>` : nothing}
        </div>
      </div>
    </div>
    `;
  }
}