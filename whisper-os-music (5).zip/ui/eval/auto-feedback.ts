/**
 * @fileoverview Logic for automated evaluation and feedback loops.
 */
import { emit } from "../core/bus.ts";

export interface EvalResult {
    score: number;
    notes: string[];
    actions: { key: string; value: unknown }[];
}

export function applyFeedback(io: Record<string,unknown>, evalResult: EvalResult){
  emit({ type: "EVALUATION_READY", score: evalResult.score, notes: evalResult.notes });
  // Simple heuristic: if score < 0.8, trigger reloop hint via actions
  if (evalResult.score < 0.8) {
    emit({ type: "RELOOP_TRIGGERED", reason: evalResult.notes[0] ?? "quality below threshold" });
  }
  for (const a of evalResult.actions) { io[a.key] = a.value; }
  return io;
}