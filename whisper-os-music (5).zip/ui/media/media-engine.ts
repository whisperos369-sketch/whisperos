/**
 * @fileoverview A unified, event-driven service for managing all media assets.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

type AudioRef = { url: string; kind: "stem"|"mix"; label?: string };
type VideoRef = { url: string; poster?: string };

export class MediaEngine extends EventTarget {
  audio: AudioRef[] = [];
  video?: VideoRef;

  private _emitUpdate() {
    this.dispatchEvent(new CustomEvent('update'));
  }

  addStem(url: string, label: string) {
    this.audio.push({ url, kind: "stem", label });
    this._emitUpdate();
  }

  setMix(url: string) {
    const existingIndex = this.audio.findIndex(a => a.kind === 'mix');
    if (existingIndex > -1) {
        this.audio[existingIndex] = { url, kind: "mix" };
    } else {
        this.audio.push({ url, kind:"mix" });
    }
    this._emitUpdate();
  }

  setVideo(url: string, poster?: string) {
    this.video = { url, poster };
    this._emitUpdate();
  }

  reset() {
    this.audio = [];
    this.video = undefined;
    this._emitUpdate();
  }
}

export const mediaEngine = new MediaEngine();