/**
 * @fileoverview A professional, persistent media player component.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {html, css, LitElement, svg, nothing} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {consume} from '@lit/context';

import {appContext, AppContext} from './context.ts';
import {formatDuration} from '../utils.ts';
import {sharedStyles} from './shared-styles.ts';
import '../volume-control.ts';
// The visualizer is now its own component
import './audio-visualizer.ts';

type VisualizerType = 'spectrum' | 'waveform' | 'particles';

@customElement('media-player')
export class MediaPlayer extends LitElement {
    @consume({context: appContext, subscribe: true})
    private _app!: AppContext;
    
    @state() private visualizerType: VisualizerType = 'spectrum';
    
    // FIX: Removed 'override' modifier to fix build error.
    static styles = [sharedStyles, css`
        :host {
            display: block;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: var(--player-height);
            background: var(--bg-panel);
            backdrop-filter: var(--backdrop-blur);
            -webkit-backdrop-filter: var(--backdrop-blur);
            border-top: 1px solid var(--border-color);
            z-index: 20;
            padding: 1rem 1.5rem;
            display: grid;
            grid-template-columns: 1fr 2fr 1fr;
            align-items: center;
            gap: 1.5rem;
        }

        .track-info { display: flex; align-items: center; gap: 1rem; min-width: 0; }
        .cover-art { width: 60px; height: 60px; border-radius: 4px; background-color: var(--bg-input); overflow: hidden; flex-shrink: 0; }
        .cover-art img { width: 100%; height: 100%; object-fit: cover; }
        .title-artist { min-width: 0; }
        .title-artist h4 { margin: 0; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .title-artist p { margin: 0; font-size: 0.8rem; color: var(--text-secondary); }

        .transport-controls { display: flex; flex-direction: column; align-items: center; gap: 0.5rem; }
        .main-controls { display: flex; align-items: center; gap: 1rem; }
        .play-button { width: 48px; height: 48px; border-radius: 50%; background-color: var(--accent-primary); color: var(--bg-main); }
        .play-button:hover { background-color: var(--accent-primary-hover); }

        .time-and-waveform { width: 100%; display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 0.8rem; }
        .timecode { font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-secondary); }
        .waveform-container { position: relative; height: 50px; cursor: pointer; background: var(--bg-input); border-radius: 4px; overflow: hidden; }
        
        .visualizer-selector {
            position: absolute;
            top: 4px;
            right: 4px;
            z-index: 1;
        }
        .visualizer-selector select {
            font-size: 0.75rem;
            padding: 2px 4px;
            background: rgba(10, 10, 26, 0.5);
            border: 1px solid var(--border-color);
            border-radius: 4px;
            color: var(--text-secondary);
        }
        .visualizer-selector select:focus {
            box-shadow: 0 0 0 2px var(--glow-color-secondary);
            border-color: var(--accent-secondary);
        }

        .meta-controls { display: flex; justify-content: flex-end; align-items: center; gap: 1rem; }
        .kv { display: flex; align-items: center; gap: 0.5rem; }
        .kv label { margin: 0; font-size: 0.8rem; }
        .kv input, .kv select { padding: 4px 8px; font-size: 0.8rem; width: 80px; }
    `];

    private _handleSeek(e: MouseEvent) {
        if (!this._app || this._app.currentTrack.duration === 0) return;
        
        const target = e.currentTarget as HTMLElement;
        const rect = target.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const width = rect.width;
        const percentage = clickX / width;
        
        const newTime = this._app.currentTrack.duration * percentage;
        this._app.setCurrentTime(newTime);
    }
    
    // FIX: Removed 'override' modifier to fix build error.
    render() {
        if (!this._app || !this._app.songState) return nothing;
        const { meta } = this._app.songState;
        const { currentTrack, isPlaying, currentTime, analyserNode } = this._app;
        
        return html`
            <div class="track-info">
                <div class="cover-art">
                    ${currentTrack.coverArtUrl ? html`<img src=${currentTrack.coverArtUrl} alt="Cover Art">` : nothing}
                </div>
                <div class="title-artist">
                    <h4 title=${currentTrack.title || 'Untitled'}>${currentTrack.title || 'Untitled'}</h4>
                    <p>${currentTrack.artist || 'Unknown Artist'}</p>
                </div>
            </div>
            <div class="transport-controls">
                <div class="main-controls">
                     <button class="icon-button" title="Previous Marker">${svg`<svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/></svg>`}</button>
                    <button class="icon-button play-button" @click=${this._app.togglePlay} title=${isPlaying ? 'Pause' : 'Play'}>
                        ${isPlaying 
                            ? svg`<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M14 19h4V5h-4v14zm-6 0h4V5H8v14z"/></svg>`
                            : svg`<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>`
                        }
                    </button>
                    <button class="icon-button" title="Next Marker">${svg`<svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M16 6h2v12h-2zm-3.5 6l-8.5 6V6z"/></svg>`}</button>
                </div>
                <div class="time-and-waveform">
                    <span class="timecode">${formatDuration(currentTime)}</span>
                    <div class="waveform-container" @click=${this._handleSeek}>
                        <audio-visualizer
                            .analyserNode=${analyserNode}
                            .type=${this.visualizerType}
                            .isPlaying=${isPlaying}
                        ></audio-visualizer>
                        <div class="visualizer-selector">
                            <select .value=${this.visualizerType} @change=${(e: Event) => this.visualizerType = (e.target as HTMLSelectElement).value as VisualizerType}>
                                <option value="spectrum">Spectrum</option>
                                <option value="waveform">Waveform</option>
                                <option value="particles">Particles</option>
                            </select>
                        </div>
                    </div>
                    <span class="timecode">${formatDuration(currentTrack.duration)}</span>
                </div>
            </div>
            <div class="meta-controls">
                 <div class="kv">
                    <label>BPM</label><input type="number" .value=${String(meta.bpm)} @change=${(e:any)=>{ this._app.updateCurrentSong({ meta: {...meta, bpm: Number(e.target.value)} })}}/>
                    <label>Key</label>
                    <select .value=${meta.key} @change=${(e:any)=>{ this._app.updateCurrentSong({ meta: {...meta, key: e.target.value} })}}>
                        ${['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'].map(k => html`<option>${k}</option>`)}
                    </select>
                </div>
                <volume-control></volume-control>
            </div>
        `;
    }
}