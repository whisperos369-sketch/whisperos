// remix-lab-module.ts
import {html, css} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {consume} from '@lit/context';
import {appContext, AppContext} from '../context.ts';
import type { SongState } from '../sections.ts';
import { aiService } from '../services/ai-service.ts';
import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';

@customElement('remix-lab-module')
export class RemixLabModule extends StudioModule