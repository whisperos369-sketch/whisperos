/**
 * @fileoverview A Command Palette component for quick actions and navigation.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { css, html, LitElement, nothing } from 'lit';
import { customElement, state, query, property } from 'lit/decorators.js';
import { consume } from '@lit/context';
import { classMap } from 'lit/directives/class-map.js';

import { appContext, AppContext } from '../context.ts';
import { sharedStyles } from '../shared-styles.ts';
import { projectStore } from '../project-store.ts';

type Command = {
  id: string;
  title: string;
  category: string;
  icon?: string;
  action: () => void;
};

@customElement('command-palette')
export class CommandPalette extends LitElement {
  @consume({ context: appContext, subscribe: true })
  private _app!: AppContext;

  @property({ attribute: false })
  public setView: (view: string) => void = () => {};

  @state() private isOpen = false;
  @state() private searchTerm = '';
  @state() private selectedIndex = 0;
  @state() private allCommands: Command[] = [];
  @state() private filteredCommands: Command[] = [];

  @query('input') private inputEl!: HTMLInputElement;

  static override styles = [
    sharedStyles,
    css`
      .command-palette-overlay {
        position: fixed;
        inset: 0;
        background-color: rgba(10, 10, 26, 0.6);
        backdrop-filter: var(--backdrop-blur);
        display: flex;
        align-items: flex-start;
        justify-content: center;
        z-index: 3000;
        padding-top: 15vh;
      }
      .command-palette {
        width: 100%;
        max-width: 600px;
        background-color: var(--bg-panel-solid);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }
      .search-input-wrapper {
        padding: var(--spacing-md);
        border-bottom: 1px solid var(--border-color);
      }
      .search-input-wrapper input {
        width: 100%;
        font-size: 1.1rem;
        background: transparent;
        border: none;
      }
      .search-input-wrapper input:focus {
        box-shadow: none;
      }
      .command-list {
        max-height: 400px;
        overflow-y: auto;
        padding: var(--spacing-sm);
      }
      .command-group-header {
        font-size: 0.8rem;
        font-weight: 500;
        color: var(--text-secondary);
        padding: var(--spacing-md) var(--spacing-md) var(--spacing-xs);
        text-transform: uppercase;
      }
      .command-item {
        display: flex;
        align-items: center;
        gap: var(--spacing-md);
        padding: var(--spacing-md);
        border-radius: var(--border-radius);
        cursor: pointer;
        user-select: none;
      }
      .command-item.selected {
        background-color: var(--accent-primary);
        color: var(--text-on-accent);
      }
    `,
  ];

  public async open() {
    this.isOpen = true;
    this.searchTerm = '';
    this.selectedIndex = 0;
    await this.updateComplete;
    this.inputEl.focus();
    this._loadCommands();
  }

  public close() {
    this.isOpen = false;
  }

  private async _loadCommands() {
    const staticCommands: Command[] = [
      { id: 'nav-studio', title: 'Navigate to Studio', category: 'Navigation', action: () => this.setView('studio') },
      { id: 'nav-presets', title: 'Navigate to Presets', category: 'Navigation', action: () => this.setView('presets') },
      { id: 'nav-remix', title: 'Navigate to Remix & LoRA', category: 'Navigation', action: () => this.setView('remix-lora') },
      { id: 'nav-releases', title: 'Navigate to Releases', category: 'Navigation', action: () => this.setView('releases') },
      { id: 'nav-settings', title: 'Navigate to Settings', category: 'Navigation', action: () => this.setView('settings') },
      { id: 'nav-meditation', title: 'Navigate to Meditation Generator', category: 'Navigation', action: () => this.setView('meditation')},
      { id: 'new-song', title: 'Create New Song', category: 'Actions', action: () => this._app.createNewSong() },
      { id: 'save-song', title: 'Save Current Song', category: 'Actions', action: () => this._app.saveCurrentSong() },
    ];

    const projects = await projectStore.getAll();
    const projectCommands: Command[] = projects.map(p => ({
      id: `load-${p.id}`,
      title: `Load: ${p.meta.title}`,
      category: 'Projects',
      action: () => this._app.loadSong(p.id),
    }));

    this.allCommands = [...staticCommands, ...projectCommands];
    this._filterCommands();
  }

  private _filterCommands() {
    if (!this.searchTerm) {
      this.filteredCommands = this.allCommands;
      return;
    }
    const lowerSearch = this.searchTerm.toLowerCase();
    this.filteredCommands = this.allCommands.filter(cmd =>
      cmd.title.toLowerCase().includes(lowerSearch) || cmd.category.toLowerCase().includes(lowerSearch)
    );
    this.selectedIndex = 0;
  }

  private _handleInput(e: Event) {
    this.searchTerm = (e.target as HTMLInputElement).value;
    this._filterCommands();
  }

  private _handleKeydown(e: KeyboardEvent) {
    if (e.key === 'Escape') {
      this.close();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      this.selectedIndex = (this.selectedIndex + 1) % this.filteredCommands.length;
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      this.selectedIndex = (this.selectedIndex - 1 + this.filteredCommands.length) % this.filteredCommands.length;
    } else if (e.key === 'Enter') {
      e.preventDefault();
      this._executeSelectedCommand();
    }
  }

  private _executeCommand(command: Command) {
    command.action();
    this.close();
  }

  private _executeSelectedCommand() {
    const command = this.filteredCommands[this.selectedIndex];
    if (command) {
      this._executeCommand(command);
    }
  }

  override render() {
    if (!this.isOpen) {
      return nothing;
    }

    const groupedCommands = this.filteredCommands.reduce((acc, cmd) => {
      if (!acc[cmd.category]) {
        acc[cmd.category] = [];
      }
      acc[cmd.category].push(cmd);
      return acc;
    }, {} as Record<string, Command[]>);

    return html`
      <div class="command-palette-overlay" @click=${this.close}>
        <div class="command-palette" @click=${(e: Event) => e.stopPropagation()}>
          <div class="search-input-wrapper">
            <input
              type="text"
              placeholder="Type a command or search..."
              .value=${this.searchTerm}
              @input=${this._handleInput}
              @keydown=${this._handleKeydown}
            />
          </div>
          <div class="command-list">
            ${Object.entries(groupedCommands).map(([category, commands]) => html`
              <div class="command-group">
                <div class="command-group-header">${category}</div>
                ${commands.map((cmd) => {
                  const globalIndex = this.filteredCommands.findIndex(c => c.id === cmd.id);
                  return html`
                    <div
                      class="command-item ${classMap({ selected: this.selectedIndex === globalIndex })}"
                      @click=${() => this._executeCommand(cmd)}
                    >
                      ${cmd.title}
                    </div>
                  `;
                })}
              </div>
            `)}
          </div>
        </div>
      </div>
    `;
  }
}
