// ui/components/songwriting-module.ts
import {css, html, nothing} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {consume} from '@lit/context';
import {appContext, AppContext} from '../context.ts';
import type { SongState } from '../sections.ts';
import { aiService, type LyricDraft } from '../services/ai-service.ts';
import { sharedStyles } from '../../shared-styles.ts';
import { StudioModule } from '../../studio-module.ts';

@customElement('songwriting-module')
export class SongwritingModule extends StudioModule {
  @consume({context: appContext, subscribe: true})
  private _app!: AppContext;

  // State for Full Draft Generator
  @state() private draftPrompt = 'Write a verse and chorus for a hip-hop track about ambition and overcoming obstacles.';
  @state() private drafts: LyricDraft[] = [];

  // State for LyriQ Muse
  @state() private isMuseOpen = false;
  @state() private musePrompt = 'a metaphor for a fading memory';
  @state() private museSuggestions: string[] = [];
  @state() private isGeneratingMuseSuggestions = false;
  @state() private museError = '';


  static styles = [sharedStyles, css`
    .panel {
      padding: var(--spacing-xl);
      max-width: 1200px;
      margin: 0 auto;
    }
    
    .editor-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--spacing-md);
    }

    .main-lyrics-editor {
        width: 100%;
        min-height: 400px;
        font-family: var(--font-mono);
        font-size: 1rem;
        line-height: 1.6;
        padding: var(--spacing-lg);
        resize: vertical;
        background-color: var(--bg-input);
        border: 1px solid var(--border-color);
        margin-bottom: var(--spacing-lg);
    }

    .main-lyrics-editor:focus {
      border-color: var(--accent-primary);
      box-shadow: 0 0 0 3px var(--glow-color);
    }

    /* Generator Section Refinement */
    details.generator-section {
        background-color: transparent;
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius);
        margin-top: var(--spacing-xl);
        transition: var(--transition-fast);
    }

    details.generator-section[open] {
        background-color: var(--bg-panel);
        border-color: var(--border-color-strong);
    }

    details.generator-section > summary {
        font-size: 1.1rem;
        font-weight: 600;
        padding: var(--spacing-md) var(--spacing-lg);
        cursor: pointer;
        list-style: none;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: var(--text-secondary);
    }
    details.generator-section > summary:hover {
        color: var(--text-primary);
    }
    details.generator-section > summary::-webkit-details-marker {
        display: none;
    }
    details.generator-section > summary::after {
        content: '▸';
        transition: transform 0.2s;
    }
    details.generator-section[open] > summary::after {
        transform: rotate(90deg);
    }
    details.generator-section[open] > summary {
        border-bottom: 1px solid var(--border-color);
    }

    .generator-content {
        padding: var(--spacing-lg);
    }

    .generator-controls {
        padding-bottom: var(--spacing-lg);
    }

    .generator-actions {
        display: flex;
        justify-content: flex-end;
        margin-top: 1rem;
    }

    .generator-results {
        padding-top: var(--spacing-lg);
        border-top: 1px solid var(--border-color);
    }
    
    /* Drafts Grid */
    .drafts-grid { 
      display: grid; 
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); 
      gap: var(--spacing-lg); 
      margin-top: var(--spacing-xl);
    }

    .draft-card { 
      border: 1px solid var(--border-color); 
      border-radius: var(--border-radius); 
      background: var(--bg-input); 
      display: flex;
      flex-direction: column;
      transition: var(--transition-fast);
    }
    .draft-card:hover {
        border-color: var(--border-color-strong);
        transform: translateY(-2px);
        box-shadow: 0 4px 15px var(--shadow-color);
    }
    .draft-card-header {
        padding: var(--spacing-sm) var(--spacing-md);
        border-bottom: 1px solid var(--border-color);
        font-weight: 500;
        color: var(--text-secondary);
        font-size: 0.85rem;
    }
    .draft-card pre {
      white-space: pre-wrap;
      word-wrap: break-word;
      font-family: var(--font-mono);
      flex-grow: 1;
      padding: var(--spacing-md);
      margin: 0;
      color: var(--text-secondary);
      font-size: 0.9rem;
    }
    .draft-card-footer {
        padding: var(--spacing-sm) var(--spacing-md);
        border-top: 1px solid var(--border-color);
        display: flex;
        justify-content: flex-end;
    }

    /* LyriQ Muse Modal */
    .muse-suggestions {
        margin-top: var(--spacing-lg);
        max-height: 250px;
        overflow-y: auto;
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius);
    }
    .suggestion-item {
        padding: var(--spacing-md);
        cursor: pointer;
        border-bottom: 1px solid var(--border-color);
        transition: background-color 0.2s;
    }
    .suggestion-item:last-child {
        border-bottom: none;
    }
    .suggestion-item:hover {
        background-color: var(--bg-hover);
    }
    .modal-footer {
        margin-top: var(--spacing-lg);
        text-align: right;
    }
  `];

  private async _generateDrafts() {
    this.drafts = [];
    const task = async () => {
      const res = await aiService.lyricsDraft({ prompt: this.draftPrompt });
      this.drafts = res.drafts;
      return res;
    };
    
    await this._performTask('Generate Lyric Drafts', [
        { message: 'Sending prompt to LLM service...', duration: 1000 },
        { message: 'Generating lyrical concepts...', duration: 2500 },
    ], task);
  }

  private _adopt(i: number) {
    const draft = this.drafts[i];
    if (!draft || !this._app.songState) return;
    this._app.updateCurrentSong({ lyrics: draft.text });
    this._app.showToast('Lyrics adopted!', 'success');
  }

  private _handleLyricsChange(e: Event) {
    const text = (e.target as HTMLTextAreaElement).value;
    this._app.updateCurrentSong({ lyrics: text });
  }

  // --- LyriQ Muse Methods ---
  private _openMuseModal() {
    this.isMuseOpen = true;
    this.museSuggestions = [];
    this.museError = '';
  }

  private _closeMuseModal() {
    this.isMuseOpen = false;
  }

  private async _generateMuseSuggestions() {
    if (!this._app.songState) return;
    this.isGeneratingMuseSuggestions = true;
    this.museSuggestions = [];
    this.museError = '';

    try {
        const currentLyrics = this._app.songState.lyrics ?? '';
        // Get the last 4 lines for context, or fewer if not available
        const lastLines = currentLyrics.split('\n').slice(-4).join('\n');

        const fullPrompt = `
          Based on the following recent lyrics:
          ---
          ${lastLines.trim() ? lastLines : '(No prior lyrics)'}
          ---
          Provide 5 creative and interesting suggestions for the next line, focusing on: ${this.musePrompt}.
          Return only a JSON array of strings, like ["suggestion one", "suggestion two", ...].
        `;
        
        // This would ideally call a specific LLM service for this task
        // We'll simulate it for now.
        await new Promise(r => setTimeout(r, 1200));
        this.museSuggestions = [
            `a photograph slowly turning to sepia`,
            `the echo of a forgotten name`,
            `like ink bleeding on a wet page`,
            `a ghost ship sailing on a sea