import { css, html, LitElement, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';
import { settingsService, type SettingsData, type VramProbeResult } from '../services/settings.ts';
import { aiService } from '../services/ai-service.ts';

@customElement('settings-tab')
export class SettingsTab extends StudioModule {
  @state() private settings: Partial<SettingsData> = {};
  @state() private saveStatus = '';
  private saveTimeout: number | undefined;
  @state() private vramProbeResult: VramProbeResult | null = null;
  @state() private isProbingVram = false;
  @state() private githubCommitMessage = '';

  // FIX: Removed 'override' modifier to fix build error.
  async firstUpdated() {
    this.isLoading = true;
    try {
      this.settings = await settingsService.getSettings();
    } catch (e) {
      this.errorMessage = (e as Error).message;
    } finally {
      this.isLoading = false;
    }
  }

  private _handleInput(path: string, value: any) {
    const keys = path.split('.');
    const newSettings = { ...this.settings };
    let current: any = newSettings;
    
    for (let i = 0; i < keys.length - 1; i++) {
      if (!current[keys[i]]) current[keys[i]] = {};
      current = current[keys[i]];
    }
    current[keys[keys.length - 1]] = value;
    
    this.settings = newSettings;
  }

  private async _saveSettings() {
    this.isLoading = true;
    this.saveStatus = '';
    this.errorMessage = '';
    try {
      await settingsService.saveSettings(this.settings);
      this.saveStatus = 'Settings saved successfully!';
      this.settings = await settingsService.getSettings();
      clearTimeout(this.saveTimeout);
      this.saveTimeout = window.setTimeout(() => this.saveStatus = '', 3000);
    } catch (e) {
      this.errorMessage = `Failed to save: ${(e as Error).message}`;
    } finally {
      this.isLoading = false;
    }
  }

  private async _handleVramProbe() {
      this.isProbingVram = true;
      this.vramProbeResult = null;
      try {
          this.vramProbeResult = await settingsService.probeVram();
      } catch (e) {
          this.errorMessage = `VRAM probe failed: ${(e as Error).message}`;
      } finally {
          this.isProbingVram = false;
      }
  }

  private async _handleGithubSync() {
      const task = async () => {
          const res = await aiService.syncToGithub({ commitMessage: this.githubCommitMessage || 'Sync from Whisper OS', branch: 'main' });
          // FIX: Cast 'this' to LitElement to access dispatchEvent
          (this as LitElement).dispatchEvent(new CustomEvent('show-toast', { detail: { message: `Synced to GitHub! Commit: ${res.commitUrl.slice(-7)}`, type: 'success' }, bubbles: true, composed: true }));
          return res;
      };
      await this._performTask("Sync to GitHub", [{ message: "Committing and pushing changes...", duration: 2000 }], task);
  }

  static override styles = [sharedStyles, css`
    .panel {
      padding: var(--spacing-xl);
      max-width: 900px;
      margin: 0 auto;
    }
    .agent-toggles {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }
    .toggle-group {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: var(--bg-input);
        padding: 0.8rem 1rem;
        border-radius: var(--border-radius);
    }
  `];

  // FIX: Removed 'override' modifier to fix build error.
  render() {
    const agents: {id: string, name: string}[] = [
      { id: 'hook-architect', name: 'Hook Architect' },
      { id: 'emotional-conductor', name: 'Emotional Conductor' },
      { id: 'groove-surgeon', name: 'Groove Surgeon' },
      { id: 'spatial-sound-architect', name: 'Spatial Architect' },
    ];

    return html`
      <div class="panel">
        <h2 class="page-title">Settings & System</h2>
        
        <div class="control-group">
            <h3>Agent Pipeline</h3>
            <p class="sub-label">Enable or disable specific creative agents in the orchestration pipeline to customize the generation process.</p>
            <div class="agent-toggles">
                ${agents.map(agent => html`
                    <div class="toggle-group">
                        <label for="toggle-${agent.id}">${agent.name}</label>
                        <label class="toggle-switch">
                            <input type="checkbox" id="toggle-${agent.id}" 
                                .checked=${(this.settings as any)?.agents?.[agent.id]?.enabled ?? true}
                                @change=${(e: any) => this._handleInput(`agents.${agent.id}.enabled`, e.target.checked)}>
                            <span class="slider"></span>
                        </label>
                    </div>
                `)}
            </div>
        </div>

        <div class="control-group">
          <h3>Version Control</h3>
          <p class="sub-label">Configure GitHub integration to save and track project versions.</p>
          <div class="row">
            <div>
              <label>GitHub Personal Access Token</label>
              <input type="password" placeholder="Enter new token..." .value=${this.settings.keys?.GITHUB_PAT || ''} @input=${(e: any) => this._handleInput('keys.GITHUB_PAT', e.target.value)}>
            </div>
            <div>
              <label>Commit Message</label>
              <input type="text" placeholder="e.g., 'Updated synth lead'" .value=${this.githubCommitMessage} @input=${(e: any) => this.githubCommitMessage = e.target.value}>
            </div>
          </div>
          <button @click=${this._handleGithubSync} ?disabled=${this.isLoading} style="margin-top: 1rem;">
            Sync to GitHub
          </button>
        </div>
        
        <div class="control-group" style="text-align: right;">
          <button @click=${this._saveSettings} ?disabled=${this.isLoading} class="primary">
            ${this.isLoading ? 'Saving...' : 'Save All Settings'}
          </button>
          ${this.saveStatus ? html`<span style="color: var(--color-success); margin-left: 1rem;">${this.saveStatus}</span>` : ''}
          ${this.renderErrorMessage()}
        </div>
      </div>
    `;
  }
}
