import { css, html, LitElement } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';
import { publisherService, type Job } from '../services/publisher.ts';

@customElement('schedule-board')
export class ScheduleBoard extends StudioModule {
  @state() private jobs: Job[] = [];
  @state() private filter: "all" | "pending" | "running" | "done" | "failed" = "pending";

  // FIX: Removed 'override' modifier to fix build error.
  async firstUpdated() {
    this._loadJobs();
  }

  private async _loadJobs() {
    this.isLoading = true;
    try {
      this.jobs = await publisherService.listJobs(this.filter);
    } catch (e) {
      this.errorMessage = (e as Error).message;
    } finally {
      this.isLoading = false;
    }
  }
  
  private async _cancelJob(jobId: string) {
    if (!confirm("Are you sure you want to cancel this scheduled job?")) return;
    try {
      await publisherService.cancelJob(jobId);
      this._loadJobs(); // Refresh the list
    } catch (e) {
      this.errorMessage = `Failed to cancel job: ${(e as Error).message}`;
    }
  }

  static override styles = [sharedStyles, css`
    .panel {
      padding: var(--spacing-xl);
      max-width: 900px;
      margin: 0 auto;
    }
  `];
}
