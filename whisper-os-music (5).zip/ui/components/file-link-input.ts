/**
 * @fileoverview A reusable component for selecting a file via upload or URL.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { css, html, LitElement } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { sharedStyles } from '../shared-styles.ts';

type InputType = 'file' | 'link';

@customElement('file-link-input')
export class FileLinkInput extends LitElement {
    @property({ type: Boolean }) showRadioToggle = true;
    // FIX: Add id property to satisfy template bindings
    @property({ type: String }) id = '';

    @state() private inputType: InputType = 'file';
    @state() private isLoading = false;
    @state() private statusMessage = '';
    @state() private statusType: 'success' | 'error' | '' = '';
    @state() private linkUrl = '';

    // FIX: Removed 'override' modifier to fix build error.
    static styles = [
        sharedStyles,
        css`
        .file-link-input-controls {
            display: flex;
            gap: 0.5rem;
        }
        .cors-warning {
            font-size: 0.75rem;
            color: var(--text-tertiary);
            margin-top: 0.5rem;
        }
        .file-link-status {
            font-size: 0.8rem;
            margin-top: 0.5rem;
        }
        .file-link-status.success { color: var(--color-success); }
        .file-link-status.error { color: var(--color-error); }
        `
    ];

    private _dispatchFile(file: File | null, isLoading = false) {
        // FIX: Cast `this` to LitElement to access dispatchEvent
        (this as LitElement).dispatchEvent(new CustomEvent('file-change', {
            detail: { file, isLoading },
            bubbles: true,
            composed: true,
        }));
    }

    private _handleFileChange(e: Event) {
        const input = e.target as HTMLInputElement;
        const file = input.files?.[0] || null;
        if (file) {
            this.statusMessage = `Selected: ${file.name}`;
            this.statusType = 'success';
            this._dispatchFile(file);
        }
    }

    private async _handleFetchLink() {
        if (!this.linkUrl.trim()) {
            this.statusMessage = 'Please enter a URL.';
            this.statusType = 'error';
            return;
        }

        try {
            // This will throw an error if the URL is not valid.
            new URL(this.linkUrl);
        } catch (_) {
            this.statusMessage = 'Invalid URL. Please enter a full, valid URL including http:// or https://.';
            this.statusType = 'error';
            this._dispatchFile(null, false);
            return;
        }

        this.isLoading = true;
        this.statusMessage = 'Fetching file...';
        this.statusType = '';
        this._dispatchFile(null, true);

        try {
            // This fetch can be blocked by CORS.
            const response = await fetch(this.linkUrl);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const blob = await response.blob();
            const fileName = this.linkUrl.substring(this.linkUrl.lastIndexOf('/') + 1) || 'downloaded_file';
            const file = new File([blob], fileName, { type: blob.type });

            this.statusMessage = `Fetched: ${file.name}`;
            this.statusType = 'success';
            this._dispatchFile(file);

        } catch (error) {
            console.error('Error fetching file:', error);
            this.statusMessage = 'Fetch failed. This is likely a CORS issue. Please download the file and use the "Upload File" option.';
            this.statusType = 'error';
            this._dispatchFile(null);
        } finally {
            this.isLoading = false;
        }
    }
    
    // FIX: Removed 'override' modifier to fix build error.
    firstUpdated() {
        if (!this.showRadioToggle) {
            this.inputType = 'file';
        }
    }
    
    private _handleInputTypeChange(e: Event) {
        this.inputType = (e.target as HTMLInputElement).value as InputType;
        this.statusMessage = '';
        this.statusType = '';
        this.linkUrl = '';
        this._dispatchFile(null);
    }

    // FIX: Removed 'override' modifier to fix build error.
    render() {
        return html`
            <div class="file-link-input-container">
                ${this.showRadioToggle ? html`
                    <div class="radio-group">
                        <label>
                            <input type="radio" name="inputType-${this.id}" value="file" .checked=${this.inputType === 'file'} @change=${this._handleInputTypeChange}>
                            <span>Upload File</span>
                        </label>
                        <label>
                            <input type="radio" name="inputType-${this.id}" value="link" .checked=${this.inputType === 'link'} @change=${this._handleInputTypeChange}>
                            <span>Paste Link</span>
                        </label>
                    </div>
                ` : ''}

                ${this.inputType === 'file' ? html`
                    <input type="file" accept="audio/*,video/*" @change=${this._handleFileChange} ?disabled=${this.isLoading}>
                ` : html`
                    <div class="file-link-input-controls" style="margin-top: 0.5rem;">
                        <input type="text" placeholder="https://..." .value=${this.linkUrl} @input=${(e: Event) => this.linkUrl = (e.target as HTMLInputElement).value} ?disabled=${this.isLoading}>
                        <button @click=${this._handleFetchLink} ?disabled=${this.isLoading}>Fetch</button>
                    </div>
                    <div class="cors-warning">
                        Note: Fetching from a link may fail due to browser security (CORS).
                    </div>
                `}
                <div class="file-link-status ${ifDefined(this.statusType)}">${this.statusMessage}</div>
            </div>
        `;
    }
}
