// ui/components/music-module.ts
import {css, html} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {consume} from '@lit/context';
import {appContext, AppContext} from '../context.ts';
import type { SongState } from '../sections.ts';
import { sharedStyles } from '../../shared-styles.ts';
import { StudioModule } from '../../studio-module.ts';
import { aiService } from '../services/ai-service.ts';

@customElement('music-module')
export class MusicModule extends StudioModule {
  @consume({context: appContext, subscribe: true})
  private _app!: AppContext;
  
  @state() private prompt = 'dark cinematic hip-hop, heavy 808s, halftime groove';
  @state() private url?: string;
  @state() private duration = 12;

  // Chunked rendering state
  @state() private useChunkedRendering = false;
  @state() private segmentSeconds = 8;
  @state() private crossfadeMs = 300;
  @state() private maxSegments = 6;
  @state() private model: 'musicgen-medium' | 'musicgen-large' | 'ace-step' = 'musicgen-large';


  private async _generate() {
    if (!this._app || !this._app.songState) return;
    this.url = undefined;

    const isAce = this.model === 'ace-step';

    if (isAce) {
        // ACE-Step doesn't support chunked rendering in this stub
        await this._generateAceStep();
    } else if (this.useChunkedRendering) {
        await this._generateChunked();
    } else {
        await this._generateSingle();
    }
  }

  private async _generateSingle() {
      const task = async () => {
        const res = await aiService.musicGen({
          prompt: this.prompt,
          duration: this.duration,
          model: this.model,
        });

        this.url = res.url;
        this._app.updateCurrentSong({
            audio: { ...this._app.songState!.audio, latestMix: res.url },
        });
        return res;
      };
      
      await this._performTask('Generate Instrumental (Single Shot)', [
          { message: `Requesting ${this.model} model...`, duration: 1000 },
          { message: 'Generating audio waveform...', duration: 8000 },
          { message: 'Finalizing audio...', duration: 2000 },
      ], task);
  }

  private async _generateChunked() {
      const targetDuration = this.segmentSeconds * this.maxSegments;
      const task = async () => {
        // The service for chunked generation is currently stubbed to musicgen
        const res = await (aiService as any).generateMusicChunked({
          prompt: this.prompt,
          segmentSeconds: this.segmentSeconds,
          crossfadeMs: this.crossfadeMs,
          maxSegments: this.maxSegments,
          model: this.model,
        });

        this.url = res.url;
         this._app.updateCurrentSong({
            audio: { ...this._app.songState!.audio, latestMix: res.url },
        });
        this._app.showToast(res.note || `Chunked render complete (${res.segments} segments).`, 'success');
        return res;
      };
      
      await this._performTask(`Generate Instrumental (Chunked, ~${targetDuration}s)`, [
          { message: `Requesting ${this.model} model...`, duration: 1000 },
          { message: 'Generating audio segments...', duration: 15000 },
          { message: 'Stitching and crossfading...', duration: 3000 },
      ], task);
  }
  
  private async _generateAceStep() {
      const task = async () => {
        const res = await aiService.aceGenerate({
          prompt: this.prompt,
          style: 'cinematic', // Style is a required param for ACE stub
        });
        this.url = res.url;
        this._app.updateCurrentSong({
            audio: { ...this._app.songState!.audio, latestMix: res.url },
        });
        return res;
      };
      await this._performTask('Generate with ACE-Step', [
          { message: 'Sending request to ACE-Step service...', duration: 1000 },
          { message: 'ACE-Step is processing...', duration: 3000 },
      ], task);
  }

  static override styles = [sharedStyles, css`
    .panel {
        padding: var(--spacing-xl);
        max-width: 800px;
        margin: 0 auto;
    }
  `];

  render() {
    if (!this._app?.songState) return html`<p>Loading...</p>`;
    
    return html`
      <div class="panel">
        <h2 class="page-title">Music Generation</h2>
        <div class="well">
            <div class="row" style="grid-template-columns: 1fr;">
              <div>
                <label>Prompt</label>
                <textarea .value=${this.prompt} @input=${(e:any)=>this.prompt=e.target.value} rows="3" ?disabled=${this.isLoading}></textarea>
              </div>
              <div class="row">
                <div>
                  <label>Duration (seconds)</label>
                  <input type="number" .value=${String(this.duration)} @input=${(e:any)=>this.duration=Number(e.target.value)} ?disabled=${this.isLoading || this.useChunkedRendering || this.model === 'ace-step'}>
                </div>
                 <div>
                    <label>Model</label>
                    <select .value=${this.model} @change=${(e:any)=>this.model=e.target.value} ?disabled=${this.isLoading}>
                        <option value="musicgen-medium">MusicGen Medium (Balanced)</option>
                        <option value="musicgen-large">MusicGen Large (Highest Quality)</option>
                        <option value="ace-step">ACE-Step 3.5B (Experimental)</option>
                    </select>
                </div>
              </div>
            </div>
            
            <div style="text-align: right; margin-top: 1.5rem;">
                <button @click=${this._generate} ?disabled=${this.isLoading} class="primary">
                    ${this.isLoading ? 'Generating...' : 'Generate Instrumental'}
                </button>
            </div>
        </div>
        
        ${this.renderProgressIndicator()}
        ${this.renderErrorMessage()}
        
        ${this.url ? html`
            <div class="control-group" style="margin-top: 2rem;">
                <h4>Generated Track</h4>
                <audio controls src=${this.url} style="width: 100%"></audio>
            </div>
        `:''}
      </div>
    `;
  }
}
