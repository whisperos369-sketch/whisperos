import { css, html, LitElement } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';
import { publisherService } from '../services/publisher.ts';
import { llmService } from '../services/llm.ts';

const PLATFORMS = ["YouTube", "TikTok", "Facebook", "Instagram", "SoundCloud"];

@customElement('publisher-tab')
export class PublisherTab extends StudioModule {
  @state() private assetUrl = 'https://storage.googleapis.com/vimeo-test/work-8496162-V1.mp4';
  @state() private coverUrl = 'https://placehold.co/512x512/7e22ce/ffffff?text=Cover';
  // FIX: Renamed state property from 'title' to 'trackTitle' to avoid conflict with HTMLElement.title
  @state() private trackTitle = 'My New Track';
  @state() private tags = 'electronic, synthwave, instrumental';
  @state() private description = '';
  @state() private selectedPlatforms: string[] = ["YouTube", "TikTok"];
  @state() private scheduleTime = '';

  private _handlePlatformToggle(platform: string) {
    if (this.selectedPlatforms.includes(platform)) {
      this.selectedPlatforms = this.selectedPlatforms.filter(p => p !== platform);
    } else {
      this.selectedPlatforms = [...this.selectedPlatforms, platform];
    }
  }
  
  private async _generateCopy() {
    if (this.selectedPlatforms.length === 0) {
      this.errorMessage = "Please select at least one platform.";
      return;
    }

    const task = async () => {
        const platform = this.selectedPlatforms[0]; // Generate for the first selected platform as an example
        const res = await llmService.captions({
            platform: platform.toLowerCase(),
            // FIX: Use renamed state property
            track_meta: { title: this.trackTitle, tags: this.tags.split(',').map(t => t.trim()) }
        });
        this.description = res.caption;
        if (res.hashtags && res.hashtags.length > 0) {
          this.tags = res.hashtags.join(', ');
        }
    };
    await this._performTask("Generate Social Copy", [
      {message: `Generating copy for ${this.selectedPlatforms[0]}...`, duration: 2500}
    ], task);
  }

  private async _publish() {
    const isScheduled = !!this.scheduleTime;
    const task = async () => {
      const payload = {
        platforms: this.selectedPlatforms,
        asset_url: this.assetUrl,
        cover_url: this.coverUrl,
        // FIX: Use renamed state property
        title: this.trackTitle,
        tags: this.tags.split(',').map(t => t.trim()),
        description: this.description,
      };

      if (isScheduled) {
        await publisherService.schedule({
            ...payload,
            schedule: { datetime: new Date(this.scheduleTime).toISOString(), timezone: "UTC" }
        });
      } else {
        await publisherService.publishNow(payload);
      }
    };

    await this._performTask(isScheduled ? "Scheduling Post" : "Publishing Now", [
        { message: isScheduled ? "Sending job to scheduler..." : "Dispatching to platforms...", duration: 2000 }
    ], task);
  }

  static override styles = [sharedStyles, css`
    .panel {
      padding: var(--spacing-xl);
      max-width: 900px;
      margin: 0 auto;
    }
    .platform-selector {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
    }
  `];

  // FIX: Removed 'override' modifier to fix build error.
  render() {
    return html`
      <div class="panel">
        <h2 class="page-title">Social Publisher</h2>
        <div class="well">
          <div class="control-group">
            <label>Platforms</label>
            <div class="platform-selector">
              ${PLATFORMS.map(p => html`
                <button 
                    class="ghost ${this.selectedPlatforms.includes(p) ? 'active' : ''}"
                    @click=${() => this._handlePlatformToggle(p)}>
                    ${p}
                </button>
              `)}
            </div>
          </div>

          <div class="row">
            <div><label>Asset URL (Video/Audio)</label><input type="text" .value=${this.assetUrl} @input=${(e:any) => this.assetUrl = e.target.value}></div>
            <div><label>Cover Art URL</label><input type="text" .value=${this.coverUrl} @input=${(e:any) => this.coverUrl = e.target.value}></div>
          </div>
          <div class="row" style="margin-top: 1rem;">
            <div><label>Title</label><input type="text" .value=${this.trackTitle} @input=${(e:any) => this.trackTitle = e.target.value}></div>
            <div><label>Tags / Hashtags (comma-separated)</label><input type="text" .value=${this.tags} @input=${(e:any) => this.tags = e.target.value}></div>
          </div>
          <div class="row" style="margin-top: 1rem;">
            <div style="grid-column: 1 / -1;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                <label style="margin-bottom: 0;">Description / Caption</label>
                <button class="ghost" @click=${this._generateCopy} ?disabled=${this.isLoading}>Generate Copy</button>
              </div>
              <textarea rows="5" .value=${this.description} @input=${(e:any) => this.description = e.target.value}></textarea>
            </div>
          </div>
          
          <div style="border-top: 1px solid var(--border-color); margin-top: 1.5rem; padding-top: 1.5rem; display: flex; justify-content: flex-end; align-items: center; gap: 1rem;">
            <div>
              <label>Schedule (Optional)</label>
              <input type="datetime-local" .value=${this.scheduleTime} @input=${(e:any) => this.scheduleTime = e.target.value}>
            </div>
            <button @click=${this._publish} ?disabled=${this.isLoading || this.selectedPlatforms.length === 0} class="primary">
              ${this.scheduleTime ? 'Schedule Post' : 'Post Now'}
            </button>
          </div>
          
          ${this.renderProgressIndicator()}
          ${this.renderErrorMessage()}
        </div>
      </div>
    `;
  }
}
