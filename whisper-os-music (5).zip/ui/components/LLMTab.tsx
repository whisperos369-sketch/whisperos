import { css, html, LitElement } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';
import { llmService } from '../services/llm.ts';
import { settingsService } from '../services/settings.ts';

type LlmTask = "songwriting" | "cover_caption" | "video_desc" | "hashtags" | "vocal_direction";

@customElement('llm-tab')
export class LLMTab extends StudioModule {
  @state() private provider = 'gemini';
  @state() private task: LlmTask = 'songwriting';
  @state() private prompt = 'An upbeat pop song about a summer road trip.';
  @state() private result = '';

  // FIX: Removed 'override' modifier to fix build error.
  async firstUpdated() {
    // Load the user's preferred provider from settings
    try {
      const settings = await settingsService.getSettings();
      this.provider = (settings as any).llm_provider || 'gemini';
    } catch (e) {
      console.error("Could not load LLM provider setting:", e);
    }
  }

  private async _generate() {
    this.result = '';
    const task = async () => {
      const res = await llmService.compose({
        provider: this.provider,
        task: this.task,
        prompt: this.prompt,
      });
      this.result = res.text;
      return res;
    };
    
    await this._performTask('LLM Composition', [
        { message: 'Sending request to LLM connector...', duration: 1000 },
        { message: `Provider '${this.provider}' is processing...`, duration: 3000 },
    ], task);
  }

  static override styles = [sharedStyles, css`
    .panel {
      padding: var(--spacing-xl);
      max-width: 900px;
      margin: 0 auto;
    }
    .result-box {
        margin-top: 1.5rem;
        padding: 1rem;
        background-color: var(--bg-input);
        border: 1px solid var(--border-color);
        border-radius: var(--border-radius);
        white-space: pre-wrap;
        word-wrap: break-word;
        font-family: var(--font-mono);
        min-height: 100px;
    }
  `];

  // FIX: Removed 'override' modifier to fix build error.
  render() {
    return html`
      <div class="panel">
        <h2 class="page-title">LLM Connector</h2>
        <div class="well">
          <div class="row">
            <div>
              <label>Provider</label>
              <select .value=${this.provider} @change=${(e: any) => this.provider = e.target.value}>
                <option value="gemini">Google Gemini</option>
                <option value="openai">OpenAI (Stub)</option>
                <option value="claude">Anthropic Claude (Stub)</option>
                <option value="local">Local Model (Stub)</option>
              </select>
            </div>
            <div>
              <label>Task Preset</label>
              <select .value=${this.task} @change=${(e: any) => this.task = e.target.value}>
                <option value="songwriting">Songwriting</option>
                <option value="cover_caption">Cover Art Caption</option>
                <option value="video_desc">Video Description</option>
                <option value="hashtags">Hashtags</option>
                <option value="vocal_direction">Vocal Direction</option>
              </select>
            </div>
          </div>
          <div class="row" style="margin-top: 1rem;">
            <div style="grid-column: 1 / -1;">
              <label>Prompt</label>
              <textarea .value=${this.prompt} @input=${(e: any) => this.prompt = e.target.value} rows="4"></textarea>
            </div>
          </div>
          <div style="text-align: right; margin-top: 1rem;">
            <button @click=${this._generate} ?disabled=${this.isLoading} class="primary">
              ${this.isLoading ? 'Generating...' : 'Generate'}
            </button>
          </div>
        </div>

        ${this.renderProgressIndicator()}
        ${this.renderErrorMessage()}

        ${this.result ? html`
          <div class="result-box">
            ${this.result}
          </div>
        `: ''}
      </div>
    `;
  }
}
