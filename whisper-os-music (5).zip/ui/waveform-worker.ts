/**
 * @fileoverview A web worker for calculating waveform peaks off the main thread.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

self.onmessage = (e: MessageEvent<{ channelData: ArrayBuffer; targetPeakCount: number }>) => {
    const { channelData, targetPeakCount } = e.data;
    const data = new Float32Array(channelData);
    // Use the passed targetPeakCount, fallback to 1024 if not provided.
    const peaks = calculatePeaks(data, targetPeakCount || 1024);
    self.postMessage({ peaks });
};

function calculatePeaks(data: Float32Array, targetPeakCount: number): number[][] {
    const peaks: number[][] = [];
    const dataLength = data.length;
    const chunkSize = Math.floor(dataLength / targetPeakCount);
    
    if (chunkSize < 1) { // Handle very short audio
        for(let i=0; i<dataLength; i++) {
            peaks.push([data[i], data[i]]);
        }
        return peaks;
    }

    for (let i = 0; i < targetPeakCount; i++) {
        const start = i * chunkSize;
        const end = start + chunkSize;
        let min = 0.0;
        let max = 0.0;

        for (let j = start; j < end; j++) {
            const value = data[j];
            if (value > max) {
                max = value;
            }
            if (value < min) {
                min = value;
            }
        }
        peaks.push([min, max]);
    }
    return peaks;
}