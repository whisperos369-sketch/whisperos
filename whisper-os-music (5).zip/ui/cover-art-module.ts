import {css, html, LitElement, nothing} from 'lit';
import {customElement, property, state} from 'lit/decorators.js';
import {classMap} from 'lit/directives/class-map.js';
import {consume} from '@lit/context';
import {appContext, AppContext, Lora} from '../context.ts';
import {aiService} from '../ai-service.ts';
import {sharedStyles} from '../shared-styles.ts';

type GeneratedImage = {
  url: string;
  score: number;
};

@customElement('cover-art-module')
export class CoverArtModule extends LitElement {
  @consume({context: appContext, subscribe: true})
  private _app!: AppContext;

  @state() private prompt = 'An abstract, vibrant, synthwave-inspired album cover';
  @state() private negative = 'blurry, text, watermark, ugly';
  @state() private numImages = 4;
  @state() private applyGlobalLoraStack = true;
  @state() private generatedImages: GeneratedImage[] = [];
  @state() private pickedUrl: string | null = null;
  @state() private loading = false;
  @state() private error = '';

  // FIX: Removed 'override' modifier to fix build error.
  static styles = [sharedStyles, css`
    .grid {
      display: grid;
      grid-template-columns: 1fr 320px;
      gap: var(--spacing-lg);
    }
    .main-content {
      display: flex;
      flex-direction: column;
      gap: var(--spacing-md);
    }
    .image-gallery {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: var(--spacing-md);
      margin-top: var(--spacing-md);
    }
    .image-container {
      position: relative;
      cursor: pointer;
      border-radius: var(--border-radius);
      overflow: hidden;
      border: 2px solid transparent;
      transition: border-color 0.2s;
    }
    .image-container.picked {
      border-color: var(--accent-primary);
      box-shadow: 0 0 10px var(--glow-color);
    }
    .image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .image-overlay {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
      padding: var(--spacing-sm);
      color: white;
      font-size: 0.8rem;
    }
  `];
  
  private async _generate() {
    this.loading = true;
    this.error = '';
    this.generatedImages = [];
    this.pickedUrl = null;
    try {
      const res = await aiService.coverArt({
        prompt: this.prompt,
        negative: this.negative,
        numImages: this.numImages,
        loras: this.applyGlobalLoraStack ? this._app.songState?.loraStack : []
      });
      this.generatedImages = res.images;
      this.pickedUrl = res.pickedUrl;
      // Update the project state with the new cover art
      if (this.pickedUrl && this._app.songState) {
        const visuals = { ...this._app.songState.visuals, coverArtUrl: this.pickedUrl };
        this._app.updateCurrentSong({ visuals });
      }
    } catch (e: any) {
      this.error = e?.message ?? 'Cover art generation failed.';
    } finally {
      this.loading = false;
    }
  }

  // FIX: Removed 'override' modifier to fix build error.
  render() {
    return html`
    <div class="panel">
      <h2 class="page-title">Cover Art</h2>
      <div class="grid">
        <div class="main-content">
          <div>
            <label>Prompt
              <textarea .value=${this.prompt} @input=${(e: any) => this.prompt = e.target.value}></textarea>
            </label>
          </div>
          <div>
            <label>Negative Prompt
              <textarea .value=${this.negative} @input=${(e: any) => this.negative = e.target.value}></textarea>
            </label>
          </div>
          <div class="image-gallery">
            ${this.generatedImages.map(img => html`
              <div class="image-container ${classMap({picked: this.pickedUrl === img.url})}" @click=${() => this.pickedUrl = img.url}>
                <img src=${img.url} alt=${this.prompt}>
                <div class="image-overlay">Score: ${img.score.toFixed(4)}</div>
              </div>
            `)}
          </div>
          ${this.error ? html`<div class="error-message">${this.error}</div>` : nothing}
        </div>
        <aside>
          <div>
            <label>Batch Size
              <select .value=${String(this.numImages)} @change=${(e: any) => this.numImages = Number(e.target.value)}>
                <option>1</option><option>4</option><option>6</option><option>9</option>
              </select>
            </label>
          </div>
          <div>
            <label>
              <input type="checkbox" .checked=${this.applyGlobalLoraStack} @change=${(e: any) => this.applyGlobalLoraStack = e.target.checked}>
              Apply Global LoRA Stack
            </label>
            <p class="sub-label">Uses the global LoRA stack configured in the right inspector panel.</p>
          </div>
          <button @click=${this._generate} ?disabled=${this.loading} style="margin-top: 16px; width: 100%;" class="primary">
            ${this.loading ? 'Generating...' : 'Generate Cover Art'}
          </button>
        </aside>
      </div>
      </div>
    `;
  }
}