/**
 * @fileoverview The "Agents Dashboard" module for monitoring the multi-agent system.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { html, css, svg } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { consume } from '@lit/context';
import { classMap } from 'lit/directives/class-map.js';

import { sharedStyles } from '../shared-styles.ts';
import { StudioModule } from '../studio-module.ts';
import { appContext, AppContext, AgentName, AgentState } from '../context.ts';
import { OrchestratorAgent } from '../orchestrator.ts';

@customElement('agents-dashboard-module')
export class AgentsDashboardModule extends StudioModule {
    @consume({ context: appContext, subscribe: true })
    private _app!: AppContext;

    @property({ attribute: false })
    orchestrator!: OrchestratorAgent;

    @state() private autoSyncEnabled = false;

    static override styles = [
      sharedStyles,
      css`
        .flow-diagram {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
            margin: 2rem 0;
            padding: 1rem;
            background-color: var(--bg-input);
            border-radius: 12px;
        }
        .flow-node {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
            min-width: 100px;
        }
        .node-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--border-color);
            transition: all 0.3s ease;
        }
        .node-icon.idle { border-color: var(--text-tertiary); }
        .node-icon.working {
            border-color: var(--accent-primary);
            box-shadow: 0 0 15px var(--glow-color);
            animation: pulse 1.5s infinite;
        }
        .node-icon.complete { border-color: var(--color-success); background-color: var(--color-success); }
        .node-icon.error { border-color: var(--color-error); background-color: var(--color-error); }
        
        .node-icon svg { width: 24px; height: 24px; fill: var(--text-primary); }
        .node-icon.complete svg, .node-icon.error svg { fill: var(--bg-main); }
        .node-label { font-size: 0.8rem; font-weight: 500; color: var(--text-secondary); }
        
        .flow-arrow { color: var(--text-tertiary); }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 var(--glow-color); }
            70% { box-shadow: 0 0 0 10px rgba(0, 255, 255, 0); }
            100% { box-shadow: 0 0 0 0 rgba(0, 255, 255, 0); }
        }

        .agent-status-list {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 1rem;
        }
        .status-item {
            display: contents; /* Makes this a grid sub-item container */
        }
        .status-item > div {
            padding: 0.8rem 1rem;
            background-color: var(--bg-input);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
        }
        .status-item:first-child > div { border-top-left-radius: 8px; border-top-right-radius: 8px; }
        .status-item:last-child > div { border-bottom: none; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; }

        .agent-name {
            font-weight: 500;
        }
        .agent-status-message {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }
        .status-indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 0.8rem;
        }
        .status-indicator.idle { background-color: var(--text-tertiary); }
        .status-indicator.working { background-color: var(--accent-primary); }
        .status-indicator.complete { background-color: var(--color-success); }
        .status-indicator.error { background-color: var(--color-error); }
      `
    ];

    private _getNodeIconForState(state: AgentState) {
        switch (state) {
            case 'idle': return svg`<svg viewBox="0 0 24 24"><path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4Z" /></svg>`;
            case 'working': return svg`<svg class="spinner" viewBox="0 0 50 50"><circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle></svg>`;
            case 'complete': return svg`<svg viewBox="0 0 24 24"><path d="M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41 10.59L10 14.17L17.59 6.58L19 8L10 17Z" /></svg>`;
            case 'error': return svg`<svg viewBox="0 0 24 24"><path d="M12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12C22,6.48 17.52,2 12,2M13,17H11V15H13V17M13,13H11V7H13V13Z" /></svg>`;
        }
    }

    private _renderFlowNode(agent: AgentName, label: string) {
        const status = this._app.agentStatus[agent].status;
        return html`
            <div class="flow-node">
                <div class="node-icon ${status}">${this._getNodeIconForState(status)}</div>
                <div class="node-label">${label}</div>
            </div>
        `;
    }

    render() {
        if (!this._app) return html`<p>Loading...</p>`;

        const { agentStatus } = this._app;
        
        return html`
            <div class="panel">
                <h2 class="page-title">Agents Dashboard</h2>
                <div class="control-group">
                    <h3>Orchestration Flow</h3>
                    <div class="flow-diagram">
                        ${this._renderFlowNode('lyrics', 'Lyrics')}
                        <div class="flow-arrow">→</div>
                        ${this._renderFlowNode('music', 'Music')}
                        <div class="flow-arrow">→</div>
                        ${this._renderFlowNode('mastering', 'Mastering')}
                        <div class="flow-arrow">→</div>
                        ${this._renderFlowNode('cover', 'Cover Art')}
                        <div class="flow-arrow">→</div>
                        ${this._renderFlowNode('video', 'Video')}
                    </div>
                </div>

                <div class="control-group">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <h3>Agent Status</h3>
                        <div class="toggle-switch-container">
                            <label class="toggle-switch">
                                <input type="checkbox" .checked=${this.autoSyncEnabled} @change=${(e: Event) => this.autoSyncEnabled = (e.target as HTMLInputElement).checked}>
                                <span class="slider"></span>
                            </label>
                            <label for="auto-sync-toggle" style="margin-left: 0.5rem;">Auto-Sync</label>
                        </div>
                    </div>
                    <div class="agent-status-list">
                        ${(Object.keys(agentStatus) as AgentName[]).map(key => html`
                            <div class="status-item">
                                <div class="agent-name"><span class="status-indicator ${agentStatus[key].status}"></span>${key.charAt(0).toUpperCase() + key.slice(1)}</div>
                                <div class="agent-status-message">${agentStatus[key].message || agentStatus[key].status}</div>
                            </div>
                        `)}
                    </div>
                </div>
            </div>
        `;
    }
}