/**
 * @fileoverview Type definitions (contracts) for the Audio Intelligence Layer.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type { Analysis, Stems, AudioIntelApi } from './audio-intel.ts';