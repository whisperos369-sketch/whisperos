import { LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';

@customElement('settings-utility')
export class SettingsUtility extends LitElement {
    // This component is a placeholder to prevent import errors.
    // The main implementation has been moved to settings-module.ts to fix a module resolution issue.
}
