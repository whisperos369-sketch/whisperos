import { LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';

@customElement('j-slider')
export class JSlider extends LitElement {
    // This component is a placeholder to prevent import errors.
}
