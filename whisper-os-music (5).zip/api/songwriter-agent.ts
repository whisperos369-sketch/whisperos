import type { CreativeAgent } from "../core/types.ts";
export const SongwriterAgent: CreativeAgent = {
  name:"songwriter", consumes:["intent"], produces:["lyrics.draft"],
  async run(input, ctx){
    const llm = await ctx.getModel("llm");
    const out = await llm.generate({ role:"songwriter", intent: input.intent ?? "create hit", style: input.style ?? "hiphop" });
    const lyrics = (out as any)?.lyrics ?? out;
    ctx.setBlackboard("lyrics", lyrics);
    return { "lyrics.draft": lyrics };
  }
};