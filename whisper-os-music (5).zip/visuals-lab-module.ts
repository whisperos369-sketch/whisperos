import { LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';

@customElement('visuals-lab-module')
export class VisualsLabModule extends LitElement {
    // This component is a placeholder to prevent import errors.
}
