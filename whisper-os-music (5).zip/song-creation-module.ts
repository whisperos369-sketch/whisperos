import { LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';

@customElement('song-creation-module')
export class SongCreationModule extends LitElement {
    // This component is a placeholder to prevent import errors.
}
