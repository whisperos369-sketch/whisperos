/**
 * @fileoverview A service for packaging and exporting all project assets.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { env } from '../config/env.ts';
import type { SongState } from '../sections.ts';

/**
 * Builds a metadata object from the current project state.
 */
function buildMetadata(project: SongState): Record<string, any> {
    return {
        title: project.meta.title,
        bpm: project.meta.bpm,
        key: project.meta.key,
        duration: project.meta.duration,
        lufsTarget: project.meta.lufsTarget,
        createdAt: new Date(project.meta.createdAt).toISOString(),
        updatedAt: new Date(project.meta.updatedAt).toISOString(),
        measurements: project.meta.measurements,
        loraStack: project.loraStack,
        generatorSettings: project.generators,
        lyrics: project.lyrics,
    };
}

/**
 * Gathers all asset URLs, builds metadata, and posts to a backend service
 * to create a downloadable .zip bundle.
 * @param project The current song state.
 * @returns An object containing the URL to download the bundle.
 */
export async function exportBundle(project: SongState): Promise<{ downloadUrl: string }> {
    const metadata = buildMetadata(project);
    
    // Gather all file URLs from the project state
    const filesToBundle: Record<string, string | undefined> = {
        'master.wav': project.audio.latestMix,
        'mix.wav': project.audio.latestMix, // Assuming latestMix is the mastered version
        'video.mp4': project.visuals?.videoUrl,
        'cover.png': project.visuals?.coverArtUrl,
        ...project.audio.stems,
    };
    
    // Filter out any undefined URLs
    const validFiles = Object.entries(filesToBundle)
        .filter(([, url]) => !!url)
        .reduce((acc, [name, url]) => ({ ...acc, [name]: url }), {});

    console.log('[Export] Bundling files:', validFiles);
    console.log('[Export] with metadata:', metadata);
    
    // In a real app, this would post the file references and metadata to a backend
    // which would then assemble the zip and return a link. Here, we simulate it.
    const response = await fetch(env.EXPORT_BUNDLE_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            files: validFiles,
            metadata: metadata,
        })
    });

    if (!response.ok) {
        throw new Error('Failed to create export bundle from the server.');
    }

    // The backend is expected to return a JSON object with a downloadUrl property.
    return response.json();
}