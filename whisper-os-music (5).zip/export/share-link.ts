/**
 * @fileoverview A service for creating shareable links for projects.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { env } from '../config/env.ts';

/**
 * Posts project information to a backend service to generate a unique, shareable link.
 * @param payload An object containing the project ID or asset URL to share.
 * @returns An object containing the generated shareable URL.
 */
export async function createShareLink(payload: { projectId: string }): Promise<{ shareUrl: string }> {
    console.log('[Share] Creating share link for:', payload);
    
    // In a real app, this would post to a backend service that creates a public
    // page or record associated with the project ID.
    const response = await fetch(env.SHARE_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });

    if (!response.ok) {
        throw new Error('Failed to create share link from the server.');
    }

    // The backend is expected to return a JSON object with a shareUrl property.
    return response.json();
}