/**
 * @fileoverview A persistent, reactive service for managing long-running jobs.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { get, set, keys, del } from 'idb-keyval';
import { v4 as uuidv4 } from 'uuid';

export type JobStatus = 'queued' | 'running' | 'paused' | 'completed' | 'failed' | 'cancelled';

export interface Job {
    id: string;
    name: string;
    status: JobStatus;
    progress: number; // 0-100
    attempts: number;
    createdAt: number;
    updatedAt: number;
    payload: any;
    meta?: Record<string, any>;
    error?: string;
}

const JOB_PREFIX = 'job-';

class JobQueueService extends EventTarget {
    private async _getJob(id: string): Promise<Job | undefined> {
        return get(`${JOB_PREFIX}${id}`);
    }

    private async _setJob(job: Job): Promise<void> {
        job.updatedAt = Date.now();
        await set(`${JOB_PREFIX}${job.id}`, job);
        this.dispatchEvent(new CustomEvent('update'));
    }

    async enqueue(name: string, payload: any): Promise<Job> {
        const job: Job = {
            id: uuidv4(),
            name,
            payload,
            status: 'queued',
            progress: 0,
            attempts: 1,
            createdAt: Date.now(),
            updatedAt: Date.now(),
        };
        await this._setJob(job);
        return job;
    }

    async listJobs(): Promise<Job[]> {
        const allKeys = await keys();
        const jobKeys = allKeys.filter(k => typeof k === 'string' && k.startsWith(JOB_PREFIX));
        const jobs = await Promise.all(jobKeys.map(k => get(k as IDBValidKey)));
        return (jobs as Job[]).sort((a, b) => b.createdAt - a.createdAt);
    }
    
    async updateJob(id: string, updates: Partial<Job>): Promise<void> {
        const job = await this._getJob(id);
        if (job) {
            Object.assign(job, updates);
            await this._setJob(job);
        }
    }

    async updateProgress(id: string, progress: number, meta?: Record<string, any>): Promise<void> {
        await this.updateJob(id, { progress, meta, status: 'running' });
    }

    async pause(id: string): Promise<void> {
        await this.updateJob(id, { status: 'paused' });
    }

    async resume(id: string): Promise<void> {
        await this.updateJob(id, { status: 'running' });
    }

    async cancel(id: string): Promise<void> {
        await this.updateJob(id, { status: 'cancelled', progress: 0 });
    }
    
    async complete(id: string): Promise<void> {
        await this.updateJob(id, { status: 'completed', progress: 100 });
    }

    async fail(id: string, error: string): Promise<void> {
        await this.updateJob(id, { status: 'failed', error });
    }

    async retry(id: string): Promise<void> {
        const job = await this._getJob(id);
        if (job) {
            await this.updateJob(id, {
                status: 'queued',
                progress: 0,
                attempts: job.attempts + 1,
                error: undefined
            });
        }
    }
}

export const jobQueueService = new JobQueueService();
