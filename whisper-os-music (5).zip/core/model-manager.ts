/**
 * @fileoverview Central manager for abstracting AI model implementations.
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import type { ModelAdapter } from "@/core/types.ts";
import { z } from "zod";
import { env, flags } from "@/config/env.ts";
import { withRetry, withTimeout, CircuitBreaker } from "@/infra.ts";
const adapters = new Map<string, ModelAdapter>();

// Create circuit breakers for the services to maintain state across calls
const musicgenBreaker = new CircuitBreaker();
const llmBreaker = new CircuitBreaker();
const aceStepBreaker = new CircuitBreaker();

export function registerModel(m: ModelAdapter){ adapters.set(m.id, m); }
export async function getModel(id: string){ const m = adapters.get(id); if(!m) throw new Error(`Model not registered: ${id}`); return m; }

export function bootstrapDefaultModels(){
  const musicgen: ModelAdapter = {
    id:"musicgen", kind:"music",
    generate: async (p)=> {
      const payload = z.object({ prompt:z.string(), duration:z.number().optional() }).parse(p);
      const fetchFn = () => fetch(env.MUSICGEN_URL, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(payload) });
      
      // Wrap the call with resilience patterns
      const res = await musicgenBreaker.run(() => 
        withRetry(() => 
          withTimeout(fetchFn(), env.API_TIMEOUT_MS)
        )
      );

      if(!res.ok) throw new Error("musicgen failed"); return res.json();
    }
  };
  const llm: ModelAdapter = {
    id:"llm", kind:"text",
    generate: async (p)=> {
      const fetchFn = () => fetch(env.LLM_URL, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(p) });
      
      // Wrap the call with resilience patterns
      const res = await llmBreaker.run(() => 
        withRetry(() => 
          withTimeout(fetchFn(), env.API_TIMEOUT_MS)
        )
      );
      
      if(!res.ok) throw new Error("llm failed"); return res.json();
    }
  };
  adapters.set(musicgen.id, musicgen);
  adapters.set(llm.id, llm);

  if (flags.ace) {
      const aceStep: ModelAdapter = {
          id: "ace-step",
          kind: "music",
          generate: async (params) => {
              const payload = { 
                  prompt: params.prompt, 
                  steps: params.steps ?? 20, 
                  cfg: params.cfg ?? 7, 
                  seed: params.seed ?? null 
              };
              const fetchFn = () => fetch(env.ACE_URL, {
                  method: "POST", 
                  headers: { "Content-Type": "application/json" }, 
                  body: JSON.stringify(payload)
              });
              const res = await aceStepBreaker.run(() => withRetry(() => withTimeout(fetchFn(), env.API_TIMEOUT_MS)));
              if (!res.ok) throw new Error("ACE-Step failed");
              return res.json();
          }
      };
      adapters.set(aceStep.id, aceStep);
  }

  if (flags.rvc) adapters.set("rvc", { id:"rvc", kind:"voice", generate: async (p)=> ({ url:"/api/rvc/output.wav", mock:true, p }) });
}