import mitt from "mitt";
import type { OrchestratorEvent } from "./types.ts";
export const bus = mitt<{ event: OrchestratorEvent }>();
export const emit = (e: OrchestratorEvent) => bus.emit("event", e);