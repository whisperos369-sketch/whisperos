export type AgentIO = Record<string, unknown>;
export interface CreativeAgent {
  name: string; consumes: string[]; produces: string[];
  run(input: AgentIO, ctx: OrchestratorContext): Promise<AgentIO>;
}
export interface ModelAdapter {
  id: string; kind: "music"|"text"|"voice"|"vision";
  generate: (params: Record<string, unknown>) => Promise<unknown>;
}
export interface OrchestratorContext {
  emit: (e: OrchestratorEvent)=> void;
  getModel: (key: string)=> Promise<ModelAdapter>;
  setBlackboard: (k: string, v: unknown)=> void;
  getBlackboard: <T=unknown>(k: string)=> T|undefined;
}
export type OrchestratorEvent =
 | { type:"STEP_STARTED"; agent:string }
 | { type:"STEP_FINISHED"; agent:string; outputKeys:string[] }
 | { type:"EVALUATION_READY"; score:number; notes:string[] }
 | { type:"RELOOP_TRIGGERED"; reason:string }
 | { type:"ERROR"; agent?:string; message:string };