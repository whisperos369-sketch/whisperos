import { emit } from "./bus.ts";
import { getAgent } from "./agent-registry.ts";
import type { AgentIO, OrchestratorContext } from "./types.ts";
class Blackboard { private s=new Map<string,unknown>(); set(k:string,v:unknown){this.s.set(k,v)} get<T=unknown>(k:string){return this.s.get(k) as T|undefined} }
export class Orchestrator {
  private bb = new Blackboard();
  constructor(private ctx: Pick<OrchestratorContext,"getModel">) {}
  private mkCtx(): OrchestratorContext { return { emit, getModel: this.ctx.getModel, setBlackboard:(k,v)=>this.bb.set(k,v), getBlackboard:<T=unknown>(k:string)=>this.bb.get<T>(k) }; }
  async runPipeline(steps: string[], seed: AgentIO){ let io = { ...seed }; const c = this.mkCtx();
    for (const name of steps){ try{ const a = getAgent(name); emit({type:"STEP_STARTED", agent:name}); io = { ...io, ...(await a.run(io, c)) }; emit({type:"STEP_FINISHED", agent:name, outputKeys:Object.keys(io)}); }catch(e:any){ emit({type:"ERROR", agent:name, message:String(e?.message??e)}); throw e; } }
    return io;
  }
}