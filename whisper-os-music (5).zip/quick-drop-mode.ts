import { LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';

@customElement('quick-drop-mode')
export class QuickDropMode extends LitElement {
    // This component is a placeholder to prevent import errors.
}
