/**
 * @fileoverview Service for scheduling jobs with numerology alignment.
 */
import dayjs from "dayjs";
import { storeGet, storeSet } from "@/ops/datastore.ts";
import { getSettings } from "@/ops/settings-service.ts";
// FIX: Import Job type from the correct path.
import type { Job } from "@/ops/types.ts";

export async function schedule(job: Job): Promise<Job> { 
    const list: Job[] = (await storeGet("scheduler.jobs")) ?? []; 
    list.push(job); 
    await storeSet("scheduler.jobs", list); 
    return job; 
}

export async function listJobs(): Promise<Job[]> { 
    return (await storeGet("scheduler.jobs")) ?? []; 
}

/** 
 * Simple numerology alignment: prefer hours/minutes that sum to primary/secondary numbers (fallback to next hour). 
 */
export async function alignTime(ts: string): Promise<string> {
  const s = await getSettings();
  if (!s.numerology?.enabled) return ts;
  
  const target = s.numerology.primary ?? 8;
  let t = dayjs(ts);
  
  for (let i = 0; i < 120; i++) { // Search up to 10 hours (120 * 5 mins)
    const sum = t.hour() + t.minute();
    if (sum % target === 0) return t.toISOString();
    t = t.add(5, "minute");
  }
  
  return dayjs(ts).toISOString(); // Fallback if no alignment found
}
