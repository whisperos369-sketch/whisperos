import { LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';

@customElement('drop-manager-module')
export class DropManagerModule extends LitElement {
    // This component is a placeholder to prevent import errors.
}
