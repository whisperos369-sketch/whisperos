import type { CreativeAgent } from "../core/types.ts";
export const EvaluationAgent: CreativeAgent = {
  name: "evaluation", consumes: ["master.url", "lyrics.draft", "cover.url"], produces: ["eval.score", "eval.notes"],
  async run(input, ctx){
    console.log("[EvaluationAgent] Simulating evaluation.");
    await new Promise(r => setTimeout(r, 500));
    const score = Math.random() * 0.4 + 0.5; // score between 0.5 and 0.9
    ctx.emit({ type: "EVALUATION_READY", score, notes: ["Mock evaluation complete."] });
    return { "eval.score": score, "eval.notes": "Mock evaluation looks good." };
  }
};
