import type { CreativeAgent } from "../core/types.ts";
export const MasteringAgent: CreativeAgent = {
  name: "mastering", consumes: ["mix.url"], produces: ["master.url"],
  async run(input, _ctx){
    console.log("[MasteringAgent] Simulating mastering.");
    await new Promise(r => setTimeout(r, 1000));
    return { "master.url": input["mix.url"] };
  }
};