import type { CreativeAgent } from "../core/types.ts";
export const MixingAgent: CreativeAgent = {
  name: "mixing", consumes: ["beat.stem"], produces: ["mix.url"],
  async run(input, _ctx){
    console.log("[MixingAgent] Simulating mixdown.");
    await new Promise(r => setTimeout(r, 1000));
    // Pass through the beat URL as the mix URL for now
    const mixUrl = input["beat.stem"];
    return { "mix.url": mixUrl };
  }
};
