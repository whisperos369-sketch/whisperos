import { registerAgent } from "@/core/agent-registry.ts";
import { SongwriterAgent } from "@/agents/songwriter-agent.ts";
import { BeatAgent } from "@/agents/beat-agent.ts";
import { MixingAgent } from "@/agents/mixing-agent.ts";
import { MasteringAgent } from "@/agents/mastering-agent.ts";
import { VisualsAgent } from "@/agents/visuals-agent.ts";
import { EvaluationAgent } from "@/agents/evaluation-agent.ts";
import { HookArchitectAgent } from "@/agents/hook-architect-agent.ts";
import { GrooveSurgeonAgent } from "@/agents/groove-surgeon-agent.ts";
import { EmotionalConductorAgent } from "@/agents/emotional-conductor-agent.ts";
import { SpatialSoundArchitectAgent } from "@/agents/spatial-sound-architect-agent.ts";
import { ArrangementAgent } from "@/agents/arrangement-agent.ts";

export function registerAllAgents(){
  [
    SongwriterAgent, 
    ArrangementAgent,
    HookArchitectAgent,
    EmotionalConductorAgent,
    GrooveSurgeonAgent,
    BeatAgent, 
    MixingAgent,
    SpatialSoundArchitectAgent,
    MasteringAgent, 
    VisualsAgent, 
    EvaluationAgent
  ].forEach(registerAgent);
