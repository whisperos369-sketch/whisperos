import type { CreativeAgent } from "../core/types.ts";
export const BeatAgentWrapper: CreativeAgent = {
  name:"beat", consumes:["lyrics.draft", "project"], produces:["beat.stem"],
  async run(input, ctx){
    const mode = (input.mode as 'musicgen' | 'ace-step') ?? "musicgen";
    const model = await ctx.getModel(mode);

    const params: Record<string, any> = {
        prompt: `Beat for: ${String(input["lyrics.draft"]||"").slice(0,300)}`
    };

    if (mode === 'ace-step') {
        const project = input.project as any;
        params.steps = 20;
        params.cfg = 7;
        params.seed = project?.generators?.seed;
    }

    const res = await model.generate(params);
    const url = (res as any)?.url ?? (res as any)?.audioUrl ?? (typeof res === 'string' ? res : null);
    if (!url) {
      console.error("Beat generation response:", res);
      throw new Error("Beat generation failed: no audio URL in response");
    }
    ctx.setBlackboard("beat.url", url);
    return { "beat.stem": url };
  }
};